import React, { useState } from 'react';
import { Shield, Lock, User, AlertCircle, ArrowLeft, Eye, EyeOff, Zap, RefreshCw, CheckCircle, Check } from 'lucide-react';

interface AdminLoginProps {
  onLoginSuccess: (token: string, username: string, requiresPasswordChange: boolean) => void;
  onBackToStore: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({
  onLoginSuccess,
  onBackToStore
}) => {
  const [username, setUsername] = useState('RuhinurRahman');
  const [password, setPassword] = useState('Ruhin1');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);
  const [resetting, setResetting] = useState(false);

  const saveTokenSafely = (token: string, user: string) => {
    try {
      localStorage.setItem('vf_admin_token', token);
      localStorage.setItem('vf_admin_user', user);
    } catch {
      // Safe fallback for restricted iframe sandbox
      (window as any).__vf_admin_token = token;
      (window as any).__vf_admin_user = user;
    }
  };

  const performLogin = async (userToSubmit: string, passToSubmit: string) => {
    setError(null);
    setResetSuccess(null);
    setLoading(true);

    try {
      const cleanUser = userToSubmit.trim() || 'RuhinurRahman';
      const cleanPass = passToSubmit.trim() || 'Ruhin1';

      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ username: cleanUser, password: cleanPass })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'ভুল ইউজারনেম বা পাসওয়ার্ড।');
      }

      saveTokenSafely(data.token, data.username);
      onLoginSuccess(data.token, data.username, data.requiresPasswordChange);
    } catch (err: any) {
      console.error('Login error:', err);
      setError(err.message || 'লগইন করতে সমস্যা হচ্ছে। নিচে ১-ক্লিকে সরাসরি লগইন বোতাম ব্যবহার করুন।');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performLogin(username, password);
  };

  const handleQuickLogin = async () => {
    setError(null);
    setResetSuccess(null);
    setLoading(true);

    try {
      // Try dedicated instant-login endpoint first
      const res = await fetch('/api/admin/instant-login', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include'
      });

      if (res.ok) {
        const data = await res.json();
        saveTokenSafely(data.token, data.username);
        onLoginSuccess(data.token, data.username, false);
        return;
      }
    } catch (instantErr) {
      console.warn('Instant login endpoint error, trying standard login:', instantErr);
    }

    // Fallback to standard login
    setUsername('RuhinurRahman');
    setPassword('Ruhin1');
    performLogin('RuhinurRahman', 'Ruhin1');
  };

  const handleResetPassword = async () => {
    setResetting(true);
    setError(null);
    try {
      const res = await fetch('/api/admin/reset-default-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include'
      });
      const data = await res.json();
      if (res.ok) {
        setUsername('RuhinurRahman');
        setPassword('Ruhin1');
        setResetSuccess('পাসওয়ার্ড সফলভাবে Ruhin1-এ রিসেট করা হয়েছে! এখন লগইন করুন।');
      } else {
        setError(data.error || 'রিসেট করা যায়নি');
      }
    } catch {
      setError('পাসওয়ার্ড রিসেটে ত্রুটি হয়েছে।');
    } finally {
      setResetting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center py-10 sm:px-6 lg:px-8 text-left">
      <div className="sm:mx-auto sm:w-full sm:max-w-md px-4">
        <button
          onClick={onBackToStore}
          className="text-xs text-slate-400 hover:text-white flex items-center gap-1.5 mb-6 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>ওয়েবসাইটে ফিরে যান (Return to Storefront)</span>
        </button>

        <div className="text-center">
          <div className="w-12 h-12 bg-slate-900 border border-slate-700 rounded-xl flex items-center justify-center mx-auto text-[#c29b38]">
            <Shield className="w-6 h-6" />
          </div>
          <h2 className="mt-4 text-2xl font-serif font-bold text-white tracking-tight">
            VELRO FASHION
          </h2>
          <p className="mt-1 text-xs text-slate-400 font-mono">
            অ্যাডমিন ও ড্রপশিপিং কন্ট্রোল পোর্টাল
          </p>
        </div>

        <div className="mt-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-xs space-y-5">
          
          {/* Quick 1-Click Login Button for Owner */}
          <div className="p-3.5 bg-gradient-to-r from-amber-950/60 via-slate-900 to-amber-950/40 border border-[#c29b38]/70 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-[#c29b38] flex items-center gap-1.5 font-mono">
                <Zap className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span>মাস্টার অ্যাডমিন ক্রেডেনশিয়াল</span>
              </span>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.2 rounded font-mono font-bold">
                ACTIVE
              </span>
            </div>
            <div className="text-xs text-slate-300 font-mono space-y-0.5">
              <p>User ID: <strong className="text-white">RuhinurRahman</strong> (বা admin)</p>
              <p>Password: <strong className="text-white">Ruhin1</strong></p>
            </div>
            <button
              type="button"
              onClick={handleQuickLogin}
              disabled={loading}
              className="w-full mt-2 py-2 px-3 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-lg text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all font-mono"
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>১-ক্লিকে সরাসরি লগইন করুন (Instant Entry)</span>
            </button>
          </div>

          {resetSuccess && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-800 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{resetSuccess}</span>
            </div>
          )}

          {error && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 rounded-xl text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-medium mb-1">ইউজারনেম (Username / Email)</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="RuhinurRahman বা admin"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-800/80 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-[#c29b38] font-mono"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-slate-300 font-medium">পাসওয়ার্ড (Password)</label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-slate-400 hover:text-white flex items-center gap-1 text-[11px] cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}</span>
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Ruhin1"
                  className="w-full pl-9 pr-10 py-2.5 bg-slate-800/80 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-[#c29b38] font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white border border-slate-600 rounded-xl font-bold tracking-wide transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
            >
              <Shield className="w-4 h-4 text-[#c29b38]" />
              <span>{loading ? 'যাচাই করা হচ্ছে...' : 'লগইন করুন (Sign In)'}</span>
            </button>
          </form>

          {/* Reset password button if user forgot changed password */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-800 text-[11px] text-slate-400">
            <span>পাসওয়ার্ডে সমস্যা হচ্ছে?</span>
            <button
              type="button"
              onClick={handleResetPassword}
              disabled={resetting}
              className="text-[#c29b38] hover:underline flex items-center gap-1 cursor-pointer font-medium"
            >
              <RefreshCw className={`w-3 h-3 ${resetting ? 'animate-spin' : ''}`} />
              <span>ডিফল্ট পাসওয়ার্ডে রিসেট করুন</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
