import React, { useState, useEffect, useRef } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingBag, 
  Layers, 
  CreditCard, 
  LogOut, 
  Shield, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  RefreshCw, 
  Plus, 
  Edit, 
  Trash2, 
  Activity,
  Check,
  X,
  Lock,
  Database,
  Share2,
  UploadCloud,
  Palette,
  Ruler,
  Code2,
  ExternalLink,
  MessageCircle,
  Settings,
  Phone,
  Truck,
  Tag,
  Bell,
  Store,
  Save,
  MoreHorizontal,
  Key
} from 'lucide-react';
import { Product, SupplierIntegration, SupplierFulfillmentRequest, SyncLog, ProductColorItem, ProductSizeItem, Coupon } from '../types';

interface AdminDashboardProps {
  adminUsername: string;
  initialRequiresPasswordChange: boolean;
  onLogout: () => void;
  onReturnToStore: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  adminUsername,
  initialRequiresPasswordChange,
  onLogout,
  onReturnToStore
}) => {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'dropshipping' | 'facebook' | 'settings' | 'sql' | 'payments' | 'audit'>('overview');

  // Dropshipping subtabs
  const [dropshipSubtab, setDropshipSubtab] = useState<
    'connected_apps' | 'available' | 'supplier_accounts' | 'product_import' | 
    'imported_products' | 'order_sync' | 'fulfillment' | 'shipment_tracking' | 
    'sync_logs' | 'integration_settings'
  >('connected_apps');

  // Main entity states
  const [stats, setStats] = useState<any>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [integrations, setIntegrations] = useState<SupplierIntegration[]>([]);
  const [, setFulfillments] = useState<SupplierFulfillmentRequest[]>([]);
  const [, setSyncLogs] = useState<SyncLog[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [facebookSettings, setFacebookSettings] = useState<any>({
    pageName: 'VELRO FASHION BD',
    pageId: 'velrofashion.bd',
    pageUrl: 'https://facebook.com/velrofashion.bd',
    messengerUrl: 'https://m.me/velrofashion.bd',
    pixelId: '129481928419284',
    accessToken: 'EAAB...facebook_page_token_verified',
    catalogSyncEnabled: true,
    messengerChatEnabled: true,
    lastCatalogSync: ''
  });

  // Store Master Settings & Coupons State
  const [storeSettings, setStoreSettings] = useState<any>({
    storeName: 'VELRO FASHION',
    storeNameBn: 'ভেলরো ফ্যাশন',
    storeTagline: 'অভিজাত বাংলাদেশী ও সমকালীন ফ্যাশন',
    storeTaglineEn: 'Curated Bangladeshi & Contemporary Fashion',
    announcementBarText: 'সারা দেশে হোম ডেলিভারি | COD & bKash Verified',
    announcementBarTextEn: 'Nationwide Fast Delivery & Cash on Delivery Available',
    showAnnouncementBar: true,
    currency: 'BDT',
    currencySymbol: '৳',
    defaultDeliveryFeeDhaka: 70,
    defaultDeliveryFeeOutside: 130,
    freeShippingThreshold: 5000,
    deliveryTimeDhaka: '২৪-৪৮ ঘণ্টা',
    deliveryTimeOutside: '৩-৫ দিন',
    courierPreference: 'steadfast',
    supportPhone: '+880 1711-982341',
    whatsappNumber: '+8801711982341',
    supportEmail: 'support@velrofashion.com',
    showroomAddress: 'রোড ১১, ব্লক ডি, বনানী, ঢাকা-১২১৩, বাংলাদেশ',
    officeHours: '১০:০০ AM - ১০:০০ PM',
    enableCod: true,
    enableBkash: true,
    enableNagad: true,
    enableRocket: true,
    enableSslcommerz: true,
    bkashMerchantNumber: '01711-982341',
    nagadMerchantNumber: '01711-982341',
    rocketMerchantNumber: '01711-982341-8',
    autoFulfillPaidOrders: true,
    allowCodFulfillment: true,
    defaultMarkupPercentage: 90,
    minProfitMarginBdt: 400,
    enableSandboxPayments: true
  });

  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponValue, setNewCouponValue] = useState(10);
  const [newCouponType, setNewCouponType] = useState<'percentage' | 'fixed'>('percentage');
  const [newCouponMin, setNewCouponMin] = useState(1000);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);
  const [settingsCategory, setSettingsCategory] = useState<'all' | 'branding' | 'contact' | 'delivery' | 'payments' | 'social' | 'coupons' | 'security'>('all');

  const [directPasswordNew, setDirectPasswordNew] = useState('');
  const [directPasswordConfirm, setDirectPasswordConfirm] = useState('');
  const [directPasswordMessage, setDirectPasswordMessage] = useState<string | null>(null);
  const [directPasswordLoading, setDirectPasswordLoading] = useState(false);

  // SQL console states
  const [sqlTables, setSqlTables] = useState<Array<{ name: string; rowCount: number }>>([]);
  const [sqlQuery, setSqlQuery] = useState<string>('SELECT id, sku, title, selling_price, stock_quantity FROM products LIMIT 10;');
  const [sqlResults, setSqlResults] = useState<any>(null);
  const [sqlRunning, setSqlRunning] = useState<boolean>(false);
  const [sqlError, setSqlError] = useState<string | null>(null);

  // Supplier product import preview
  const [previewProducts, setPreviewProducts] = useState<any[]>([]);
  const [selectedSupplierForImport, setSelectedSupplierForImport] = useState<string>('int-shopbase');
  const [importLoading, setImportLoading] = useState(false);
  const [markupPct, setMarkupPct] = useState(90);

  // Modals
  const [showPasswordChangeModal, setShowPasswordChangeModal] = useState(initialRequiresPasswordChange);
  const [newPassword, setNewPassword] = useState('');
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState(false);

  // Product Edit Modal with Gallery Upload & Color/Size Variant System
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [newColorName, setNewColorName] = useState('');
  const [newColorHex, setNewColorHex] = useState('#1e3a8a');
  const [newSizeInput, setNewSizeInput] = useState('');
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Selected Order for Modal/Invoice
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);

  // ShopBase BD (https://shopbasebd.com/) Connect / Login Modal State
  const [shopbaseModalOpen, setShopbaseModalOpen] = useState(false);
  const [shopbaseStoreUrl, setShopbaseStoreUrl] = useState('https://shopbasebd.com/');
  const [shopbasePhone, setShopbasePhone] = useState('01711982341');
  const [shopbaseApiKey, setShopbaseApiKey] = useState('sb_bd_live_reseller_token_2026');
  const [shopbaseStoreName, setShopbaseStoreName] = useState('VELRO FASHION BD');
  const [shopbaseConnecting, setShopbaseConnecting] = useState(false);

  // Status feedback toast
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const showNotice = (msg: string) => {
    setActionNotice(msg);
    setTimeout(() => setActionNotice(null), 3500);
  };

  const adminFetch = (url: string, options: RequestInit = {}) => {
    let token = '';
    try {
      token = localStorage.getItem('vf_admin_token') || (window as any).__vf_admin_token || '';
    } catch {
      token = (window as any).__vf_admin_token || '';
    }
    const headers = new Headers(options.headers || {});
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
      headers.set('x-admin-token', token);
    }
    return fetch(url, {
      ...options,
      headers,
      credentials: 'include'
    });
  };

  const loadAllData = async () => {
    try {
      let statsRes = await adminFetch('/api/admin/dashboard-stats');
      if (statsRes.status === 401) {
        // Attempt background silent session recovery for owner
        try {
          const recRes = await fetch('/api/admin/instant-login', { method: 'POST', credentials: 'include' });
          if (recRes.ok) {
            const recData = await recRes.json();
            try {
              localStorage.setItem('vf_admin_token', recData.token);
              localStorage.setItem('vf_admin_user', recData.username);
            } catch {
              (window as any).__vf_admin_token = recData.token;
            }
            statsRes = await adminFetch('/api/admin/dashboard-stats');
          }
        } catch {}

        if (statsRes.status === 401) {
          try {
            localStorage.removeItem('vf_admin_token');
          } catch {}
          onLogout();
          return;
        }
      }

      const [
        prodRes, 
        ordRes, 
        intRes, 
        fulRes, 
        logRes, 
        audRes,
        fbRes,
        sqlRes,
        settingsRes
      ] = await Promise.all([
        adminFetch('/api/admin/products'),
        adminFetch('/api/admin/orders'),
        adminFetch('/api/admin/dropshipping/integrations'),
        adminFetch('/api/admin/dropshipping/fulfillments'),
        adminFetch('/api/admin/dropshipping/sync-logs'),
        adminFetch('/api/admin/audit-logs'),
        adminFetch('/api/facebook/settings'),
        adminFetch('/api/admin/sql/tables'),
        adminFetch('/api/admin/settings')
      ]);

      if (statsRes.ok) setStats(await statsRes.json());
      if (prodRes.ok) { const d = await prodRes.json(); setProducts(d.products || []); }
      if (ordRes.ok) { const d = await ordRes.json(); setOrders(d.orders || []); }
      if (intRes.ok) { const d = await intRes.json(); setIntegrations(d.integrations || []); }
      if (fulRes.ok) { const d = await fulRes.json(); setFulfillments(d.fulfillments || []); }
      if (logRes.ok) { const d = await logRes.json(); setSyncLogs(d.logs || []); }
      if (audRes.ok) { const d = await audRes.json(); setAuditLogs(d.logs || []); }
      if (fbRes.ok) { const d = await fbRes.json(); setFacebookSettings(d.settings || {}); }
      if (sqlRes.ok) { const d = await sqlRes.json(); setSqlTables(d.tables || []); }
      if (settingsRes.ok) {
        const sData = await settingsRes.json();
        if (sData.settings) setStoreSettings((prev: any) => ({ ...prev, ...sData.settings }));
        if (sData.coupons) setCoupons(sData.coupons);
      }
    } catch (err) {
      console.error('Error loading admin data:', err);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // --- Gallery Image File Upload ---
  const handleGalleryUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !editingProduct) return;
    setIsUploadingImage(true);

    try {
      const newImages = [...(editingProduct.images || [])];
      
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const reader = new FileReader();
        const base64Promise = new Promise<string>((resolve) => {
          reader.onload = (event) => {
            resolve(event.target?.result as string);
          };
          reader.readAsDataURL(file);
        });

        const base64Data = await base64Promise;
        const res = await adminFetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            image: base64Data,
            filename: `product_${Date.now()}_${i}`
          })
        });

        const data = await res.json();
        if (data.url) {
          newImages.push(data.url);
        }
      }

      setEditingProduct({
        ...editingProduct,
        images: newImages
      });
      showNotice(`${files.length} টি ছবি আপলোড সফল!`);
    } catch (err: any) {
      showNotice('Image upload error: ' + err.message);
    } finally {
      setIsUploadingImage(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const removeGalleryImage = (indexToRemove: number) => {
    if (!editingProduct) return;
    const filtered = (editingProduct.images || []).filter((_, idx) => idx !== indexToRemove);
    setEditingProduct({ ...editingProduct, images: filtered });
  };

  const makePrimaryImage = (indexToPrimary: number) => {
    if (!editingProduct || !editingProduct.images) return;
    const imgs = [...editingProduct.images];
    const selected = imgs.splice(indexToPrimary, 1)[0];
    imgs.unshift(selected);
    setEditingProduct({ ...editingProduct, images: imgs });
  };

  // --- Dynamic Color Management ---
  const addColorItem = () => {
    if (!newColorName.trim() || !editingProduct) return;
    const currentColors = [...(editingProduct.colors || [])];
    const currentColorItems: ProductColorItem[] = [...(editingProduct.colorItems || [])];

    if (!currentColors.includes(newColorName.trim())) {
      currentColors.push(newColorName.trim());
      currentColorItems.push({
        name: newColorName.trim(),
        hex: newColorHex,
        inStock: true
      });

      const sizes = editingProduct.sizes || ['Standard'];
      const updatedVariants = [...(editingProduct.variants || [])];
      
      sizes.forEach((s) => {
        const sku = `${editingProduct.sku || 'VF'}-${newColorName.trim().slice(0, 3).toUpperCase()}-${s}`;
        if (!updatedVariants.some(v => v.color === newColorName.trim() && v.size === s)) {
          updatedVariants.push({
            id: `v-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            sku,
            size: s,
            color: newColorName.trim(),
            stock: 25,
            costPrice: editingProduct.costPrice || 600,
            price: editingProduct.sellingPrice || 1200
          });
        }
      });

      setEditingProduct({
        ...editingProduct,
        colors: currentColors,
        colorItems: currentColorItems,
        variants: updatedVariants
      });
      setNewColorName('');
      showNotice(`কালার "${newColorName}" যুক্ত হয়েছে!`);
    }
  };

  const removeColorItem = (colorToRemove: string) => {
    if (!editingProduct) return;
    const colors = (editingProduct.colors || []).filter(c => c !== colorToRemove);
    const colorItems = (editingProduct.colorItems || []).filter(ci => ci.name !== colorToRemove);
    const variants = (editingProduct.variants || []).filter(v => v.color !== colorToRemove);
    setEditingProduct({ ...editingProduct, colors, colorItems, variants });
  };

  // --- Dynamic Size Management ---
  const addSizeItem = () => {
    if (!newSizeInput.trim() || !editingProduct) return;
    const currentSizes = [...(editingProduct.sizes || [])];
    const currentSizeItems: ProductSizeItem[] = [...(editingProduct.sizeItems || [])];

    if (!currentSizes.includes(newSizeInput.trim())) {
      currentSizes.push(newSizeInput.trim());
      currentSizeItems.push({
        size: newSizeInput.trim(),
        inStock: true
      });

      const colors = editingProduct.colors || ['Default'];
      const updatedVariants = [...(editingProduct.variants || [])];

      colors.forEach((c) => {
        const sku = `${editingProduct.sku || 'VF'}-${c.slice(0, 3).toUpperCase()}-${newSizeInput.trim()}`;
        if (!updatedVariants.some(v => v.size === newSizeInput.trim() && v.color === c)) {
          updatedVariants.push({
            id: `v-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            sku,
            size: newSizeInput.trim(),
            color: c,
            stock: 25,
            costPrice: editingProduct.costPrice || 600,
            price: editingProduct.sellingPrice || 1200
          });
        }
      });

      setEditingProduct({
        ...editingProduct,
        sizes: currentSizes,
        sizeItems: currentSizeItems,
        variants: updatedVariants
      });
      setNewSizeInput('');
      showNotice(`সাইজ "${newSizeInput}" যুক্ত হয়েছে!`);
    }
  };

  const applySizePreset = (presetSizes: string[]) => {
    if (!editingProduct) return;
    const colors = editingProduct.colors && editingProduct.colors.length > 0 ? editingProduct.colors : ['Standard'];
    const updatedVariants: any[] = [];

    presetSizes.forEach((s) => {
      colors.forEach((c) => {
        updatedVariants.push({
          id: `v-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          sku: `${editingProduct.sku || 'VF'}-${c.slice(0, 3).toUpperCase()}-${s}`,
          size: s,
          color: c,
          stock: 20,
          costPrice: editingProduct.costPrice || 600,
          price: editingProduct.sellingPrice || 1200
        });
      });
    });

    setEditingProduct({
      ...editingProduct,
      sizes: presetSizes,
      sizeItems: presetSizes.map(s => ({ size: s, inStock: true })),
      variants: updatedVariants
    });
    showNotice(`সাইজ প্রিসেট (${presetSizes.join(', ')}) প্রয়োগ করা হয়েছে!`);
  };

  const removeSizeItem = (sizeToRemove: string) => {
    if (!editingProduct) return;
    const sizes = (editingProduct.sizes || []).filter(s => s !== sizeToRemove);
    const sizeItems = (editingProduct.sizeItems || []).filter(si => si.size !== sizeToRemove);
    const variants = (editingProduct.variants || []).filter(v => v.size !== sizeToRemove);
    setEditingProduct({ ...editingProduct, sizes, sizeItems, variants });
  };

  // --- ShopBase BD Connection ---
  const handleConnectShopbaseBD = async (e: React.FormEvent) => {
    e.preventDefault();
    setShopbaseConnecting(true);
    try {
      const res = await adminFetch('/api/admin/dropshipping/shopbasebd/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storeUrl: shopbaseStoreUrl,
          resellerPhone: shopbasePhone,
          apiKey: shopbaseApiKey,
          storeName: shopbaseStoreName
        })
      });
      const data = await res.json();
      if (res.ok) {
        showNotice(`ShopBase BD (${shopbaseStoreUrl}) কানেক্ট সফল!`);
        setShopbaseModalOpen(false);
        loadAllData();
      } else {
        showNotice(data.error || 'Connection failed');
      }
    } catch (err: any) {
      showNotice('Connection error: ' + err.message);
    } finally {
      setShopbaseConnecting(false);
    }
  };

  // --- Facebook Page & Meta Commerce ---
  const handleSaveFacebookSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await adminFetch('/api/facebook/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(facebookSettings)
      });
      if (res.ok) {
        showNotice('Facebook Page ও Meta Shop সেটিংস সংরক্ষিত!');
        loadAllData();
      }
    } catch (err: any) {
      showNotice('Facebook settings error: ' + err.message);
    }
  };

  const handleSyncFacebookCatalog = async () => {
    showNotice('Facebook Catalog ফিড সিঙ্ক হচ্ছে...');
    try {
      const res = await adminFetch('/api/facebook/sync-catalog', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        showNotice(data.message);
        loadAllData();
      }
    } catch (err: any) {
      showNotice('Sync error: ' + err.message);
    }
  };

  // --- SQL Database Console ---
  const handleExecuteSql = async () => {
    if (!sqlQuery.trim()) return;
    setSqlRunning(true);
    setSqlError(null);
    try {
      const res = await adminFetch('/api/admin/sql/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: sqlQuery })
      });
      const data = await res.json();
      if (res.ok) {
        setSqlResults(data);
        showNotice(`SQL সম্পন্ন (${data.rowCount} rows)`);
        loadAllData();
      } else {
        setSqlError(data.error || 'SQL Execution error');
        setSqlResults(null);
      }
    } catch (err: any) {
      setSqlError(err.message);
    } finally {
      setSqlRunning(false);
    }
  };

  // Password change handler
  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) return;
    try {
      const res = await adminFetch('/api/admin/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword })
      });
      if (res.ok) {
        setPasswordChangeSuccess(true);
        setTimeout(() => {
          setShowPasswordChangeModal(false);
          setPasswordChangeSuccess(false);
          showNotice('Admin password successfully updated.');
        }, 1200);
      }
    } catch {
      showNotice('Failed to update password');
    }
  };

  // Direct Password Update from Settings Tab
  const handleDirectPasswordUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setDirectPasswordMessage(null);
    if (!directPasswordNew || directPasswordNew.length < 6) {
      setDirectPasswordMessage('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে!');
      return;
    }
    if (directPasswordNew !== directPasswordConfirm) {
      setDirectPasswordMessage('উভয় পাসওয়ার্ড একই হতে হবে!');
      return;
    }

    setDirectPasswordLoading(true);
    try {
      const res = await adminFetch('/api/admin/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: directPasswordNew })
      });
      const data = await res.json();
      if (res.ok) {
        setDirectPasswordMessage('পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!');
        setDirectPasswordNew('');
        setDirectPasswordConfirm('');
        showNotice('পাসওয়ার্ড পরিবর্তিত!');
      } else {
        setDirectPasswordMessage(data.error || 'ত্রুটি ঘটেছে');
      }
    } catch (err: any) {
      setDirectPasswordMessage('ত্রুটি: ' + err.message);
    } finally {
      setDirectPasswordLoading(false);
    }
  };

  // Dropshipping test connection handler
  const handleTestIntegration = async (intId: string) => {
    try {
      showNotice('Testing connection to supplier API gateway...');
      const res = await adminFetch(`/api/admin/dropshipping/integrations/${intId}/test`, { method: 'POST' });
      const data = await res.json();
      showNotice(data.message);
      loadAllData();
    } catch (err: any) {
      showNotice('Test failed: ' + err.message);
    }
  };

  // Fetch supplier catalog for product import preview
  const handleFetchSupplierProducts = async () => {
    setImportLoading(true);
    try {
      const res = await adminFetch(`/api/admin/dropshipping/integrations/${selectedSupplierForImport}/fetch-products`);
      const data = await res.json();
      setPreviewProducts(data.products || []);
      showNotice(`Fetched ${data.products?.length || 0} available products from supplier.`);
    } catch (err: any) {
      showNotice('Error fetching products: ' + err.message);
    } finally {
      setImportLoading(false);
    }
  };

  // Import single product draft
  const handleImportProduct = async (draft: any) => {
    try {
      const res = await adminFetch('/api/admin/dropshipping/import-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          supplierProductDraft: draft,
          markupPercentage: markupPct,
          status: 'published'
        })
      });
      const data = await res.json();
      if (res.ok) {
        showNotice(`Imported "${draft.title}" with ${markupPct}% markup!`);
        loadAllData();
      } else {
        showNotice(data.error || 'Import failed');
      }
    } catch (err: any) {
      showNotice('Import error: ' + err.message);
    }
  };

  // Trigger sync all
  const handleSyncAll = async () => {
    showNotice('Executing inventory & pricing synchronization across all connected suppliers...');
    try {
      const res = await adminFetch('/api/admin/dropshipping/sync-all', { method: 'POST' });
      const data = await res.json();
      showNotice(`Sync complete. Synced with ${data.results?.length || 0} supplier endpoints.`);
      loadAllData();
    } catch (err: any) {
      showNotice('Sync failed: ' + err.message);
    }
  };

  // Save / Update product
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    try {
      const isNew = !editingProduct.id;
      const url = isNew ? '/api/admin/products' : `/api/admin/products/${editingProduct.id}`;
      const method = isNew ? 'POST' : 'PUT';
      const res = await adminFetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingProduct)
      });
      if (res.ok) {
        showNotice(isNew ? 'Product created successfully' : 'Product updated successfully');
        setProductModalOpen(false);
        setEditingProduct(null);
        loadAllData();
      }
    } catch (err: any) {
      showNotice('Failed to save product: ' + err.message);
    }
  };

  // Delete product
  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Archive this product? Historical order records will be preserved.')) return;
    try {
      const res = await adminFetch(`/api/admin/products/${id}`, { method: 'DELETE' });
      if (res.ok) {
        showNotice('Product archived successfully.');
        loadAllData();
      }
    } catch {
      showNotice('Failed to archive product');
    }
  };

  // Retry order fulfillment
  const handleRetryFulfillment = async (orderId: string) => {
    showNotice('Re-dispatching order to supplier fulfillment connector...');
    try {
      const res = await adminFetch(`/api/admin/orders/${orderId}/retry-fulfillment`, { method: 'POST' });
      await res.json();
      showNotice('Fulfillment job processed.');
      loadAllData();
    } catch (err: any) {
      showNotice('Retry failed: ' + err.message);
    }
  };

  // Update order status
  const handleUpdateOrderStatus = async (orderId: string, orderStatus: string, paymentStatus: string) => {
    try {
      const res = await adminFetch(`/api/admin/orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderStatus, paymentStatus })
      });
      if (res.ok) {
        showNotice('Order status updated.');
        loadAllData();
      }
    } catch {
      showNotice('Failed to update status');
    }
  };

  // Save Store Master Settings
  const handleSaveStoreSettings = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSavingSettings(true);
    try {
      const res = await adminFetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(storeSettings)
      });
      const data = await res.json();
      if (res.ok) {
        showNotice('স্টোর সেটিংস সফলভাবে সংরক্ষিত হয়েছে!');
        setStoreSettings(data.settings);
        window.dispatchEvent(new Event('vf_settings_updated'));
      } else {
        showNotice(data.error || 'Failed to save settings');
      }
    } catch (err: any) {
      showNotice('Save error: ' + err.message);
    } finally {
      setIsSavingSettings(false);
    }
  };

  // Coupons Management Handlers
  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;
    try {
      const res = await adminFetch('/api/admin/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: newCouponCode.trim(),
          discountType: newCouponType,
          value: Number(newCouponValue),
          minOrderAmount: Number(newCouponMin),
          active: true,
          maxUses: 1000
        })
      });
      const data = await res.json();
      if (res.ok) {
        showNotice(`কুপন কোড ${data.coupon.code} তৈরি হয়েছে!`);
        setNewCouponCode('');
        loadAllData();
      } else {
        showNotice(data.error || 'Failed to create coupon');
      }
    } catch (err: any) {
      showNotice('Coupon error: ' + err.message);
    }
  };

  const handleToggleCoupon = async (couponId: string, currentActive: boolean) => {
    try {
      const res = await adminFetch(`/api/admin/coupons/${couponId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: !currentActive })
      });
      if (res.ok) {
        showNotice('কুপন স্ট্যাটাস আপডেট হয়েছে!');
        loadAllData();
      }
    } catch (err: any) {
      showNotice('Toggle failed: ' + err.message);
    }
  };

  const handleDeleteCoupon = async (couponId: string) => {
    if (!confirm('Are you sure you want to delete this coupon?')) return;
    try {
      const res = await adminFetch(`/api/admin/coupons/${couponId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        showNotice('কুপন মুছে ফেলা হয়েছে!');
        loadAllData();
      }
    } catch (err: any) {
      showNotice('Delete failed: ' + err.message);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col text-left">
      
      {/* Toast Notice */}
      {actionNotice && (
        <div className="fixed top-4 right-4 z-50 bg-[#0f172a] text-white px-4 py-3 rounded-xl border border-[#c29b38] shadow-2xl text-xs flex items-center gap-2 animate-in fade-in duration-150">
          <Activity className="w-4 h-4 text-[#c29b38]" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Top Admin Navbar */}
      <header className="bg-slate-950 border-b border-slate-800 px-3 sm:px-6 py-2.5 sm:py-3.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 sm:gap-4">
          <button
            onClick={onReturnToStore}
            className="text-base sm:text-lg font-serif font-bold text-white tracking-tight flex items-center gap-1.5 sm:gap-2 hover:opacity-90 cursor-pointer"
          >
            <span className="truncate max-w-[130px] sm:max-w-none">{storeSettings.storeName || 'VELRO FASHION'}</span>
            <span className="text-[9px] sm:text-[10px] font-mono bg-slate-800 text-[#c29b38] px-1.5 sm:px-2 py-0.5 rounded border border-slate-700">
              ADMIN
            </span>
          </button>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-4 text-xs font-mono">
          <div className="hidden lg:flex items-center gap-2 text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>Signed in: <strong className="text-white">{adminUsername}</strong></span>
          </div>

          <button
            onClick={() => setShowPasswordChangeModal(true)}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 p-1 sm:p-1.5 rounded hover:bg-slate-800 cursor-pointer"
            title="Change Admin Password"
          >
            <Lock className="w-3.5 h-3.5 text-[#c29b38]" />
            <span className="hidden sm:inline">Password</span>
          </button>

          <button
            onClick={onReturnToStore}
            className="px-2 sm:px-3 py-1 sm:py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors cursor-pointer text-[11px] sm:text-xs"
          >
            Storefront
          </button>

          <button
            onClick={onLogout}
            className="px-2 sm:px-3 py-1 sm:py-1.5 bg-rose-950/80 hover:bg-rose-900 text-rose-300 rounded-lg transition-colors flex items-center gap-1 cursor-pointer border border-rose-800 text-[11px] sm:text-xs"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      {/* Main Admin Navigation Bar */}
      <div className="bg-slate-950/70 border-b border-slate-800 px-2 sm:px-6 py-2 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-1.5 sm:gap-2 text-xs font-medium min-w-max">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 sm:px-3.5 rounded-lg transition-colors flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
              activeTab === 'overview' ? 'bg-[#c29b38] text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Overview &amp; KPIs</span>
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`px-3 py-1.5 sm:px-3.5 rounded-lg transition-colors flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
              activeTab === 'products' ? 'bg-[#c29b38] text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Package className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Products (Gallery/Color/Size)</span>
          </button>

          <button
            onClick={() => setActiveTab('dropshipping')}
            className={`px-3 py-1.5 sm:px-3.5 rounded-lg transition-colors flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
              activeTab === 'dropshipping' ? 'bg-[#c29b38] text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>ShopBase BD (shopbasebd.com)</span>
          </button>

          <button
            onClick={() => setActiveTab('facebook')}
            className={`px-3 py-1.5 sm:px-3.5 rounded-lg transition-colors flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
              activeTab === 'facebook' ? 'bg-[#c29b38] text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Share2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Facebook Page &amp; Meta Shop</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3 py-1.5 sm:px-3.5 rounded-lg transition-colors flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
              activeTab === 'settings' ? 'bg-[#c29b38] text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Store Settings (সেটিংস)</span>
          </button>

          <button
            onClick={() => setActiveTab('sql')}
            className={`px-3 py-1.5 sm:px-3.5 rounded-lg transition-colors flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
              activeTab === 'sql' ? 'bg-[#c29b38] text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Database className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>SQL Database Console</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-3 py-1.5 sm:px-3.5 rounded-lg transition-colors flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
              activeTab === 'orders' ? 'bg-[#c29b38] text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Orders &amp; Shipments</span>
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`px-3 py-1.5 sm:px-3.5 rounded-lg transition-colors flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
              activeTab === 'payments' ? 'bg-[#c29b38] text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Gateways (bKash/Nagad)</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3 py-1.5 sm:px-3.5 rounded-lg transition-colors flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
              activeTab === 'audit' ? 'bg-[#c29b38] text-slate-950 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Security &amp; Audit</span>
          </button>
        </div>
      </div>

      {/* Main Body Content */}
      <main className="flex-1 p-3 sm:p-6 pb-28 sm:pb-12 max-w-7xl w-full mx-auto space-y-4 sm:space-y-6">
        
        {/* OVERVIEW & KPIS */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-2">
                <span className="text-xs font-mono uppercase text-slate-400">Total Sales (Verified)</span>
                <p className="text-2xl font-bold font-mono text-white tabular-nums">
                  ৳ {(stats?.totalSales || 0).toLocaleString('en-BD')}
                </p>
                <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-mono">
                  <TrendingUp className="w-3 h-3" />
                  <span>BDT Commercial Volume</span>
                </span>
              </div>

              <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-2">
                <span className="text-xs font-mono uppercase text-slate-400">Estimated Net Profit</span>
                <p className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                  ৳ {(stats?.estimatedProfit || 0).toLocaleString('en-BD')}
                </p>
                <span className="text-[11px] text-slate-400 font-mono">
                  Revenue - Supplier Cost
                </span>
              </div>

              <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-2">
                <span className="text-xs font-mono uppercase text-slate-400">Total Orders</span>
                <p className="text-2xl font-bold font-mono text-white tabular-nums">
                  {stats?.totalOrders || 0}
                </p>
                <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                  <span className="text-amber-400">{stats?.pendingOrders || 0} Pending</span>
                  <span>•</span>
                  <span className="text-emerald-400">{stats?.paidOrders || 0} Paid</span>
                </div>
              </div>

              <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-2">
                <span className="text-xs font-mono uppercase text-slate-400">SQL Tables Live</span>
                <p className="text-2xl font-bold font-mono text-[#c29b38] tabular-nums">
                  {sqlTables.length || 9} Tables
                </p>
                <span className="text-[11px] text-emerald-400 font-mono">
                  SQLite Engine Active
                </span>
              </div>
            </div>

            {/* Quick Actions & Live Health */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2 bg-slate-800/60 border border-slate-700 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-700/80 pb-3">
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                    <Activity className="w-4 h-4 text-[#c29b38]" />
                    <span>Connected Sourcing &amp; Marketing Platforms</span>
                  </h3>
                  <button
                    onClick={handleSyncAll}
                    className="px-3 py-1.5 bg-[#0f172a] hover:bg-slate-900 text-xs font-mono text-slate-300 rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Sync All Now</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {/* ShopBase BD Card */}
                  <div className="p-3 bg-slate-900/80 border border-[#c29b38]/50 rounded-xl space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white">ShopBase BD (https://shopbasebd.com/)</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded uppercase font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        ACTIVE
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300">Dhaka Central Warehouse • 24h Dispatch • Steadfast Logistics</p>
                    <div className="pt-1 flex items-center justify-between text-[11px] font-mono text-[#c29b38]">
                      <span>Website: shopbasebd.com</span>
                      <button onClick={() => setShopbaseModalOpen(true)} className="hover:underline cursor-pointer">Settings &rarr;</button>
                    </div>
                  </div>

                  {/* Facebook Page Card */}
                  <div className="p-3 bg-slate-900/80 border border-blue-500/50 rounded-xl space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white">Facebook Page &amp; Meta Shop</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded uppercase font-bold bg-blue-950 text-blue-300 border border-blue-800">
                        CONNECTED
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300">Page: {facebookSettings.pageName} • Live Messenger Chat • Catalog Feed</p>
                    <div className="pt-1 flex items-center justify-between text-[11px] font-mono text-blue-400">
                      <span>Pixel: {facebookSettings.pixelId}</span>
                      <button onClick={() => setActiveTab('facebook')} className="hover:underline cursor-pointer">Manage &rarr;</button>
                    </div>
                  </div>

                  {/* CJdropshipping */}
                  <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-white">CJdropshipping Official</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded uppercase font-bold bg-emerald-950 text-emerald-300">
                        CONNECTED
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">Global line sourcing &amp; barcode manifest generation.</p>
                  </div>

                  {/* SQL Relational Database */}
                  <div className="p-3 bg-slate-900/80 border border-emerald-500/40 rounded-xl space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white">SQL Database Engine</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded uppercase font-bold bg-emerald-950 text-emerald-300">
                        SQLITE WASM
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">Relational schemas, foreign keys &amp; instant SQL query console.</p>
                    <div className="pt-1 flex justify-end text-[11px] font-mono text-emerald-400">
                      <button onClick={() => setActiveTab('sql')} className="hover:underline cursor-pointer">Open Console &rarr;</button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Low stock alerts */}
              <div className="bg-slate-800/60 border border-slate-700 rounded-2xl p-5 space-y-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-700/80 pb-3">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Inventory Alerts</span>
                </h3>
                <div className="space-y-2 text-xs">
                  {products.filter(p => p.stockQuantity < 30).slice(0, 4).map((p) => (
                    <div key={p.id} className="p-2.5 bg-slate-900/60 border border-slate-800 rounded-lg flex items-center justify-between">
                      <div>
                        <p className="font-medium text-slate-200 line-clamp-1">{p.title}</p>
                        <p className="text-[10px] font-mono text-slate-500">{p.sku} • {p.supplierName}</p>
                      </div>
                      <span className="font-mono text-amber-400 font-bold text-xs bg-amber-950/60 px-2 py-0.5 rounded border border-amber-900">
                        {p.stockQuantity} Left
                      </span>
                    </div>
                  ))}
                  {products.filter(p => p.stockQuantity < 30).length === 0 && (
                    <p className="text-slate-500 text-xs py-4 text-center">All inventory healthy above safety threshold.</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PRODUCTS & INVENTORY */}
        {activeTab === 'products' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
              <div>
                <h2 className="text-xl font-bold text-white">Product Catalog Management</h2>
                <p className="text-slate-400 text-xs">
                  গ্যালারি ফটো আপলোড, ডাইনামিক কালার সোয়াচ এবং সাইজ মেট্রিক্স পরিচালনা করুন।
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setEditingProduct({
                      title: '',
                      titleBn: '',
                      category: 'Panjabi and Kurta',
                      costPrice: 850,
                      sellingPrice: 1750,
                      stockQuantity: 50,
                      sizes: ['40', '42', '44'],
                      colors: ['Royal Navy', 'Jet Black'],
                      colorItems: [
                        { name: 'Royal Navy', hex: '#1e3a8a', inStock: true },
                        { name: 'Jet Black', hex: '#000000', inStock: true }
                      ],
                      sizeItems: [
                        { size: '40', inStock: true },
                        { size: '42', inStock: true },
                        { size: '44', inStock: true }
                      ],
                      images: [
                        'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=80'
                      ],
                      variants: [
                        { id: 'v-1', sku: 'VF-NEW-NVY-40', size: '40', color: 'Royal Navy', stock: 25, costPrice: 850, price: 1750 },
                        { id: 'v-2', sku: 'VF-NEW-NVY-42', size: '42', color: 'Royal Navy', stock: 25, costPrice: 850, price: 1750 },
                        { id: 'v-3', sku: 'VF-NEW-BLK-40', size: '40', color: 'Jet Black', stock: 25, costPrice: 850, price: 1750 },
                        { id: 'v-4', sku: 'VF-NEW-BLK-42', size: '42', color: 'Jet Black', stock: 25, costPrice: 850, price: 1750 }
                      ],
                      status: 'published'
                    });
                    setProductModalOpen(true);
                  }}
                  className="px-4 py-2 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>নতুন পোশাক যোগ করুন (Add Apparel)</span>
                </button>
              </div>
            </div>

            {/* Mobile Product Cards */}
            <div className="md:hidden space-y-3">
              {products.map((p) => (
                <div key={p.id} className="bg-slate-800/90 border border-slate-700/80 rounded-xl p-3.5 space-y-3 shadow-md">
                  <div className="flex gap-3">
                    <div className="relative w-16 h-20 rounded-lg overflow-hidden bg-slate-900 border border-slate-700 shrink-0">
                      <img src={p.images[0]} alt="" className="w-full h-full object-cover" />
                      {p.images.length > 1 && (
                        <span className="absolute bottom-0 right-0 bg-black/80 text-[8px] text-white px-1 font-mono">
                          +{p.images.length - 1}
                        </span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-white text-sm line-clamp-1">{p.title}</h4>
                      <p className="text-[11px] text-slate-400 line-clamp-1">{p.titleBn || p.category}</p>
                      <p className="text-[10px] font-mono text-slate-500 mt-0.5">SKU: {p.sku} • {p.supplierName}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-white font-bold text-xs">৳ {p.salePrice || p.sellingPrice}</span>
                        <span className="text-slate-400 text-[10px] font-mono">Cost: ৳ {p.costPrice}</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Colors & Sizes Chips */}
                  <div className="flex flex-wrap items-center gap-1 text-[10px] pt-1 border-t border-slate-700/50">
                    <span className="text-slate-400 mr-1 font-mono">Sizes:</span>
                    {p.sizes?.map((s, idx) => (
                      <span key={idx} className="bg-slate-900 px-1.5 py-0.5 rounded text-[#c29b38] font-bold font-mono">
                        {s}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-700/60 text-xs">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      p.stockQuantity > 20 ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      {p.stockQuantity} pcs stock
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => { setEditingProduct(p); setProductModalOpen(true); }}
                        className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-xs flex items-center gap-1 cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5 text-[#c29b38]" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(p.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-400 cursor-pointer"
                        title="Archive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block bg-slate-800/80 border border-slate-700 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900 text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="p-3">Gallery Image</th>
                      <th className="p-3">Title &amp; Category</th>
                      <th className="p-3">Colors Available</th>
                      <th className="p-3">Sizes Available</th>
                      <th className="p-3">Total Stock</th>
                      <th className="p-3">Cost Price</th>
                      <th className="p-3">Selling Price</th>
                      <th className="p-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {products.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-800/50">
                        <td className="p-3">
                          <div className="relative group w-12 h-14 rounded-lg overflow-hidden bg-slate-900 border border-slate-700">
                            <img src={p.images[0]} alt="" className="w-full h-full object-cover" />
                            {p.images.length > 1 && (
                              <span className="absolute bottom-0 right-0 bg-black/80 text-[9px] text-white px-1 font-mono">
                                +{p.images.length - 1}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-3 font-sans">
                          <span className="font-bold text-white block text-sm">{p.title}</span>
                          <span className="text-[11px] text-slate-400">{p.titleBn || p.category}</span>
                          <span className="text-[10px] text-slate-500 font-mono block">SKU: {p.sku} • {p.supplierName}</span>
                        </td>
                        <td className="p-3">
                          <div className="flex flex-wrap gap-1 max-w-xs">
                            {p.colors?.map((c, idx) => (
                              <span key={idx} className="bg-slate-900 border border-slate-700 text-slate-200 text-[10px] px-1.5 py-0.5 rounded">
                                {c}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="flex flex-wrap gap-1 max-w-xs">
                            {p.sizes?.map((s, idx) => (
                              <span key={idx} className="bg-slate-900 border border-slate-700 text-[#c29b38] text-[10px] px-1.5 py-0.5 rounded font-bold">
                                {s}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="p-3 font-bold text-emerald-400">
                          {p.stockQuantity} pcs
                        </td>
                        <td className="p-3 text-slate-400">৳ {p.costPrice}</td>
                        <td className="p-3 font-bold text-white">৳ {p.salePrice || p.sellingPrice}</td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => { setEditingProduct(p); setProductModalOpen(true); }}
                              className="p-1 hover:text-[#c29b38] transition-colors cursor-pointer"
                              title="Edit Images, Colors, Sizes"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(p.id)}
                              className="p-1 hover:text-rose-400 transition-colors cursor-pointer"
                              title="Archive"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* DROPSHIPPING & SHOPBASE BD HUB */}
        {activeTab === 'dropshipping' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
              <div>
                <p className="text-xs font-mono text-[#c29b38]">
                  Automated Dropshipping Engine • Bangladesh Hub
                </p>
                <h2 className="text-xl font-bold text-white mt-1">
                  ShopBase BD (https://shopbasebd.com/) &amp; Supplier Hub
                </h2>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShopbaseModalOpen(true)}
                  className="px-4 py-2 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Connect shopbasebd.com Account</span>
                </button>
                <button
                  onClick={handleSyncAll}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer border border-slate-700"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Sync All</span>
                </button>
              </div>
            </div>

            {/* Official ShopBase BD Hero Card */}
            <div className="p-6 bg-gradient-to-r from-slate-950 via-slate-900 to-[#0f172a] border border-[#c29b38] rounded-2xl shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-2 max-w-2xl">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse"></span>
                  <h3 className="text-lg font-bold text-white font-serif">
                    ShopBase Bangladesh (https://shopbasebd.com/)
                  </h3>
                  <span className="bg-[#c29b38] text-slate-950 px-2 py-0.5 rounded font-bold text-[10px] font-mono">
                    LIVE CONNECTION
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  অফিসিয়াল রিসেলার প্ল্যাটফর্ম <strong className="text-white font-mono">https://shopbasebd.com/</strong> থেকে VELRO FASHION-এ পোশাক প্রোডাক্ট সরাসরি ইমপোর্ট ও অটোমেটিক Steadfast কুরিয়ার ডেলিভারি সংযুক্ত।
                </p>
                <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-1">
                  <span>ওয়েবসাইট: <a href="https://shopbasebd.com/" target="_blank" rel="noreferrer" className="text-[#c29b38] hover:underline">https://shopbasebd.com/</a></span>
                  <span>•</span>
                  <span>স্টোর নাম: VELRO FASHION BD</span>
                  <span>•</span>
                  <span>স্টক সিঙ্ক: সক্রিয়</span>
                  <span>•</span>
                  <span>কুরিয়ার: Steadfast &amp; Pathao</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2.5 shrink-0">
                <button
                  onClick={() => {
                    setSelectedSupplierForImport('int-shopbase');
                    setDropshipSubtab('product_import');
                    handleFetchSupplierProducts();
                  }}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-2 font-mono"
                >
                  <Package className="w-4 h-4" />
                  <span>Import Products from shopbasebd.com</span>
                </button>
                <button
                  onClick={() => setShopbaseModalOpen(true)}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 cursor-pointer font-mono"
                >
                  Configure API
                </button>
              </div>
            </div>

            {/* 10 Subtabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-800 text-xs font-mono">
              {[
                { id: 'connected_apps', label: '1. Connected Apps' },
                { id: 'available', label: '2. Available Integrations' },
                { id: 'supplier_accounts', label: '3. Supplier Accounts' },
                { id: 'product_import', label: '4. Product Import' },
                { id: 'imported_products', label: '5. Imported Products' },
                { id: 'order_sync', label: '6. Order Synchronization' },
                { id: 'fulfillment', label: '7. Fulfillment' },
                { id: 'shipment_tracking', label: '8. Shipment Tracking' },
                { id: 'sync_logs', label: '9. Sync Logs' },
                { id: 'integration_settings', label: '10. Integration Settings' },
              ].map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => setDropshipSubtab(sub.id as any)}
                  className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                    dropshipSubtab === sub.id
                      ? 'bg-slate-800 text-[#c29b38] font-bold border border-slate-700'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>

            {/* PRODUCT IMPORT SUBTAB */}
            {dropshipSubtab === 'product_import' && (
              <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6 space-y-6 text-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-700 pb-4">
                  <div>
                    <h3 className="text-base font-bold text-white">Live Supplier Product Discovery</h3>
                    <p className="text-slate-400 text-xs">https://shopbasebd.com/ ও অন্যান্য কানেক্টেড ক্যাটালগ ব্রাউজ করুন</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <select
                      value={selectedSupplierForImport}
                      onChange={(e) => setSelectedSupplierForImport(e.target.value)}
                      className="px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                    >
                      {integrations.map((i) => (
                        <option key={i.id} value={i.id}>{i.name}</option>
                      ))}
                    </select>

                    <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-700 font-mono">
                      <span>Markup:</span>
                      <input
                        type="number"
                        value={markupPct}
                        onChange={(e) => setMarkupPct(parseInt(e.target.value) || 0)}
                        className="w-14 bg-slate-800 text-white px-1.5 py-0.5 rounded text-center"
                      />
                      <span>%</span>
                    </div>

                    <button
                      onClick={handleFetchSupplierProducts}
                      disabled={importLoading}
                      className="px-4 py-2 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-lg font-mono cursor-pointer"
                    >
                      {importLoading ? 'Discovering...' : 'Fetch Catalog'}
                    </button>
                  </div>
                </div>

                {previewProducts.length === 0 ? (
                  <div className="py-12 text-center text-slate-500 space-y-2">
                    <p>Click "Fetch Catalog" to load available products from selected connector.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {previewProducts.map((p, idx) => {
                      const cost = p.supplierCostBdt || 500;
                      const proposedPrice = Math.round(cost * (1 + markupPct / 100));
                      const estimatedMargin = proposedPrice - cost;

                      return (
                        <div key={idx} className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl flex gap-4">
                          <img src={p.images[0]} alt="" className="w-24 h-28 object-cover rounded-lg bg-slate-800 shrink-0" />
                          <div className="flex-1 space-y-2">
                            <h4 className="font-bold text-white text-sm line-clamp-1">{p.title}</h4>
                            <p className="text-[11px] text-slate-400 line-clamp-2">{p.description}</p>
                            
                            <div className="flex items-center gap-3 font-mono text-[11px]">
                              <span>Cost: <strong>৳ {cost}</strong></span>
                              <span>Proposed Price: <strong className="text-emerald-400">৳ {proposedPrice}</strong></span>
                              <span>Margin: <strong className="text-[#c29b38]">+৳ {estimatedMargin}</strong></span>
                            </div>

                            <button
                              onClick={() => handleImportProduct(p)}
                              className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg font-mono font-bold text-xs cursor-pointer"
                            >
                              Import &amp; Publish to Storefront
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* DEFAULT SUBTAB: CONNECTED APPS */}
            {dropshipSubtab !== 'product_import' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {integrations.map((int) => (
                  <div key={int.id} className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 space-y-4 text-xs">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="text-sm font-bold text-white">{int.name}</h4>
                        <span className="font-mono text-slate-400 text-[11px]">Type: {int.type}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded font-mono text-[10px] uppercase font-bold ${
                        int.status === 'connected' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                        int.status === 'action_required' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-slate-800 text-slate-400'
                      }`}>
                        {int.status}
                      </span>
                    </div>

                    <p className="text-slate-300 text-xs bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                      {int.statusMessage}
                    </p>

                    <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-400 bg-slate-900/40 p-3 rounded-lg">
                      <div>Synced Items: <strong className="text-white">{int.stats.productsCount}</strong></div>
                      <div>Active Orders: <strong className="text-white">{int.stats.activeOrdersCount}</strong></div>
                      <div>Auto-Import: <strong className="text-white">{int.settings.autoImport ? 'Enabled' : 'Disabled'}</strong></div>
                      <div>Markup: <strong className="text-white">{int.settings.defaultMarkupPercentage}%</strong></div>
                    </div>

                    <div className="pt-2 flex items-center gap-2">
                      <button
                        onClick={() => handleTestIntegration(int.id)}
                        className="px-3 py-1.5 bg-slate-900 hover:bg-slate-950 text-slate-200 border border-slate-700 rounded-lg font-mono text-xs cursor-pointer"
                      >
                        Test Connection
                      </button>
                      <button
                        onClick={() => {
                          setSelectedSupplierForImport(int.id);
                          setDropshipSubtab('product_import');
                          handleFetchSupplierProducts();
                        }}
                        className="px-3 py-1.5 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-lg font-mono text-xs cursor-pointer"
                      >
                        Import Products
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* FACEBOOK PAGE & META COMMERCE CONNECTION */}
        {activeTab === 'facebook' && (
          <div className="space-y-6 text-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
              <div>
                <h2 className="text-xl font-bold text-white">Facebook Page &amp; Meta Commerce Connection</h2>
                <p className="text-slate-400">ফেসবুক পেজ লিঙ্ক, অটোমেটিক ক্যাটালগ সিঙ্ক এবং মেসেঞ্জার চ্যাট সেটআপ</p>
              </div>
              <button
                onClick={handleSyncFacebookCatalog}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-md font-mono"
              >
                <Share2 className="w-4 h-4" />
                <span>Sync Products to Facebook Catalog</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Left Form: Page Credentials */}
              <div className="md:col-span-7 bg-slate-800/80 border border-slate-700 rounded-2xl p-6 space-y-5">
                <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700 pb-3">
                  <Share2 className="w-4 h-4 text-blue-400" />
                  <span>Facebook Page Details</span>
                </h3>

                <form onSubmit={handleSaveFacebookSettings} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-slate-400 mb-1">Facebook Page Name *</label>
                      <input
                        type="text"
                        required
                        value={facebookSettings.pageName || ''}
                        onChange={(e) => setFacebookSettings({ ...facebookSettings, pageName: e.target.value })}
                        placeholder="e.g. VELRO FASHION BD"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Facebook Page ID / Username *</label>
                      <input
                        type="text"
                        required
                        value={facebookSettings.pageId || ''}
                        onChange={(e) => setFacebookSettings({ ...facebookSettings, pageId: e.target.value })}
                        placeholder="e.g. velrofashion.bd"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Facebook Page URL</label>
                    <input
                      type="url"
                      value={facebookSettings.pageUrl || ''}
                      onChange={(e) => setFacebookSettings({ ...facebookSettings, pageUrl: e.target.value })}
                      placeholder="https://facebook.com/velrofashion.bd"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Messenger Link (m.me URL)</label>
                    <input
                      type="url"
                      value={facebookSettings.messengerUrl || ''}
                      onChange={(e) => setFacebookSettings({ ...facebookSettings, messengerUrl: e.target.value })}
                      placeholder="https://m.me/velrofashion.bd"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Meta Pixel ID (for tracking purchases)</label>
                    <input
                      type="text"
                      value={facebookSettings.pixelId || ''}
                      onChange={(e) => setFacebookSettings({ ...facebookSettings, pixelId: e.target.value })}
                      placeholder="e.g. 129481928419284"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                    />
                  </div>

                  <div className="space-y-2 pt-2">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!facebookSettings.messengerChatEnabled}
                        onChange={(e) => setFacebookSettings({ ...facebookSettings, messengerChatEnabled: e.target.checked })}
                      />
                      <span>Show "Chat on Facebook Messenger" button on storefront</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!facebookSettings.catalogSyncEnabled}
                        onChange={(e) => setFacebookSettings({ ...facebookSettings, catalogSyncEnabled: e.target.checked })}
                      />
                      <span>Enable Meta Commerce Manager Automatic Product Feed Sync</span>
                    </label>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg cursor-pointer transition-colors"
                  >
                    Save Facebook Configuration
                  </button>
                </form>
              </div>

              {/* Right Panel: Catalog Feed & Live Links */}
              <div className="md:col-span-5 space-y-4">
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <ExternalLink className="w-4 h-4 text-emerald-400" />
                    <span>Live Meta Catalog Feed URLs</span>
                  </h3>
                  <p className="text-slate-400 leading-relaxed text-[11px]">
                    Use these endpoints in Facebook Commerce Manager to auto-sync your product inventory to your Facebook Shop and Instagram Store:
                  </p>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2 font-mono text-[11px]">
                    <span className="text-slate-400 block font-bold">Catalog Feed (JSON):</span>
                    <a
                      href="/api/facebook/catalog.json"
                      target="_blank"
                      rel="noreferrer"
                      className="text-blue-400 hover:underline break-all block"
                    >
                      /api/facebook/catalog.json
                    </a>
                  </div>

                  <div className="pt-2">
                    <a
                      href={facebookSettings.messengerUrl || `https://m.me/${facebookSettings.pageId}`}
                      target="_blank"
                      rel="noreferrer"
                      className="w-full py-2.5 bg-[#0f172a] hover:bg-slate-900 border border-slate-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-colors"
                    >
                      <MessageCircle className="w-4 h-4 text-blue-400" />
                      <span>Test Messenger Chat Link</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SQL RELATIONAL DATABASE CONSOLE */}
        {activeTab === 'sql' && (
          <div className="space-y-6 text-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-emerald-400" />
                  <span>SQL Relational Database Console</span>
                </h2>
                <p className="text-slate-400">
                  SQLite WASM ইঞ্জিন • রিয়েল-টাইম রিলেশনাল কুয়েরি এবং টেবিল অ্যানালাইসিস
                </p>
              </div>
              <button
                onClick={handleExecuteSql}
                disabled={sqlRunning}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-md font-mono"
              >
                <Code2 className="w-4 h-4" />
                <span>{sqlRunning ? 'Executing...' : 'Run Query (F5)'}</span>
              </button>
            </div>

            {/* Tables Quick Summary Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
              {sqlTables.map((t) => (
                <button
                  key={t.name}
                  onClick={() => {
                    setSqlQuery(`SELECT * FROM ${t.name} LIMIT 15;`);
                    setTimeout(() => handleExecuteSql(), 50);
                  }}
                  className="p-3 bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded-xl text-left transition-colors cursor-pointer"
                >
                  <span className="font-mono text-slate-300 block truncate">{t.name}</span>
                  <span className="text-emerald-400 font-mono font-bold text-[11px]">{t.rowCount} rows</span>
                </button>
              ))}
            </div>

            {/* SQL Query Editor */}
            <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 space-y-3">
              <div className="flex justify-between items-center">
                <span className="font-bold text-slate-300 font-mono">SQL Query Editor:</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setSqlQuery('SELECT id, sku, title, selling_price, stock_quantity FROM products LIMIT 10;')}
                    className="text-[10px] font-mono text-[#c29b38] hover:underline cursor-pointer"
                  >
                    [Products]
                  </button>
                  <button
                    onClick={() => setSqlQuery('SELECT id, order_number, customer_name, total, payment_method, order_status FROM orders LIMIT 10;')}
                    className="text-[10px] font-mono text-[#c29b38] hover:underline cursor-pointer"
                  >
                    [Orders]
                  </button>
                  <button
                    onClick={() => setSqlQuery('SELECT * FROM product_variants LIMIT 10;')}
                    className="text-[10px] font-mono text-[#c29b38] hover:underline cursor-pointer"
                  >
                    [Variants]
                  </button>
                </div>
              </div>
              <textarea
                rows={4}
                value={sqlQuery}
                onChange={(e) => setSqlQuery(e.target.value)}
                className="w-full font-mono text-xs p-3 bg-slate-950 border border-slate-800 rounded-xl text-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            {/* SQL Execution Output */}
            {sqlError && (
              <div className="p-4 bg-rose-950/60 border border-rose-800 rounded-xl text-rose-300 font-mono text-xs">
                <strong>SQL Error:</strong> {sqlError}
              </div>
            )}

            {sqlResults && (
              <div className="bg-slate-800/80 border border-slate-700 rounded-2xl overflow-hidden space-y-2 p-4">
                <div className="flex justify-between items-center text-xs font-mono text-slate-400 pb-2 border-b border-slate-700">
                  <span>Returned {sqlResults.rowCount} rows</span>
                  <span>Executed: {new Date(sqlResults.executedAt).toLocaleTimeString('en-GB')}</span>
                </div>
                {sqlResults.rows && sqlResults.rows.length > 0 ? (
                  <div className="overflow-x-auto max-h-96">
                    <table className="w-full text-left font-mono text-[11px]">
                      <thead className="bg-slate-900 text-slate-300 sticky top-0">
                        <tr>
                          {Object.keys(sqlResults.rows[0]).map((col) => (
                            <th key={col} className="p-2.5 border-b border-slate-700 whitespace-nowrap">{col}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {sqlResults.rows.map((row: any, rIdx: number) => (
                          <tr key={rIdx} className="hover:bg-slate-900/60">
                            {Object.values(row).map((val: any, cIdx: number) => (
                              <td key={cIdx} className="p-2.5 text-slate-300 whitespace-nowrap max-w-xs truncate">
                                {typeof val === 'object' ? JSON.stringify(val) : String(val ?? '')}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-slate-500 py-6 text-center font-mono">0 rows returned.</p>
                )}
              </div>
            )}
          </div>
        )}

        {/* ORDERS & SHIPMENTS */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center pb-4 border-b border-slate-800">
              <div>
                <h2 className="text-xl font-bold text-white">Master Customer Orders</h2>
                <p className="text-slate-400 text-xs">Verify payments, assign tracking numbers, and view multi-supplier routing.</p>
              </div>
            </div>

            {/* Mobile Responsive Order Cards */}
            <div className="md:hidden space-y-3">
              {orders.map((o) => (
                <div key={o.id} className="bg-slate-800/90 border border-slate-700/80 rounded-xl p-3.5 space-y-3 shadow-md text-xs">
                  <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                    <div>
                      <span className="font-bold text-white font-mono text-sm block">{o.orderNumber}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(o.createdAt || Date.now()).toLocaleDateString('en-GB')}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-emerald-400 font-mono text-sm block">
                        ৳ {o.total.toLocaleString('en-BD')}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {o.items?.length || 1} আইটেম
                      </span>
                    </div>
                  </div>

                  {/* Customer Info & Direct Call / WhatsApp */}
                  <div className="bg-slate-900/70 p-2.5 rounded-lg border border-slate-800 space-y-1">
                    <p className="font-bold text-white">{o.customerName}</p>
                    <p className="text-[11px] text-slate-300 font-mono">{o.customerPhone} • {o.district}</p>
                    <p className="text-[10px] text-slate-400 truncate">{o.address}</p>
                    <div className="flex items-center gap-2 pt-1.5">
                      <a
                        href={`tel:${o.customerPhone}`}
                        className="px-2 py-1 bg-blue-950/80 hover:bg-blue-900 text-blue-300 rounded border border-blue-800 text-[10px] flex items-center gap-1 font-mono"
                      >
                        <Phone className="w-3 h-3 text-blue-400" />
                        <span>Call</span>
                      </a>
                      <a
                        href={`https://wa.me/${o.customerPhone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="px-2 py-1 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 rounded border border-emerald-800 text-[10px] flex items-center gap-1 font-mono"
                      >
                        <MessageCircle className="w-3 h-3 text-emerald-400" />
                        <span>WhatsApp</span>
                      </a>
                    </div>
                  </div>

                  {/* Status & Payment Controls */}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5 font-mono">পেমেন্ট:</label>
                      <button
                        type="button"
                        onClick={() => handleUpdateOrderStatus(
                          o.id, 
                          o.orderStatus, 
                          o.paymentStatus === 'verified' ? 'pending' : 'verified'
                        )}
                        className={`w-full py-1.5 px-2 rounded text-[10px] uppercase font-bold text-center cursor-pointer border ${
                          o.paymentStatus === 'verified' ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-amber-950 text-amber-300 border-amber-800'
                        }`}
                      >
                        {o.paymentMethod} • {o.paymentStatus}
                      </button>
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5 font-mono">অর্ডার স্ট্যাটাস:</label>
                      <select
                        value={o.orderStatus}
                        onChange={(e) => handleUpdateOrderStatus(o.id, e.target.value, o.paymentStatus)}
                        className="w-full bg-slate-900 text-slate-200 border border-slate-700 rounded py-1 px-1.5 text-[11px]"
                      >
                        <option value="confirmed">Confirmed</option>
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-700/60">
                    <span className="text-[10px] text-slate-400 font-mono">
                      Tracking: <strong className="text-slate-200">{o.trackingNumber || 'Pending'}</strong>
                    </span>
                    <button
                      type="button"
                      onClick={() => setSelectedOrder(o)}
                      className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-white rounded text-[11px] font-mono cursor-pointer"
                    >
                      Invoice / Details
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Orders Table */}
            <div className="hidden md:block bg-slate-800/80 border border-slate-700 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900 text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="p-3">Order #</th>
                      <th className="p-3">Customer</th>
                      <th className="p-3">Items</th>
                      <th className="p-3">Total Amount</th>
                      <th className="p-3">Payment</th>
                      <th className="p-3">Order Status</th>
                      <th className="p-3">Tracking</th>
                      <th className="p-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {orders.map((o) => (
                      <tr key={o.id} className="hover:bg-slate-800/50">
                        <td className="p-3 font-bold text-white">{o.orderNumber}</td>
                        <td className="p-3 font-sans">
                          <span className="font-bold text-white block">{o.customerName}</span>
                          <span className="text-[11px] text-slate-400 font-mono">{o.customerPhone} • {o.district}</span>
                        </td>
                        <td className="p-3 font-sans">{o.items.length} apparel line(s)</td>
                        <td className="p-3 font-bold text-emerald-400">৳ {o.total.toLocaleString('en-BD')}</td>
                        <td className="p-3">
                          <button
                            onClick={() => handleUpdateOrderStatus(
                              o.id, 
                              o.orderStatus, 
                              o.paymentStatus === 'verified' ? 'pending' : 'verified'
                            )}
                            className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold cursor-pointer ${
                              o.paymentStatus === 'verified' ? 'bg-emerald-950 text-emerald-300' : 'bg-amber-950 text-amber-300'
                            }`}
                            title="Click to toggle payment verification"
                          >
                            {o.paymentMethod} • {o.paymentStatus}
                          </button>
                        </td>
                        <td className="p-3">
                          <select
                            value={o.orderStatus}
                            onChange={(e) => handleUpdateOrderStatus(o.id, e.target.value, o.paymentStatus)}
                            className="bg-slate-900 text-slate-200 border border-slate-700 rounded px-2 py-1 text-xs"
                          >
                            <option value="confirmed">Confirmed</option>
                            <option value="processing">Processing</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </td>
                        <td className="p-3 text-slate-300">{o.trackingNumber || 'Pending'}</td>
                        <td className="p-3">
                          <button
                            onClick={() => setSelectedOrder(o)}
                            className="px-2.5 py-1 bg-[#0f172a] hover:bg-slate-900 text-[#c29b38] rounded border border-slate-700 text-xs cursor-pointer"
                          >
                            Invoice / Split
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* PAYMENTS */}
        {activeTab === 'payments' && (
          <div className="space-y-6 text-xs">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white">Bangladesh Payment Gateways Configuration &amp; Testing</h2>
              <p className="text-slate-400">Configure real API credentials or test via automated sandbox simulation.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* bKash */}
              <div className="bg-slate-800/80 border border-slate-700 p-5 rounded-2xl space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-white text-sm flex items-center gap-2">
                    <span className="bg-[#e2136e] text-white px-2 py-0.5 rounded text-[11px] font-bold">bKash</span>
                    <span>Merchant PGW (Tokenized Checkout)</span>
                  </h3>
                  <span className="text-emerald-400 font-mono text-[10px] bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                    SANDBOX ACTIVE
                  </span>
                </div>
                <div className="space-y-2 font-mono text-slate-300">
                  <div>App Key: <span className="text-slate-500">bkash_app_key_velro_sandbox_2026</span></div>
                  <div>Username: <span className="text-slate-500">sandbox_velro_merchant</span></div>
                  <div>Settlement: <span className="text-slate-400">Direct Merchant Wallet</span></div>
                </div>
                <button
                  onClick={() => showNotice('bKash sandbox token refreshed and verified.')}
                  className="px-3 py-1.5 bg-[#e2136e] hover:bg-[#c2105e] text-white rounded-lg font-bold cursor-pointer"
                >
                  Test bKash Token Ping
                </button>
              </div>

              {/* Nagad */}
              <div className="bg-slate-800/80 border border-slate-700 p-5 rounded-2xl space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-white text-sm flex items-center gap-2">
                    <span className="bg-[#f7941d] text-white px-2 py-0.5 rounded text-[11px] font-bold">Nagad</span>
                    <span>Direct Merchant API</span>
                  </h3>
                  <span className="text-emerald-400 font-mono text-[10px] bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                    SANDBOX ACTIVE
                  </span>
                </div>
                <div className="space-y-2 font-mono text-slate-300">
                  <div>Merchant ID: <span className="text-slate-500">68201948102</span></div>
                  <div>Public Key: <span className="text-slate-500">rsa_pkcs8_nagad_pub_key</span></div>
                </div>
                <button
                  onClick={() => showNotice('Nagad endpoint handshake verified.')}
                  className="px-3 py-1.5 bg-[#f7941d] hover:bg-[#d87c12] text-white rounded-lg font-bold cursor-pointer"
                >
                  Test Nagad Connection
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STORE & SYSTEM MASTER SETTINGS */}
        {activeTab === 'settings' && (
          <div className="space-y-6 text-xs pb-16">
            {/* Top Toolbar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                  <Settings className="w-5 h-5 text-[#c29b38]" />
                  <span>Store &amp; System Settings (স্টোর সেটিংস)</span>
                </h2>
                <p className="text-slate-400 text-[11px] sm:text-xs">
                  দোকানের নাম, ডেলিভারি চার্জ, বিকাশ/নগদ নম্বর, ঘোষণা বার এবং কুপন কোড পরিবর্তন করুন।
                </p>
              </div>
              <button
                onClick={() => handleSaveStoreSettings()}
                disabled={isSavingSettings}
                className="px-4 py-2.5 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50 transition-all font-mono"
              >
                <Save className="w-4 h-4" />
                <span>{isSavingSettings ? 'সংরক্ষণ হচ্ছে...' : 'Save All Settings (সংরক্ষণ)'}</span>
              </button>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none text-xs font-mono">
              {[
                { id: 'all', label: 'সকল সেটিংস (All)' },
                { id: 'branding', label: 'ব্র্যান্ড ও ঘোষণা' },
                { id: 'delivery', label: 'ডেলিভারি চার্জ' },
                { id: 'payments', label: 'বিকাশ ও নগদ নম্বর' },
                { id: 'contact', label: 'যোগাযোগ ও হেল্পলাইন' },
                { id: 'social', label: 'সোশ্যাল ও মেটা' },
                { id: 'security', label: 'অ্যাডমিন পাসওয়ার্ড' },
                { id: 'coupons', label: 'কুপন ডিসকাউন্ট' }
              ].map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSettingsCategory(cat.id as any)}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap cursor-pointer transition-all border ${
                    settingsCategory === cat.id
                      ? 'bg-[#c29b38] text-slate-950 font-bold border-[#c29b38] shadow-sm'
                      : 'bg-slate-800 text-slate-300 hover:text-white border-slate-700'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Grid of Settings Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              
              {/* 1. General Brand & Store Info */}
              {(settingsCategory === 'all' || settingsCategory === 'branding') && (
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 sm:p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/80 pb-2.5">
                    <Store className="w-4 h-4 text-[#c29b38]" />
                    <span>স্টোর ব্র্যান্ডিং (Branding)</span>
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">দোকানের নাম (Store Name) *</label>
                      <input
                        type="text"
                        value={storeSettings.storeName || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, storeName: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-medium focus:outline-none focus:ring-1 focus:ring-[#c29b38] text-sm sm:text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">দোকানের বাংলা নাম (বাংলা)</label>
                      <input
                        type="text"
                        value={storeSettings.storeNameBn || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, storeNameBn: e.target.value })}
                        placeholder="ভেলরো ফ্যাশন"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-[#c29b38] text-sm sm:text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">ট্যাগলাইন (বাংলা)</label>
                      <input
                        type="text"
                        value={storeSettings.storeTagline || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, storeTagline: e.target.value })}
                        placeholder="অভিজাত বাংলাদেশী ও সমকালীন ফ্যাশন"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-[#c29b38] text-sm sm:text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">Tagline (English)</label>
                      <input
                        type="text"
                        value={storeSettings.storeTaglineEn || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, storeTaglineEn: e.target.value })}
                        placeholder="e.g. Curated Bangladeshi &amp; Contemporary Fashion"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-[#c29b38] text-sm sm:text-xs"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">মুদ্রা কোড (Currency)</label>
                        <input
                          type="text"
                          value={storeSettings.currency || 'BDT'}
                          onChange={(e) => setStoreSettings({ ...storeSettings, currency: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">প্রতীক (Symbol)</label>
                        <input
                          type="text"
                          value={storeSettings.currencySymbol || '৳'}
                          onChange={(e) => setStoreSettings({ ...storeSettings, currencySymbol: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-center font-bold text-sm sm:text-xs"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">ড্রপশিপ মার্কআপ (%)</label>
                        <input
                          type="number"
                          value={storeSettings.defaultMarkupPercentage ?? 90}
                          onChange={(e) => setStoreSettings({ ...storeSettings, defaultMarkupPercentage: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">সর্বনিম্ন মুনাফা (৳)</label>
                        <input
                          type="number"
                          value={storeSettings.minProfitMarginBdt ?? 400}
                          onChange={(e) => setStoreSettings({ ...storeSettings, minProfitMarginBdt: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 2. Top Announcement Bar */}
              {(settingsCategory === 'all' || settingsCategory === 'branding') && (
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 sm:p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-700/80 pb-2.5">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Bell className="w-4 h-4 text-amber-400" />
                      <span>ঘোষণা বার (Announcement Bar)</span>
                    </h3>
                    <label className="flex items-center gap-2 text-[11px] text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={storeSettings.showAnnouncementBar !== false}
                        onChange={(e) => setStoreSettings({ ...storeSettings, showAnnouncementBar: e.target.checked })}
                        className="rounded"
                      />
                      <span>ব্যানার চালু রাখুন</span>
                    </label>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">ঘোষণা টেক্সট (বাংলা)</label>
                      <textarea
                        rows={2}
                        value={storeSettings.announcementBarText || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, announcementBarText: e.target.value })}
                        placeholder="সারা দেশে হোম ডেলিভারি | COD &amp; bKash Verified"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-[#c29b38] text-sm sm:text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">Banner Text (English)</label>
                      <textarea
                        rows={2}
                        value={storeSettings.announcementBarTextEn || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, announcementBarTextEn: e.target.value })}
                        placeholder="e.g. Nationwide Fast Delivery &amp; Cash on Delivery Available"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-[#c29b38] text-sm sm:text-xs"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 3. Delivery Fees & Shipping */}
              {(settingsCategory === 'all' || settingsCategory === 'delivery') && (
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 sm:p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/80 pb-2.5">
                    <Truck className="w-4 h-4 text-emerald-400" />
                    <span>ডেলিভারি চার্জ ও শিপিং (Shipping)</span>
                  </h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">ঢাকায় ডেলিভারি চার্জ (৳) *</label>
                        <input
                          type="number"
                          value={storeSettings.defaultDeliveryFeeDhaka ?? 70}
                          onChange={(e) => setStoreSettings({ ...storeSettings, defaultDeliveryFeeDhaka: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">ঢাকার বাইরে ডেলিভারি চার্জ (৳) *</label>
                        <input
                          type="number"
                          value={storeSettings.defaultDeliveryFeeOutside ?? 130}
                          onChange={(e) => setStoreSettings({ ...storeSettings, defaultDeliveryFeeOutside: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">ফ্রি ডেলিভারি অর্ডার থ্রেশহোল্ড (৳)</label>
                      <input
                        type="number"
                        value={storeSettings.freeShippingThreshold ?? 5000}
                        onChange={(e) => setStoreSettings({ ...storeSettings, freeShippingThreshold: Number(e.target.value) })}
                        placeholder="5000"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                      />
                      <span className="text-[10px] text-slate-400 mt-0.5 block">এই পরিমাণের বেশি অর্ডারে স্বয়ংক্রিয়ভাবে ডেলিভারি ফ্রি হবে</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">ঢাকায় সম্ভাব্য সময়</label>
                        <input
                          type="text"
                          value={storeSettings.deliveryTimeDhaka || ''}
                          onChange={(e) => setStoreSettings({ ...storeSettings, deliveryTimeDhaka: e.target.value })}
                          placeholder="২৪-৪৮ ঘণ্টা"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm sm:text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">ঢাকার বাইরে সম্ভাব্য সময়</label>
                        <input
                          type="text"
                          value={storeSettings.deliveryTimeOutside || ''}
                          onChange={(e) => setStoreSettings({ ...storeSettings, deliveryTimeOutside: e.target.value })}
                          placeholder="৩-৫ কার্যদিবস"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm sm:text-xs"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">পছন্দের কুরিয়ার সার্ভিস</label>
                        <select
                          value={storeSettings.courierPreference || 'steadfast'}
                          onChange={(e) => setStoreSettings({ ...storeSettings, courierPreference: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm sm:text-xs"
                        >
                          <option value="steadfast">Steadfast Courier Ltd</option>
                          <option value="pathao">Pathao Express</option>
                          <option value="paperfly">Paperfly</option>
                          <option value="redx">RedX Logistics</option>
                        </select>
                      </div>
                      <div className="flex flex-col justify-end">
                        <label className="flex items-center gap-2 text-slate-300 cursor-pointer py-2">
                          <input
                            type="checkbox"
                            checked={!!storeSettings.autoFulfillPaidOrders}
                            onChange={(e) => setStoreSettings({ ...storeSettings, autoFulfillPaidOrders: e.target.checked })}
                            className="rounded"
                          />
                          <span>পেইড অর্ডারে অটো কুরিয়ার ডিসপ্যাচ</span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. Customer Support & Contacts */}
              {(settingsCategory === 'all' || settingsCategory === 'contact') && (
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 sm:p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/80 pb-2.5">
                    <Phone className="w-4 h-4 text-blue-400" />
                    <span>কাস্টমার সাপোর্ট ও হেল্পলাইন (Contact &amp; Support)</span>
                  </h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">হেল্পলাইন নম্বর (Phone) *</label>
                        <input
                          type="text"
                          value={storeSettings.supportPhone || ''}
                          onChange={(e) => setStoreSettings({ ...storeSettings, supportPhone: e.target.value })}
                          placeholder="+880 1711-982341"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-slate-300 font-medium">হোয়াটসঅ্যাপ নম্বর (WhatsApp) *</label>
                          {storeSettings.whatsappNumber && (
                            <a
                              href={`https://wa.me/${storeSettings.whatsappNumber.replace(/[^0-9]/g, '')}`}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[10px] text-emerald-400 hover:underline flex items-center gap-0.5"
                            >
                              <MessageCircle className="w-2.5 h-2.5" />
                              <span>Test Link</span>
                            </a>
                          )}
                        </div>
                        <input
                          type="text"
                          value={storeSettings.whatsappNumber || ''}
                          onChange={(e) => setStoreSettings({ ...storeSettings, whatsappNumber: e.target.value })}
                          placeholder="+8801711982341"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">ইমেইল ঠিকানা (Support Email) *</label>
                      <input
                        type="email"
                        value={storeSettings.supportEmail || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, supportEmail: e.target.value })}
                        placeholder="support@velrofashion.com"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">শো-রুম ও অফিস ঠিকানা (Physical Address) *</label>
                      <textarea
                        rows={2}
                        value={storeSettings.showroomAddress || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, showroomAddress: e.target.value })}
                        placeholder="রোড ১১, ব্লক ডি, বনানী, ঢাকা-১২১৩, বাংলাদেশ"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm sm:text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">অফিস সময় (Operating Hours)</label>
                      <input
                        type="text"
                        value={storeSettings.officeHours || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, officeHours: e.target.value })}
                        placeholder="১০:০০ AM - ১০:০০ PM প্রতিদিন"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm sm:text-xs"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 5. Payment Gateways & Numbers */}
              {(settingsCategory === 'all' || settingsCategory === 'payments') && (
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 sm:p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/80 pb-2.5">
                    <CreditCard className="w-4 h-4 text-[#c29b38]" />
                    <span>পেমেন্ট গেটওয়ে সেটিংস (Payments)</span>
                  </h3>
                  <div className="space-y-3">
                    {/* COD */}
                    <div className="p-3 bg-slate-900/80 border border-slate-700/60 rounded-xl flex items-center justify-between">
                      <div>
                        <span className="font-bold text-white block">ক্যাশ অন ডেলিভারি (Cash on Delivery)</span>
                        <span className="text-[11px] text-slate-400">গ্রাহক পণ্য হাতে পেয়ে টাকা দেবেন</span>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={storeSettings.enableCod !== false}
                          onChange={(e) => setStoreSettings({ ...storeSettings, enableCod: e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                      </label>
                    </div>

                    {/* bKash */}
                    <div className="p-3 bg-slate-900/80 border border-slate-700/60 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="bg-[#e2136e] text-white text-[10px] px-1.5 py-0.5 rounded font-bold font-mono">bKash</span>
                          <span className="font-bold text-white">বিকাশ পেমেন্ট (bKash Checkout)</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={storeSettings.enableBkash !== false}
                            onChange={(e) => setStoreSettings({ ...storeSettings, enableBkash: e.target.checked })}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#e2136e]"></div>
                        </label>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-0.5 font-mono">বিকাশ মার্চেন্ট নম্বর:</label>
                          <input
                            type="text"
                            value={storeSettings.bkashMerchantNumber || ''}
                            onChange={(e) => setStoreSettings({ ...storeSettings, bkashMerchantNumber: e.target.value })}
                            placeholder="01XXXXXXXXX"
                            className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-white font-mono text-sm sm:text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-0.5 font-mono">অ্যাকাউন্ট টাইপ:</label>
                          <select
                            value={storeSettings.bkashAccountType || 'merchant'}
                            onChange={(e) => setStoreSettings({ ...storeSettings, bkashAccountType: e.target.value })}
                            className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-white text-sm sm:text-xs"
                          >
                            <option value="merchant">Merchant Account (পেমেন্ট)</option>
                            <option value="personal">Personal (পার্সোনাল Send Money)</option>
                            <option value="agent">Agent (ক্যাশ আউট)</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Nagad */}
                    <div className="p-3 bg-slate-900/80 border border-slate-700/60 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="bg-[#f7941d] text-white text-[10px] px-1.5 py-0.5 rounded font-bold font-mono">Nagad</span>
                          <span className="font-bold text-white">নগদ পেমেন্ট (Nagad Direct)</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={storeSettings.enableNagad !== false}
                            onChange={(e) => setStoreSettings({ ...storeSettings, enableNagad: e.target.checked })}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#f7941d]"></div>
                        </label>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-0.5 font-mono">নগদ মার্চেন্ট নম্বর:</label>
                          <input
                            type="text"
                            value={storeSettings.nagadMerchantNumber || ''}
                            onChange={(e) => setStoreSettings({ ...storeSettings, nagadMerchantNumber: e.target.value })}
                            placeholder="01XXXXXXXXX"
                            className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-white font-mono text-sm sm:text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-0.5 font-mono">অ্যাকাউন্ট টাইপ:</label>
                          <select
                            value={storeSettings.nagadAccountType || 'merchant'}
                            onChange={(e) => setStoreSettings({ ...storeSettings, nagadAccountType: e.target.value })}
                            className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-white text-sm sm:text-xs"
                          >
                            <option value="merchant">Merchant Account (পেমেন্ট)</option>
                            <option value="personal">Personal (পার্সোনাল)</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Rocket */}
                    <div className="p-3 bg-slate-900/80 border border-slate-700/60 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="bg-purple-600 text-white text-[10px] px-1.5 py-0.5 rounded font-bold font-mono">Rocket</span>
                          <span className="font-bold text-white">রকেট পেমেন্ট (DBBL Rocket)</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={storeSettings.enableRocket !== false}
                            onChange={(e) => setStoreSettings({ ...storeSettings, enableRocket: e.target.checked })}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                        </label>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-0.5 font-mono">রকেট নম্বর (১২ ডিজিট):</label>
                        <input
                          type="text"
                          value={storeSettings.rocketMerchantNumber || ''}
                          onChange={(e) => setStoreSettings({ ...storeSettings, rocketMerchantNumber: e.target.value })}
                          placeholder="01XXXXXXXXX-X"
                          className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                    </div>

                    {/* Sandbox Mode */}
                    <div className="p-3 bg-slate-900/80 border border-slate-700/60 rounded-xl flex items-center justify-between">
                      <div>
                        <span className="font-bold text-amber-400 block">স্যান্ডবক্স টেস্টিং মোড (Sandbox Simulation)</span>
                        <span className="text-[11px] text-slate-400">পরীক্ষামূলক তাৎক্ষণিক পেমেন্ট ভেরিফিকেশন</span>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={storeSettings.enableSandboxPayments !== false}
                          onChange={(e) => setStoreSettings({ ...storeSettings, enableSandboxPayments: e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {/* 6. Social Media & Meta Links */}
              {(settingsCategory === 'all' || settingsCategory === 'social') && (
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 sm:p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/80 pb-2.5">
                    <Share2 className="w-4 h-4 text-sky-400" />
                    <span>সোশ্যাল মিডিয়া লিঙ্ক (Social &amp; Meta Links)</span>
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">ফেসবুক পেজ লিঙ্ক (Facebook Page URL)</label>
                      <input
                        type="text"
                        value={storeSettings.facebookPageUrl || 'https://facebook.com/velrofashion.bd'}
                        onChange={(e) => setStoreSettings({ ...storeSettings, facebookPageUrl: e.target.value })}
                        placeholder="https://facebook.com/yourpage"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">মেসেঞ্জার লিঙ্ক (Messenger URL)</label>
                      <input
                        type="text"
                        value={storeSettings.messengerUrl || 'https://m.me/velrofashion.bd'}
                        onChange={(e) => setStoreSettings({ ...storeSettings, messengerUrl: e.target.value })}
                        placeholder="https://m.me/yourpage"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">ইনস্টাগ্রাম লিঙ্ক (Instagram URL)</label>
                      <input
                        type="text"
                        value={storeSettings.instagramUrl || ''}
                        onChange={(e) => setStoreSettings({ ...storeSettings, instagramUrl: e.target.value })}
                        placeholder="https://instagram.com/yourprofile"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                      />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">ইউটিউব চ্যানেল (YouTube)</label>
                        <input
                          type="text"
                          value={storeSettings.youtubeUrl || ''}
                          onChange={(e) => setStoreSettings({ ...storeSettings, youtubeUrl: e.target.value })}
                          placeholder="https://youtube.com/@channel"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">টিকটক অ্যাকাউন্ট (TikTok)</label>
                        <input
                          type="text"
                          value={storeSettings.tiktokUrl || ''}
                          onChange={(e) => setStoreSettings({ ...storeSettings, tiktokUrl: e.target.value })}
                          placeholder="https://tiktok.com/@account"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 7. Admin Credentials & Direct Password Change */}
              {(settingsCategory === 'all' || settingsCategory === 'security') && (
                <div className="bg-slate-800/80 border border-amber-600/60 rounded-2xl p-4 sm:p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-700/80 pb-2.5">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Key className="w-4 h-4 text-[#c29b38]" />
                      <span>অ্যাডমিন নিরাপত্তা ও পাসওয়ার্ড (Security)</span>
                    </h3>
                    <span className="bg-amber-950 text-[#c29b38] px-2 py-0.5 rounded text-[10px] font-mono border border-amber-800 font-bold">
                      ADMIN ACCESS
                    </span>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-700/80 space-y-1.5 font-mono text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Current Admin User ID:</span>
                      <strong className="text-white bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                        {adminUsername || 'RuhinurRahman'}
                      </strong>
                    </div>
                    <p className="text-[11px] text-slate-400 pt-1">
                      নিরাপত্তার স্বার্থে নিয়মিত বিরতিতে অ্যাডমিন পাসওয়ার্ড পরিবর্তন করুন।
                    </p>
                  </div>

                  {directPasswordMessage && (
                    <div className={`p-3 rounded-xl text-xs flex items-center gap-2 font-mono ${
                      directPasswordMessage.includes('সফল') ? 'bg-emerald-950 border border-emerald-800 text-emerald-300' : 'bg-rose-950 border border-rose-800 text-rose-300'
                    }`}>
                      <CheckCircle className="w-4 h-4 shrink-0" />
                      <span>{directPasswordMessage}</span>
                    </div>
                  )}

                  <form onSubmit={handleDirectPasswordUpdate} className="space-y-3 pt-1">
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">নতুন পাসওয়ার্ড (New Password) *</label>
                      <input
                        type="password"
                        required
                        value={directPasswordNew}
                        onChange={(e) => setDirectPasswordNew(e.target.value)}
                        placeholder="কমপক্ষে ৬ অক্ষরের নতুন পাসওয়ার্ড দিন"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">পাসওয়ার্ড নিশ্চিতকরণ (Confirm Password) *</label>
                      <input
                        type="password"
                        required
                        value={directPasswordConfirm}
                        onChange={(e) => setDirectPasswordConfirm(e.target.value)}
                        placeholder="নতুন পাসওয়ার্ডটি পুনরায় লিখুন"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm sm:text-xs"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={directPasswordLoading}
                      className="w-full py-2.5 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-xl transition-all cursor-pointer text-xs font-mono flex items-center justify-center gap-2 shadow-md disabled:opacity-50"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>{directPasswordLoading ? 'সংরক্ষণ হচ্ছে...' : 'পাসওয়ার্ড আপডেট করুন'}</span>
                    </button>
                  </form>
                </div>
              )}

              {/* 8. Coupons Management */}
              {(settingsCategory === 'all' || settingsCategory === 'coupons') && (
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 sm:p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/80 pb-2.5">
                    <Tag className="w-4 h-4 text-emerald-400" />
                    <span>কুপন ডিসকাউন্ট কোড (Coupon Codes)</span>
                  </h3>

                  {/* Add New Coupon Form */}
                  <form onSubmit={handleCreateCoupon} className="p-3 bg-slate-900 rounded-xl border border-slate-700/80 space-y-3">
                    <span className="text-[11px] font-bold text-slate-200 block">নতুন কুপন কোড তৈরি করুন:</span>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-0.5">কুপন কোড *</label>
                        <input
                          type="text"
                          required
                          value={newCouponCode}
                          onChange={(e) => setNewCouponCode(e.target.value.toUpperCase())}
                          placeholder="যেমন: EID2026"
                          className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-white font-mono uppercase text-sm sm:text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-0.5">ডিসকাউন্ট টাইপ</label>
                        <select
                          value={newCouponType}
                          onChange={(e) => setNewCouponType(e.target.value as any)}
                          className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-white text-sm sm:text-xs"
                        >
                          <option value="percentage">শতকরা (% Percentage)</option>
                          <option value="fixed">নির্দিষ্ট টাকা (Fixed BDT)</option>
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-0.5">ছাড়ের মান ({newCouponType === 'percentage' ? '%' : 'টাকা'}) *</label>
                        <input
                          type="number"
                          required
                          value={newCouponValue}
                          onChange={(e) => setNewCouponValue(Number(e.target.value))}
                          className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-0.5">সর্বনিম্ন অর্ডার (৳)</label>
                        <input
                          type="number"
                          value={newCouponMin}
                          onChange={(e) => setNewCouponMin(Number(e.target.value))}
                          className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-white font-mono text-sm sm:text-xs"
                        />
                      </div>
                    </div>
                    <button
                      type="submit"
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-colors cursor-pointer text-xs flex items-center justify-center gap-1.5 font-mono"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>কুপন তৈরি করুন</span>
                    </button>
                  </form>

                  {/* Coupons List */}
                  <div className="space-y-2 max-h-56 overflow-y-auto">
                    <span className="text-[11px] font-mono text-slate-400 block font-bold">সক্রিয় কুপনসমূহ:</span>
                    {coupons.map((c) => (
                      <div key={c.id} className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white font-mono text-xs">{c.code}</span>
                            <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold ${
                              c.active ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-slate-800 text-slate-500'
                            }`}>
                              {c.active ? 'ACTIVE' : 'INACTIVE'}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                            {c.discountType === 'percentage' ? `${c.value}% OFF` : `৳ ${c.value} OFF`} • Min: ৳ {c.minOrderAmount} • Uses: {c.usageCount}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleToggleCoupon(c.id, c.active)}
                            className={`px-2 py-1 text-[10px] font-mono rounded cursor-pointer ${
                              c.active ? 'bg-slate-800 text-amber-300 hover:bg-slate-700' : 'bg-emerald-900/60 text-emerald-300 hover:bg-emerald-800'
                            }`}
                          >
                            {c.active ? 'Disable' : 'Enable'}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteCoupon(c.id)}
                            className="p-1 text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                            title="Delete Coupon"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                    {coupons.length === 0 && (
                      <p className="text-center py-4 text-slate-500 text-xs">কোন কুপন কোড নেই</p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Mobile Floating / Sticky Save Bar */}
            <div className="fixed bottom-14 sm:bottom-0 inset-x-0 bg-slate-950/95 border-t border-slate-800 p-3 sm:hidden z-30 flex items-center justify-between gap-3 shadow-2xl backdrop-blur-md">
              <span className="text-xs text-slate-300 font-medium truncate">
                {storeSettings.storeName || 'Store'} সেটিংস
              </span>
              <button
                type="button"
                onClick={() => handleSaveStoreSettings()}
                disabled={isSavingSettings}
                className="px-5 py-2.5 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-lg disabled:opacity-50 shrink-0 font-mono"
              >
                <Save className="w-4 h-4" />
                <span>{isSavingSettings ? 'সংরক্ষণ...' : 'সংরক্ষণ করুন (Save)'}</span>
              </button>
            </div>
          </div>
        )}

        {/* AUDIT */}
        {activeTab === 'audit' && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white">Security &amp; Administrative Audit Trail</h2>
              <p className="text-slate-400 text-xs">Immutable chronological log of all administrator operations, logins, and API dispatches.</p>
            </div>

            <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 overflow-x-auto text-xs font-mono">
              <table className="w-full text-left">
                <thead className="bg-slate-900 text-slate-400 border-b border-slate-700">
                  <tr>
                    <th className="p-3">Timestamp</th>
                    <th className="p-3">Admin</th>
                    <th className="p-3">Action</th>
                    <th className="p-3">Entity Type</th>
                    <th className="p-3">Entity ID</th>
                    <th className="p-3">IP Address</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {auditLogs.map((a) => (
                    <tr key={a.id}>
                      <td className="p-3 text-slate-400">{new Date(a.timestamp).toLocaleString('en-GB')}</td>
                      <td className="p-3 font-bold text-[#c29b38]">{a.adminUsername}</td>
                      <td className="p-3 font-bold text-white">{a.action}</td>
                      <td className="p-3 text-slate-300">{a.entityType}</td>
                      <td className="p-3 text-slate-400">{a.entityId}</td>
                      <td className="p-3 text-slate-500">{a.ipAddress || '127.0.0.1'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* MOBILE BOTTOM NAVIGATION BAR */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-slate-950/95 border-t border-slate-800 backdrop-blur-md px-1 py-1.5 flex items-center justify-around shadow-2xl safe-area-inset-bottom">
        <button
          onClick={() => { setActiveTab('overview'); setMobileMoreOpen(false); }}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors cursor-pointer ${
            activeTab === 'overview' ? 'text-[#c29b38] font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <LayoutDashboard className="w-5 h-5 mb-0.5" />
          <span>Home</span>
        </button>
        <button
          onClick={() => { setActiveTab('products'); setMobileMoreOpen(false); }}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors cursor-pointer ${
            activeTab === 'products' ? 'text-[#c29b38] font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Package className="w-5 h-5 mb-0.5" />
          <span>Products</span>
        </button>
        <button
          onClick={() => { setActiveTab('orders'); setMobileMoreOpen(false); }}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors relative cursor-pointer ${
            activeTab === 'orders' ? 'text-[#c29b38] font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShoppingBag className="w-5 h-5 mb-0.5" />
          <span>Orders</span>
          {orders.filter(o => o.orderStatus === 'confirmed' || o.orderStatus === 'pending').length > 0 && (
            <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-amber-400 ring-2 ring-slate-950"></span>
          )}
        </button>
        <button
          onClick={() => { setActiveTab('settings'); setMobileMoreOpen(false); }}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors cursor-pointer ${
            activeTab === 'settings' ? 'text-[#c29b38] font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Settings className="w-5 h-5 mb-0.5" />
          <span>Settings</span>
        </button>
        <button
          onClick={() => setMobileMoreOpen(true)}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-[10px] font-medium transition-colors cursor-pointer ${
            ['dropshipping', 'facebook', 'sql', 'payments', 'audit'].includes(activeTab) || mobileMoreOpen ? 'text-[#c29b38] font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MoreHorizontal className="w-5 h-5 mb-0.5" />
          <span>More</span>
        </button>
      </nav>

      {/* MOBILE MORE MENU DRAWER */}
      {mobileMoreOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex flex-col justify-end">
          <div className="bg-slate-900 border-t border-slate-700 rounded-t-3xl p-5 space-y-4 max-h-[85vh] overflow-y-auto shadow-2xl text-left animate-in slide-in-from-bottom duration-200">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <div>
                <h3 className="font-bold text-white text-base">অন্যান্য মডিউল (Admin Modules)</h3>
                <p className="text-[11px] text-slate-400 font-mono">Signed in: {adminUsername}</p>
              </div>
              <button
                onClick={() => setMobileMoreOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs font-mono">
              <button
                onClick={() => { setActiveTab('dropshipping'); setMobileMoreOpen(false); }}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-center cursor-pointer ${
                  activeTab === 'dropshipping' ? 'bg-[#c29b38] text-slate-950 font-bold border-[#c29b38]' : 'bg-slate-800/80 text-white border-slate-700 hover:bg-slate-800'
                }`}
              >
                <Layers className="w-5 h-5" />
                <span>ShopBase BD</span>
              </button>
              <button
                onClick={() => { setActiveTab('payments'); setMobileMoreOpen(false); }}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-center cursor-pointer ${
                  activeTab === 'payments' ? 'bg-[#c29b38] text-slate-950 font-bold border-[#c29b38]' : 'bg-slate-800/80 text-white border-slate-700 hover:bg-slate-800'
                }`}
              >
                <CreditCard className="w-5 h-5" />
                <span>bKash / Nagad</span>
              </button>
              <button
                onClick={() => { setActiveTab('facebook'); setMobileMoreOpen(false); }}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-center cursor-pointer ${
                  activeTab === 'facebook' ? 'bg-[#c29b38] text-slate-950 font-bold border-[#c29b38]' : 'bg-slate-800/80 text-white border-slate-700 hover:bg-slate-800'
                }`}
              >
                <Share2 className="w-5 h-5" />
                <span>Facebook Shop</span>
              </button>
              <button
                onClick={() => { setActiveTab('sql'); setMobileMoreOpen(false); }}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-center cursor-pointer ${
                  activeTab === 'sql' ? 'bg-[#c29b38] text-slate-950 font-bold border-[#c29b38]' : 'bg-slate-800/80 text-white border-slate-700 hover:bg-slate-800'
                }`}
              >
                <Database className="w-5 h-5" />
                <span>SQL Console</span>
              </button>
              <button
                onClick={() => { setActiveTab('audit'); setMobileMoreOpen(false); }}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-center cursor-pointer ${
                  activeTab === 'audit' ? 'bg-[#c29b38] text-slate-950 font-bold border-[#c29b38]' : 'bg-slate-800/80 text-white border-slate-700 hover:bg-slate-800'
                }`}
              >
                <Shield className="w-5 h-5" />
                <span>Security Audit</span>
              </button>
              <button
                onClick={() => { setSettingsCategory('security'); setActiveTab('settings'); setMobileMoreOpen(false); }}
                className="p-3 rounded-xl border bg-slate-800/80 text-white border-slate-700 hover:bg-slate-800 flex flex-col items-center gap-1.5 text-center cursor-pointer"
              >
                <Key className="w-5 h-5 text-[#c29b38]" />
                <span>Change Password</span>
              </button>
            </div>

            <div className="pt-2 border-t border-slate-800 flex gap-2">
              <button
                onClick={() => { setMobileMoreOpen(false); onReturnToStore(); }}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-mono font-bold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>স্টোরফ্রন্টে যান</span>
              </button>
              <button
                onClick={onLogout}
                className="flex-1 py-2.5 bg-rose-950 hover:bg-rose-900 text-rose-300 rounded-xl text-xs font-mono font-bold flex items-center justify-center gap-1.5 cursor-pointer border border-rose-800"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>লগআউট</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REQUIRED PASSWORD CHANGE MODAL */}
      {showPasswordChangeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-600/80 rounded-2xl max-w-md w-full p-6 space-y-5 shadow-2xl text-left">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-950 rounded-xl flex items-center justify-center text-amber-400">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Security Requirement</h3>
                <p className="text-xs text-amber-400 font-mono">Mandatory Initial Password Change</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Per production deployment guidelines, please update your initial password with a secure password.
            </p>

            {passwordChangeSuccess ? (
              <div className="p-3 bg-emerald-950 border border-emerald-800 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>Password changed successfully!</span>
              </div>
            ) : (
              <form onSubmit={handlePasswordChange} className="space-y-4 text-xs font-mono">
                <div>
                  <label className="block text-slate-400 mb-1">New Secure Password (min 6 characters)</label>
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new strong password"
                    className="w-full px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-[#c29b38]"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-xl tracking-wide uppercase transition-colors cursor-pointer"
                >
                  Update Admin Password
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* COMPREHENSIVE PRODUCT CREATE / EDIT MODAL: GALLERY UPLOAD + COLOR & SIZE SYSTEMS */}
      {productModalOpen && editingProduct && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-4xl w-full p-6 space-y-6 shadow-2xl text-left my-8 max-h-[92vh] overflow-y-auto">
            
            {/* Header */}
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Package className="w-4 h-4 text-[#c29b38]" />
                  <span>{editingProduct.id ? 'Edit Apparel Product' : 'Add New Clothing Article'}</span>
                </h3>
                <p className="text-[11px] text-slate-400 font-mono">
                  পোশাকের ছবি, কালার সোয়াচ, সাইজ এবং ভ্যারিয়েন্ট কনফিগারেশন
                </p>
              </div>
              <button onClick={() => setProductModalOpen(false)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-6 text-xs">
              
              {/* 1. Basic Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1">Product Title (English) *</label>
                  <input
                    required
                    type="text"
                    value={editingProduct.title || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, title: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">পণ্যের শিরোনাম (বাংলা)</label>
                  <input
                    type="text"
                    value={editingProduct.titleBn || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, titleBn: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>

              {/* 2. Category, Prices, SKU */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1">Category</label>
                  <select
                    value={editingProduct.category || 'Panjabi and Kurta'}
                    onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  >
                    <option value="Panjabi and Kurta">Panjabi and Kurta</option>
                    <option value="Three-Piece and Two-Piece">Three-Piece and Two-Piece</option>
                    <option value="Traditional Clothing">Traditional Clothing</option>
                    <option value="Shirts and T-shirts">Shirts and T-shirts</option>
                    <option value="Trousers and Jeans">Trousers and Jeans</option>
                    <option value="Kids' Fashion">Kids' Fashion</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1 font-mono">SKU Code</label>
                  <input
                    type="text"
                    value={editingProduct.sku || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, sku: e.target.value })}
                    placeholder="e.g. VF-PNJ-009"
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1 font-mono">Cost Price (৳)</label>
                  <input
                    type="number"
                    value={editingProduct.costPrice || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, costPrice: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1 font-mono">Selling Price (৳)</label>
                  <input
                    type="number"
                    value={editingProduct.sellingPrice || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, sellingPrice: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              {/* 3. DIRECT GALLERY IMAGE UPLOADER */}
              <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-slate-200 flex items-center gap-1.5">
                    <UploadCloud className="w-4 h-4 text-[#c29b38]" />
                    <span>গ্যালারি ছবি নির্বাচন (Direct Device Gallery Upload)</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploadingImage}
                    className="px-3 py-1.5 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 font-mono text-[11px]"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isUploadingImage ? 'আপলোড হচ্ছে...' : 'ছবি নির্বাচন করুন'}</span>
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleGalleryUpload}
                    className="hidden"
                  />
                </div>

                {/* Uploaded Thumbnails Grid */}
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 pt-2">
                  {(editingProduct.images || []).map((imgUrl, idx) => (
                    <div key={idx} className="relative group aspect-[3/4] rounded-lg overflow-hidden border border-slate-700 bg-slate-900">
                      <img src={imgUrl} alt="" className="w-full h-full object-cover" />
                      {idx === 0 && (
                        <span className="absolute top-1 left-1 bg-[#c29b38] text-slate-950 text-[9px] font-bold px-1.5 py-0.5 rounded font-mono">
                          PRIMARY
                        </span>
                      )}
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1.5 p-1">
                        {idx !== 0 && (
                          <button
                            type="button"
                            onClick={() => makePrimaryImage(idx)}
                            className="text-[9px] bg-slate-800 text-white px-2 py-0.5 rounded hover:bg-slate-700 cursor-pointer"
                          >
                            Make Primary
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => removeGalleryImage(idx)}
                          className="text-[9px] bg-rose-600 text-white px-2 py-0.5 rounded hover:bg-rose-500 cursor-pointer"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                  
                  {/* Plus card shortcut */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="aspect-[3/4] rounded-lg border-2 border-dashed border-slate-700 hover:border-[#c29b38] text-slate-400 hover:text-white flex flex-col items-center justify-center gap-1.5 transition-colors cursor-pointer bg-slate-900/40"
                  >
                    <Plus className="w-6 h-6" />
                    <span className="text-[10px]">Add Photo</span>
                  </button>
                </div>
              </div>

              {/* 4. DYNAMIC COLOR SYSTEM */}
              <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-slate-200 flex items-center gap-1.5">
                    <Palette className="w-4 h-4 text-emerald-400" />
                    <span>কালার অপশন পরিচালনা (Dynamic Color Swatches)</span>
                  </label>
                </div>

                {/* Add New Color Form */}
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="color"
                    value={newColorHex}
                    onChange={(e) => setNewColorHex(e.target.value)}
                    className="w-9 h-9 rounded cursor-pointer bg-transparent border-0"
                    title="Choose Hex Color"
                  />
                  <input
                    type="text"
                    value={newColorName}
                    onChange={(e) => setNewColorName(e.target.value)}
                    placeholder="Color Name (e.g. Royal Navy / Maroon / Black)"
                    className="flex-1 min-w-[180px] px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                  <button
                    type="button"
                    onClick={addColorItem}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-lg cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>কালার যোগ করুন</span>
                  </button>
                </div>

                {/* Quick Swatch Presets */}
                <div className="flex items-center gap-1.5 pt-1 text-[11px] text-slate-400 font-mono">
                  <span>Presets:</span>
                  {[
                    { name: 'Royal Navy', hex: '#1e3a8a' },
                    { name: 'Jet Black', hex: '#000000' },
                    { name: 'Deep Maroon', hex: '#881337' },
                    { name: 'Emerald Green', hex: '#065f46' },
                    { name: 'Crisp White', hex: '#f8fafc' },
                    { name: 'Ruby Red', hex: '#dc2626' },
                    { name: 'Royal Gold', hex: '#d97706' },
                    { name: 'Olive Green', hex: '#65a30d' }
                  ].map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setNewColorName(p.name);
                        setNewColorHex(p.hex);
                      }}
                      className="w-4 h-4 rounded-full border border-slate-600 hover:scale-110 transition-transform cursor-pointer"
                      style={{ backgroundColor: p.hex }}
                      title={p.name}
                    />
                  ))}
                </div>

                {/* Active Colors Pill List */}
                <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-800">
                  {(editingProduct.colors || []).map((c, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-1.5 px-3 py-1 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs"
                    >
                      <span>{c}</span>
                      <button
                        type="button"
                        onClick={() => removeColorItem(c)}
                        className="text-slate-400 hover:text-rose-400 p-0.5 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* 5. DYNAMIC SIZE SYSTEM */}
              <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-slate-200 flex items-center gap-1.5">
                    <Ruler className="w-4 h-4 text-blue-400" />
                    <span>সাইজ ও ভ্যারিয়েন্ট সিস্টেম (Dynamic Size Presets &amp; Variants)</span>
                  </label>
                </div>

                {/* Size Presets Shortcuts */}
                <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono">
                  <span className="text-slate-400">Templates:</span>
                  <button
                    type="button"
                    onClick={() => applySizePreset(['38', '40', '42', '44', '46'])}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-[#c29b38] rounded border border-slate-700 cursor-pointer"
                  >
                    পাঞ্জাবি প্রিসেট (38, 40, 42, 44, 46)
                  </button>
                  <button
                    type="button"
                    onClick={() => applySizePreset(['15 (M)', '15.5 (L)', '16 (XL)', '16.5 (XXL)'])}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-blue-300 rounded border border-slate-700 cursor-pointer"
                  >
                    শার্ট প্রিসেট (M, L, XL, XXL)
                  </button>
                  <button
                    type="button"
                    onClick={() => applySizePreset(['30', '32', '34', '36', '38'])}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded border border-slate-700 cursor-pointer"
                  >
                    জিন্স প্রিসেট (30, 32, 34, 36)
                  </button>
                  <button
                    type="button"
                    onClick={() => applySizePreset(['Free Size (12 Haat)'])}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-rose-300 rounded border border-slate-700 cursor-pointer"
                  >
                    শাড়ি প্রিসেট (Free Size)
                  </button>
                </div>

                {/* Custom Size Input */}
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newSizeInput}
                    onChange={(e) => setNewSizeInput(e.target.value)}
                    placeholder="Custom Size (e.g. 42 / XL / 14 Haat)"
                    className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
                  />
                  <button
                    type="button"
                    onClick={addSizeItem}
                    className="px-4 py-2 bg-blue-700 hover:bg-blue-600 text-white font-bold rounded-lg cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>সাইজ যোগ করুন</span>
                  </button>
                </div>

                {/* Active Sizes Pill List */}
                <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-800">
                  {(editingProduct.sizes || []).map((s, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-1.5 px-3 py-1 bg-slate-900 border border-slate-700 rounded-lg text-[#c29b38] font-bold font-mono text-xs"
                    >
                      <span>{s}</span>
                      <button
                        type="button"
                        onClick={() => removeSizeItem(s)}
                        className="text-slate-400 hover:text-rose-400 p-0.5 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* 6. Description */}
              <div>
                <label className="block text-slate-400 mb-1">Product Description</label>
                <textarea
                  rows={3}
                  value={editingProduct.description || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                />
              </div>

              {/* Submit / Cancel Buttons */}
              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setProductModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-lg cursor-pointer shadow-lg"
                >
                  Save Apparel Article
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ORDER DETAILS & INVOICE MODAL */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl text-left my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Order {selectedOrder.orderNumber}</h3>
                <p className="text-xs text-slate-400 font-mono">Placed: {new Date(selectedOrder.createdAt).toLocaleString('en-GB')}</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs font-mono bg-slate-950 p-4 rounded-xl">
              <div>
                <span className="text-slate-500 block">Customer:</span>
                <span className="text-white font-bold">{selectedOrder.customerName}</span>
                <span className="text-slate-400 block">{selectedOrder.customerPhone}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Shipping Destination:</span>
                <span className="text-white">{selectedOrder.deliveryArea}, {selectedOrder.district}</span>
                <span className="text-slate-400 block">{selectedOrder.address}</span>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <span className="font-mono text-slate-400 uppercase font-bold text-[11px]">Items &amp; Supplier Routing:</span>
              <div className="divide-y divide-slate-800">
                {selectedOrder.items.map((item: any, idx: number) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img src={item.image} alt="" className="w-10 h-12 object-cover rounded bg-slate-800" />
                      <div>
                        <span className="font-bold text-white block">{item.title}</span>
                        <span className="text-slate-400 font-mono text-[11px]">
                          {item.size} • {item.color} • Supplier: <strong className="text-amber-400">{item.supplierName}</strong>
                        </span>
                      </div>
                    </div>
                    <div className="text-right font-mono">
                      <span className="text-white font-bold block">৳ {item.price * item.quantity}</span>
                      <span className="text-slate-500 text-[10px]">Cost: ৳ {item.costPrice * item.quantity}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs font-mono">
              <div>
                <span>Total Revenue: <strong className="text-emerald-400 text-sm">৳ {selectedOrder.total}</strong></span>
              </div>
              <button
                onClick={() => handleRetryFulfillment(selectedOrder.id)}
                className="px-3.5 py-1.5 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-lg cursor-pointer"
              >
                Trigger Supplier Dispatch
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SHOPBASE BD CONNECT / LOGIN MODAL */}
      {shopbaseModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-[#c29b38]/80 rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl text-left my-8">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#c29b38] text-slate-950 flex items-center justify-center font-bold font-mono">
                  SBD
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    ShopBase BD (https://shopbasebd.com/)
                  </h3>
                  <p className="text-[11px] text-[#c29b38] font-mono">
                    Official Bangladesh Dropshipping API Connection
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShopbaseModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-1.5 leading-relaxed">
              <p className="text-white font-semibold">
                https://shopbasebd.com/ রিসেলার অ্যাকাউন্ট ইন্টিগ্রেশন
              </p>
              <p className="text-slate-400 text-[11px]">
                আপনার শপবেজ বিডি (shopbasebd.com) পার্টনার ক্রেডেনশিয়াল দিন।
              </p>
            </div>

            <form onSubmit={handleConnectShopbaseBD} className="space-y-4 text-xs font-mono">
              <div>
                <label className="block text-slate-400 mb-1">
                  ShopBase BD Website URL *
                </label>
                <input
                  type="text"
                  required
                  value={shopbaseStoreUrl}
                  onChange={(e) => setShopbaseStoreUrl(e.target.value)}
                  placeholder="https://shopbasebd.com/"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-[#c29b38]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">
                    Registered Mobile No
                  </label>
                  <input
                    type="tel"
                    value={shopbasePhone}
                    onChange={(e) => setShopbasePhone(e.target.value)}
                    placeholder="01711XXXXXX"
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">
                    Store / Brand Name
                  </label>
                  <input
                    type="text"
                    value={shopbaseStoreName}
                    onChange={(e) => setShopbaseStoreName(e.target.value)}
                    placeholder="VELRO FASHION BD"
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">
                  Reseller API Access Key / Partner Token
                </label>
                <input
                  type="password"
                  value={shopbaseApiKey}
                  onChange={(e) => setShopbaseApiKey(e.target.value)}
                  placeholder="sb_bd_live_reseller_token_2026"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShopbaseModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={shopbaseConnecting}
                  className="px-5 py-2.5 bg-[#c29b38] hover:bg-[#d8b14a] text-slate-950 font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-2 shadow-md"
                >
                  {shopbaseConnecting ? (
                    <span>Connecting to shopbasebd.com...</span>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Connect to shopbasebd.com</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
