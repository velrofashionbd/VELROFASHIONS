export interface ProductVariant {
  id: string;
  sku: string;
  size: string;
  color: string;
  stock: number;
  costPrice: number;
  price: number;
  supplierVariantId?: string;
}

export interface ProductColorItem {
  name: string;
  hex: string;
  inStock?: boolean;
}

export interface ProductSizeItem {
  size: string;
  chest?: string;
  length?: string;
  inStock?: boolean;
}

export interface Product {
  id: string;
  title: string;
  titleBn: string;
  description: string;
  descriptionBn: string;
  sku: string;
  supplierProductId?: string;
  supplierName: string;
  supplierProductUrl?: string;
  category: string;
  subcategory: string;
  images: string[];
  costPrice: number;
  sellingPrice: number;
  salePrice?: number;
  discountPercent?: number;
  sizes: string[];
  colors: string[];
  colorItems?: ProductColorItem[];
  sizeItems?: ProductSizeItem[];
  variants: ProductVariant[];
  stockQuantity: number;
  weightKg: number;
  status: 'published' | 'draft' | 'archived';
  shippingInfo: string;
  shippingInfoBn: string;
  isFeatured: boolean;
  isBestseller: boolean;
  isNewArrival: boolean;
}

export interface FacebookSettings {
  pageName: string;
  pageId: string;
  pageUrl: string;
  messengerUrl: string;
  accessToken?: string;
  pixelId?: string;
  catalogSyncEnabled: boolean;
  messengerChatEnabled: boolean;
  lastCatalogSync?: string;
}

export interface Category {
  slug: string;
  nameEn: string;
  nameBn: string;
  descriptionEn: string;
  descriptionBn: string;
  imageUrl: string;
  parentGroup?: string;
}

export interface CartItem {
  productId: string;
  variantId: string;
  sku: string;
  title: string;
  titleBn?: string;
  size: string;
  color: string;
  price: number;
  costPrice: number;
  quantity: number;
  image: string;
  supplierName: string;
  supplierProductId?: string;
  supplierVariantId?: string;
}

export interface OrderItem {
  productId: string;
  variantId: string;
  sku: string;
  title: string;
  size: string;
  color: string;
  quantity: number;
  price: number;
  costPrice: number;
  image: string;
  supplierName: string;
  supplierProductId?: string;
  supplierVariantId?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  district: string;
  deliveryArea: string;
  address: string;
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  couponCode?: string;
  total: number;
  paymentMethod: 'cod' | 'bkash' | 'nagad' | 'rocket' | 'sslcommerz';
  paymentStatus: 'pending' | 'verified' | 'failed' | 'refunded';
  paymentReference?: string;
  orderStatus: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  fulfillmentStatus: 'unfulfilled' | 'partially_fulfilled' | 'fulfilled' | 'failed';
  trackingNumber?: string;
  courierName?: string;
  supplierOrderIds?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface ShipmentEvent {
  id: string;
  orderId: string;
  orderNumber: string;
  timestamp: string;
  status: string;
  location: string;
  description: string;
  source: 'courier' | 'supplier' | 'admin';
}

export interface SupplierIntegration {
  id: string;
  name: string;
  type: string;
  status: 'not_connected' | 'connecting' | 'connected' | 'syncing' | 'action_required' | 'connection_error';
  statusMessage?: string;
  config: Record<string, any>;
  stats: {
    productsCount: number;
    activeOrdersCount: number;
    lastSyncTimestamp?: string;
    lastSuccessfulFulfillment?: string;
    syncErrorsCount: number;
  };
  settings: {
    autoImport: boolean;
    autoPublish: boolean;
    autoPriceSync: boolean;
    autoStockSync: boolean;
    autoFulfillPaidOrders: boolean;
    allowCodFulfillment: boolean;
    defaultMarkupPercentage: number;
    minimumProfitMarginBdt: number;
    maxShippingDays: number;
  };
  createdAt: string;
  updatedAt: string;
}

export interface SupplierFulfillmentRequest {
  id: string;
  orderId: string;
  orderNumber: string;
  supplierId: string;
  supplierName: string;
  idempotencyKey: string;
  items: any[];
  customerShipping: any;
  status: 'pending_approval' | 'processing' | 'submitted' | 'shipped' | 'delivered' | 'failed' | 'cancelled';
  supplierOrderId?: string;
  trackingNumber?: string;
  courierName?: string;
  totalCostBdt: number;
  failureReason?: string;
  retryCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface SyncLog {
  id: string;
  timestamp: string;
  integrationType: string;
  supplierId: string;
  supplierName: string;
  eventType: string;
  status: 'success' | 'warning' | 'error';
  message: string;
  details?: any;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  value: number;
  minOrderAmount: number;
  active: boolean;
  usageCount: number;
  maxUses: number;
}

export interface StoreSettings {
  storeName: string;
  storeNameBn?: string;
  storeTagline?: string;
  storeTaglineEn?: string;
  announcementBarText?: string;
  announcementBarTextEn?: string;
  showAnnouncementBar?: boolean;
  currency: string;
  currencySymbol: string;
  defaultDeliveryFeeDhaka: number;
  defaultDeliveryFeeOutside: number;
  freeShippingThreshold: number;
  deliveryTimeDhaka?: string;
  deliveryTimeOutside?: string;
  courierPreference?: string;
  supportPhone?: string;
  whatsappNumber?: string;
  supportEmail?: string;
  showroomAddress?: string;
  officeHours?: string;
  enableCod?: boolean;
  enableBkash?: boolean;
  enableNagad?: boolean;
  enableRocket?: boolean;
  enableSslcommerz?: boolean;
  bkashMerchantNumber?: string;
  bkashAccountType?: string;
  nagadMerchantNumber?: string;
  nagadAccountType?: string;
  rocketMerchantNumber?: string;
  autoFulfillPaidOrders?: boolean;
  allowCodFulfillment?: boolean;
  defaultMarkupPercentage?: number;
  minProfitMarginBdt?: number;
  enableSandboxPayments?: boolean;
  facebookPageUrl?: string;
  messengerUrl?: string;
  instagramUrl?: string;
  youtubeUrl?: string;
  tiktokUrl?: string;
}
