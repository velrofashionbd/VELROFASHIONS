import React, { useState, useEffect } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { Product } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onNavigateToShop: (category?: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  products,
  onSelectProduct,
  onNavigateToShop
}) => {
  const { language, t } = useLanguage();
  const [query, setQuery] = useState('');

  useEffect(() => {
    if (isOpen) {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const filtered = query.trim()
    ? products.filter((p) => {
        const q = query.toLowerCase();
        return (
          p.title.toLowerCase().includes(q) ||
          p.titleBn?.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q)
        );
      })
    : [];

  const handleSelect = (p: Product) => {
    onSelectProduct(p);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-start justify-center pt-16 sm:pt-24 px-4 animate-in fade-in duration-150">
      <div 
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden text-left"
      >
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="flex-1 text-base text-slate-900 placeholder-slate-400 focus:outline-none bg-transparent"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2.5 py-1 text-xs font-semibold text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
          >
            ESC
          </button>
        </div>

        {/* Popular Category Shortcuts */}
        {!query.trim() && (
          <div className="p-6 space-y-4">
            <p className="text-xs font-mono uppercase tracking-wider text-slate-400">
              {language === 'bn' ? 'জনপ্রিয় ক্যাটাগরি' : 'Trending Categories'}
            </p>
            <div className="flex flex-wrap gap-2">
              {['Panjabi and Kurta', 'Three-Piece and Two-Piece', 'Traditional Clothing', 'Shirts and T-shirts', 'Trousers and Jeans'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    onNavigateToShop(cat);
                    onClose();
                  }}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-medium rounded-lg transition-colors cursor-pointer"
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Search Results */}
        {query.trim() && (
          <div className="max-h-96 overflow-y-auto p-4 divide-y divide-slate-100">
            {filtered.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-sm">
                <p>{language === 'bn' ? 'কোন পোশাকের ফলাফল পাওয়া যায়নি।' : 'No matching clothing items found.'}</p>
                <p className="text-xs text-slate-400 mt-1">Try searching "Panjabi", "Saree", "Shirt", or "Denim".</p>
              </div>
            ) : (
              filtered.map((product) => (
                <div
                  key={product.id}
                  onClick={() => handleSelect(product)}
                  className="py-3 px-2 flex items-center justify-between hover:bg-slate-50 rounded-lg cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={product.images[0]}
                      alt={product.title}
                      className="w-12 h-14 object-cover rounded-md bg-slate-100 shrink-0"
                    />
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900">
                        {language === 'bn' ? (product.titleBn || product.title) : product.title}
                      </h4>
                      <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                        <span>{product.category}</span>
                        <span aria-hidden="true">•</span>
                        <span className="font-mono">{product.sku}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-bold font-mono text-slate-950 tabular-nums">
                      ৳ {(product.salePrice || product.sellingPrice).toLocaleString('en-BD')}
                    </span>
                    <ArrowRight className="w-4 h-4 text-slate-400 ml-auto mt-1" />
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
