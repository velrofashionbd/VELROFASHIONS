import React, { useState } from 'react';
import { MessageSquare, X, Send, PhoneCall } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const LiveSupportWidget: React.FC = () => {
  const { language, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{ sender: 'bot' | 'user'; text: string; time: string }>>([
    {
      sender: 'bot',
      text: language === 'bn' 
        ? 'আসসালামু আলাইকুম! VELRO FASHION-এ আপনাকে স্বাগতম। সাইজ, ফেব্রিক বা অর্ডার সংক্রান্ত যে কোন বিষয়ে আমরা আপনাকে সহায়তা করতে প্রস্তুত।'
        : 'Welcome to VELRO FASHION Concierge. How may we assist your shopping today?',
      time: 'Just now'
    }
  ]);
  const [input, setInput] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userText = input.trim();
    const newMsg = { sender: 'user' as const, text: userText, time: 'Now' };
    setMessages(prev => [...prev, newMsg]);
    setInput('');

    setTimeout(() => {
      let reply = language === 'bn' 
        ? 'আপনার বার্তার জন্য ধন্যবাদ! দ্রুত সহায়তার জন্য সরাসরি আমাদের হেল্পলাইনে কল করতে পারেন: +৮৮০ ১৭১১-৯৮২৩৪১'
        : 'Thank you for reaching out. Our stylist & dispatch support team is active. For direct phone assistance call +880 1711-982341.';
      
      const lower = userText.toLowerCase();
      if (lower.includes('delivery') || userText.includes('ডেলিভারি')) {
        reply = language === 'bn'
          ? 'ঢাকায় ২৪-৪৮ ঘণ্টার মধ্যে ডেলিভারি (চার্জ ৭০ টাকা) এবং ঢাকার বাইরে ৩-৫ দিনে ডেলিভারি (চার্জ ১৩০ টাকা)। ৫,০০০ টাকার অধিক অর্ডারে ডেলিভারি ফ্রি!'
          : 'Standard delivery in Dhaka is 24-48 hours (৳ 70) and 3-5 days outside Dhaka (৳ 130). Free delivery applies on orders above ৳ 5,000.';
      } else if (lower.includes('size') || userText.includes('সাইজ')) {
        reply = language === 'bn'
          ? 'পাঞ্জাবির জন্য ৪০ (M), ৪২ (L), ৪৪ (XL)। সাইজ নিয়ে কোন সমস্যা হলে ৭ দিনের মধ্যে সহজে এক্সচেঞ্জ সুবিধা পাবেন।'
          : 'For panjabi and shirts: M (40), L (42), XL (44). 7-day hassle-free size exchange is guaranteed!';
      }

      setMessages(prev => [...prev, { sender: 'bot', text: reply, time: 'Now' }]);
    }, 600);
  };

  return (
    <div className="fixed bottom-5 right-5 z-40 text-left">
      {/* Floating Trigger Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-4 py-3 bg-[#0f172a] hover:bg-slate-800 text-white rounded-full shadow-xl transition-transform hover:scale-105 cursor-pointer border border-slate-700"
          title="Live Customer Support"
          aria-label="Support Chat"
        >
          <MessageSquare className="w-4 h-4 text-[#c29b38]" />
          <span className="text-xs font-semibold">{t.customerSupport}</span>
        </button>
      )}

      {/* Expanded Support Window */}
      {isOpen && (
        <div className="w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col h-[480px] animate-in fade-in slide-in-from-bottom-4 duration-200">
          {/* Header */}
          <div className="p-4 bg-[#0f172a] text-white flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <h3 className="text-xs font-semibold tracking-wide">VELRO FASHION CONCIERGE</h3>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">Online Support • Banani, Dhaka</p>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Support Actions */}
          <div className="px-3 py-2 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
            <a
              href="tel:+8801711982341"
              className="flex items-center gap-1 text-[#b3821a] hover:underline font-medium"
            >
              <PhoneCall className="w-3 h-3" />
              <span>+880 1711-982341</span>
            </a>
            <span className="text-slate-400">•</span>
            <span className="text-slate-500 font-mono">24/7 Order Desk</span>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/40 text-xs">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3 rounded-xl leading-relaxed ${
                    m.sender === 'user'
                      ? 'bg-[#0f172a] text-white rounded-br-none'
                      : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-none shadow-xs'
                  }`}
                >
                  <p>{m.text}</p>
                </div>
                <span className="text-[10px] text-slate-400 mt-1 px-1">{m.time}</span>
              </div>
            ))}
          </div>

          {/* Input Form */}
          <form onSubmit={handleSend} className="p-3 border-t border-slate-200 bg-white flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={language === 'bn' ? 'বার্তা লিখুন...' : 'Type a message...'}
              className="flex-1 text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
            <button
              type="submit"
              className="p-2 bg-[#0f172a] hover:bg-slate-800 text-white rounded-lg transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
