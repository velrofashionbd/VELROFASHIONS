import React, { useState } from 'react';
import { ShoppingBag, Zap, Check } from 'lucide-react';
import { Product } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onQuickOrder?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect, onQuickOrder }) => {
  const { language } = useLanguage();
  const { addToCart } = useCart();
  const [selectedSize] = useState<string>(product.sizes[0] || 'Standard');
  const [selectedColor] = useState<string>(product.colors[0] || 'Standard');
  const [addedAnimation, setAddedAnimation] = useState(false);

  const title = language === 'bn' ? (product.titleBn || product.title) : product.title;
  const currentPrice = product.salePrice || product.sellingPrice;
  const hasDiscount = product.salePrice && product.salePrice < product.sellingPrice;

  // Derive badge type
  let badge: { label: string; bg: string } | null = null;
  if (product.isNewArrival) {
    badge = { label: 'New', bg: 'bg-[#0284c7]' };
  } else if (product.isBestseller) {
    badge = { label: 'Hot', bg: 'bg-rose-600' };
  } else if (hasDiscount) {
    badge = { label: 'Sale', bg: 'bg-rose-600' };
  }

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, selectedSize, selectedColor, 1);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1200);
  };

  const handleDirectOrder = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onQuickOrder) {
      onQuickOrder(product);
    } else {
      onSelect(product);
    }
  };

  return (
    <div
      onClick={() => onSelect(product)}
      className="group relative flex flex-col bg-white border border-slate-200/90 rounded-2xl overflow-hidden hover:border-slate-300 hover:shadow-md transition-all duration-200 cursor-pointer text-left"
    >
      {/* Image Container with Badge */}
      <div className="relative aspect-[3/4] w-full bg-slate-100 overflow-hidden">
        <img
          src={product.images[0]}
          alt={title}
          className="h-full w-full object-cover object-top transition-transform duration-500 ease-out group-hover:scale-105"
          loading="lazy"
        />
        {/* Badge in top-left */}
        {badge && (
          <div className={`absolute top-2.5 left-2.5 ${badge.bg} text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xs tracking-wide uppercase`}>
            {badge.label}
          </div>
        )}
      </div>

      {/* Card Body */}
      <div className="p-3 sm:p-3.5 flex flex-col flex-1 justify-between">
        <div>
          {/* Color Swatch Dots */}
          <div className="flex items-center gap-1.5 mb-2">
            {(product.colors.length > 0 ? product.colors.slice(0, 3) : ['Navy', 'Black', 'Olive']).map((c, idx) => {
              let dotColor = '#1e293b';
              const lower = c.toLowerCase();
              if (lower.includes('blue') || lower.includes('denim') || lower.includes('navy')) dotColor = '#1d4ed8';
              else if (lower.includes('red') || lower.includes('maroon') || lower.includes('pink') || lower.includes('rose')) dotColor = '#e11d48';
              else if (lower.includes('green') || lower.includes('olive') || lower.includes('sage')) dotColor = '#3f6212';
              else if (lower.includes('white') || lower.includes('ivory')) dotColor = '#e2e8f0';
              else if (lower.includes('gold') || lower.includes('mustard')) dotColor = '#d97706';
              else if (lower.includes('black') || lower.includes('charcoal')) dotColor = '#0f172a';
              return (
                <span
                  key={idx}
                  className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full border border-slate-300"
                  style={{ backgroundColor: dotColor }}
                />
              );
            })}
          </div>

          {/* Title */}
          <h3 className="text-xs sm:text-sm font-semibold text-slate-900 line-clamp-1 leading-snug group-hover:text-[#0284c7] transition-colors">
            {title}
          </h3>

          {/* Size Info */}
          <p className="text-[11px] text-slate-500 mt-0.5">
            সাইজ: {product.sizes.join(', ')}
          </p>
        </div>

        {/* Price and Cart Button Row */}
        <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm sm:text-base font-bold font-mono text-slate-950 tabular-nums">
              ৳ {currentPrice.toLocaleString('en-BD')}
            </span>
            {hasDiscount && (
              <span className="text-[10px] sm:text-xs text-slate-400 line-through font-mono tabular-nums">
                ৳ {product.sellingPrice.toLocaleString('en-BD')}
              </span>
            )}
          </div>

          {/* Blue round shopping bag button */}
          <button
            onClick={handleQuickAdd}
            className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center transition-all cursor-pointer shrink-0 ${
              addedAnimation
                ? 'bg-emerald-600 text-white'
                : 'bg-[#0f172a] hover:bg-[#0284c7] text-white shadow-xs'
            }`}
            title="ব্যাগে যোগ করুন"
            aria-label="Add to Bag"
          >
            {addedAnimation ? <Check className="w-3.5 h-3.5" /> : <ShoppingBag className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
          </button>
        </div>

        {/* Direct Easy Order Underneath Product */}
        <div className="mt-2.5 pt-2 border-t border-slate-100">
          <button
            onClick={handleDirectOrder}
            className="w-full py-1.5 px-2 bg-amber-50 hover:bg-[#0f172a] text-[#b45309] hover:text-white border border-amber-200 hover:border-[#0f172a] rounded-lg text-[11px] font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <Zap className="w-3 h-3 text-[#f59e0b] fill-current" />
            <span>সহজে অর্ডার করুন (COD)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
