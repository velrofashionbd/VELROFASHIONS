import React, { useState } from 'react';
import { X, CheckCircle, Truck, ShieldCheck, MapPin } from 'lucide-react';
import { Product, Order } from '../types';
import { BANGLADESH_DISTRICTS } from '../i18n';

interface QuickOrderModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const QuickOrderModal: React.FC<QuickOrderModalProps> = ({
  product,
  isOpen,
  onClose,
  onOrderSuccess
}) => {
  if (!isOpen || !product) return null;

  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'Standard');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0] || 'Standard');
  const [quantity, setQuantity] = useState(1);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [district, setDistrict] = useState('Dhaka');
  const [deliveryArea, setDeliveryArea] = useState('');
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bkash' | 'nagad'>('cod');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const currentPrice = product.salePrice || product.sellingPrice;
  const isDhaka = district.toLowerCase() === 'dhaka';
  const subtotal = currentPrice * quantity;
  const deliveryFee = subtotal >= 5000 ? 0 : (isDhaka ? 70 : 130);
  const total = subtotal + deliveryFee;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!customerName.trim()) {
      setErrorMsg('অনুগ্রহ করে আপনার নাম লিখুন।');
      return;
    }
    const cleanPhone = customerPhone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 11) {
      setErrorMsg('সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 01711XXXXXX)');
      return;
    }
    if (!address.trim()) {
      setErrorMsg('অনুগ্রহ করে আপনার পূর্ণ ঠিকানা লিখুন।');
      return;
    }

    setIsSubmitting(true);
    try {
      const orderPayload = {
        customerName: customerName.trim(),
        customerPhone: cleanPhone,
        customerEmail: '',
        district,
        deliveryArea: deliveryArea.trim() || district,
        address: address.trim(),
        notes: 'Quick Direct 1-Click Order',
        items: [
          {
            productId: product.id,
            variantId: `${product.id}-${selectedSize}-${selectedColor}`,
            sku: product.sku,
            title: product.title,
            size: selectedSize,
            color: selectedColor,
            quantity,
            price: currentPrice,
            costPrice: product.costPrice,
            image: product.images[0] || '',
            supplierName: product.supplierName || 'In-House Studio'
          }
        ],
        paymentMethod
      };

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'অর্ডার প্রক্রিয়া করা যায়নি');
      }
      onClose();
      onOrderSuccess(data.order);
    } catch (err: any) {
      setErrorMsg(err.message || 'অর্ডারে ত্রুটি হয়েছে');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div 
        onClick={(e) => e.stopPropagation()}
        className="relative bg-white rounded-2xl max-w-lg w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200 text-left"
      >
        {/* Modal Header */}
        <div className="sticky top-0 bg-[#0f172a] text-white p-4 flex items-center justify-between rounded-t-2xl z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#c29b38] flex items-center justify-center text-slate-950 font-bold text-xs">
              ১-ক্লিক
            </div>
            <div>
              <h3 className="font-bold text-sm">সহজে দ্রুত অর্ডার করুন (Quick Order)</h3>
              <p className="text-[11px] text-slate-300">ক্যাশ অন ডেলিভারিতে অর্ডার কনফার্ম করুন</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4">
          {/* Product Summary Header */}
          <div className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <img
              src={product.images[0]}
              alt={product.title}
              className="w-16 h-20 object-cover rounded-lg bg-slate-100 shrink-0"
            />
            <div className="flex-1 min-w-0">
              <h4 className="font-bold text-xs sm:text-sm text-slate-900 line-clamp-1">{product.title}</h4>
              <p className="text-[11px] text-slate-500 line-clamp-1">{product.titleBn || product.category}</p>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-sm font-bold text-[#0f172a] font-mono">
                  ৳ {currentPrice.toLocaleString('en-BD')}
                </span>
                {product.salePrice && product.salePrice < product.sellingPrice && (
                  <span className="text-[10px] text-slate-400 line-through font-mono">
                    ৳ {product.sellingPrice.toLocaleString('en-BD')}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Size & Color Selector */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                সাইজ নির্বাচন করুন
              </label>
              <select
                value={selectedSize}
                onChange={(e) => setSelectedSize(e.target.value)}
                className="w-full px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-medium"
              >
                {product.sizes.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                কালার নির্বাচন করুন
              </label>
              <select
                value={selectedColor}
                onChange={(e) => setSelectedColor(e.target.value)}
                className="w-full px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-medium"
              >
                {product.colors.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Quantity */}
          <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-700">পরিমাণ (Quantity):</span>
            <div className="flex items-center border border-slate-300 rounded-md bg-white">
              <button
                type="button"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="px-2.5 py-0.5 text-xs text-slate-600 hover:bg-slate-100"
              >
                -
              </button>
              <span className="px-3 py-0.5 text-xs font-mono font-bold text-slate-900">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity(quantity + 1)}
                className="px-2.5 py-0.5 text-xs text-slate-600 hover:bg-slate-100"
              >
                +
              </button>
            </div>
          </div>

          {/* Customer Delivery Fields */}
          <div className="space-y-3 pt-1 border-t border-slate-200">
            <h5 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#c29b38]" />
              <span>ডেলিভারি ঠিকানা:</span>
            </h5>
            <div>
              <label className="block text-[11px] font-medium text-slate-700 mb-1">
                আপনার নাম *
              </label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="যেমন: তানভীর হাসান"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>
            <div>
              <label className="block text-[11px] font-medium text-slate-700 mb-1">
                মোবাইল নম্বর * (১১ ডিজিট)
              </label>
              <input
                type="tel"
                required
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="01XXXXXXXXX"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">
                  জেলা নির্বাচন
                </label>
                <select
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full px-2.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-medium"
                >
                  {BANGLADESH_DISTRICTS.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">
                  থানা / এরিয়া
                </label>
                <input
                  type="text"
                  value={deliveryArea}
                  onChange={(e) => setDeliveryArea(e.target.value)}
                  placeholder="যেমন: মিরপুর / উত্তরা / বাড্ডা"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>
            </div>
            <div>
              <label className="block text-[11px] font-medium text-slate-700 mb-1">
                সম্পূর্ণ ঠিকানা *
              </label>
              <textarea
                required
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="বাসা নম্বর, রোড নম্বর, এলাকা"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="space-y-2 pt-2 border-t border-slate-200">
            <label className="block text-[11px] font-semibold text-slate-800">
              পেমেন্ট মাধ্যম
            </label>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setPaymentMethod('cod')}
                className={`py-2 px-2 rounded-lg border text-center font-medium cursor-pointer transition-all ${
                  paymentMethod === 'cod'
                    ? 'border-slate-900 bg-slate-900 text-white font-bold'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                ক্যাশ অন ডেলিভারি
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('bkash')}
                className={`py-2 px-2 rounded-lg border text-center font-medium cursor-pointer transition-all ${
                  paymentMethod === 'bkash'
                    ? 'border-[#e2136e] bg-[#e2136e] text-white font-bold'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                বিকাশ (bKash)
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('nagad')}
                className={`py-2 px-2 rounded-lg border text-center font-medium cursor-pointer transition-all ${
                  paymentMethod === 'nagad'
                    ? 'border-[#f7941d] bg-[#f7941d] text-white font-bold'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                নগদ (Nagad)
              </button>
            </div>
          </div>

          {/* Pricing Summary */}
          <div className="p-3 bg-slate-100 rounded-xl space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>পোশাকের মূল্য:</span>
              <span className="font-mono font-medium">৳ {subtotal.toLocaleString('en-BD')}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>ডেলিভারি চার্জ ({isDhaka ? 'ঢাকা' : 'ঢাকার বাইরে'}):</span>
              <span className="font-mono">৳ {deliveryFee}</span>
            </div>
            <div className="flex justify-between text-sm font-bold text-slate-900 pt-1.5 border-t border-slate-200">
              <span>সর্বমোট প্রদেয়:</span>
              <span className="font-mono text-base text-[#0f172a]">৳ {total.toLocaleString('en-BD')}</span>
            </div>
          </div>

          {errorMsg && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs">
              {errorMsg}
            </div>
          )}

          {/* Confirm Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 bg-[#0f172a] hover:bg-slate-800 text-white rounded-xl font-bold text-xs tracking-wide uppercase transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? (
              <span>অর্ডার সম্পন্ন হচ্ছে...</span>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 text-[#c29b38]" />
                <span>অর্ডার নিশ্চিত করুন (৳ {total.toLocaleString('en-BD')})</span>
              </>
            )}
          </button>

          <div className="flex items-center justify-center gap-4 text-[10px] text-slate-500 pt-1">
            <span className="flex items-center gap-1">
              <Truck className="w-3 h-3 text-slate-600" />
              দ্রুত হোম ডেলিভারি
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-slate-600" />
              পণ্য দেখে মূল্য পরিশোধ
            </span>
          </div>
        </form>
      </div>
    </div>
  );
};
