import React from 'react';
import { Phone, Mail, MapPin, Shield, Truck, RefreshCw, Lock } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface FooterProps {
  onNavigate: (view: string, param?: string) => void;
  onOpenAdmin: () => void;
  storeSettings?: any;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenAdmin, storeSettings }) => {
  const { language, t } = useLanguage();

  return (
    <footer className="bg-[#0f172a] text-slate-400 border-t border-slate-800 text-left text-xs">
      {/* Trust Badges Strip */}
      <div className="border-b border-slate-800 py-6 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-[#c29b38] shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-white font-semibold text-xs">{t.nationwideDelivery}</p>
              <p className="text-[11px] text-slate-500">
                {storeSettings?.deliveryTimeDhaka ? `${storeSettings.deliveryTimeDhaka} ঢাকায়` : '২৪-৪৮ ঘণ্টা ঢাকায়'} • {storeSettings?.deliveryTimeOutside || '৩-৫ দিন সারা দেশে'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-[#c29b38] shrink-0">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <p className="text-white font-semibold text-xs">{t.easyExchange}</p>
              <p className="text-[11px] text-slate-500">৭ দিনের সাইজ এক্সচেঞ্জ সুবিধা</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-[#c29b38] shrink-0">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <p className="text-white font-semibold text-xs">{t.authenticFabric}</p>
              <p className="text-[11px] text-slate-500">প্রিমিয়াম সুতি ও পিওর সিল্ক</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-[#c29b38] shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-white font-semibold text-xs">{t.securePayment}</p>
              <p className="text-[11px] text-slate-500">ক্যাশ অন ডেলিভারি ও বিকাশ</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
        {/* Brand & Address */}
        <div className="lg:col-span-2 space-y-4">
          <span className="text-xl font-serif font-bold tracking-tight text-white block">
            {storeSettings?.storeName || 'VELRO FASHION'}
          </span>
          <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
            {language === 'bn'
              ? (storeSettings?.storeTagline || 'বাংলাদেশের ঐতিহ্যবাহী কারুশিল্প ও আধুনিক সমকালীন পোশাকের মিলনমেলা।')
              : (storeSettings?.storeTaglineEn || "Bangladesh's premier online clothing store combining bespoke Bengali handloom heritage with contemporary dropshipped apparel.")}
          </p>
          <div className="space-y-2 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#c29b38] shrink-0" />
              <span>{storeSettings?.showroomAddress || t.dhakaOffice}</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#c29b38] shrink-0" />
              <a href={`tel:${storeSettings?.supportPhone || '+8801711982341'}`} className="hover:text-white transition-colors">
                {storeSettings?.supportPhone || t.callUs}
              </a>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#c29b38] shrink-0" />
              <a href={`mailto:${storeSettings?.supportEmail || 'support@velrofashion.com'}`} className="hover:text-white transition-colors">
                {storeSettings?.supportEmail || t.emailUs}
              </a>
            </div>
          </div>
        </div>

        {/* Fashion Categories */}
        <div className="space-y-3">
          <h4 className="text-white font-semibold text-xs tracking-wider uppercase font-mono">
            {language === 'bn' ? 'পোশাক বিভাগ' : 'Collections'}
          </h4>
          <ul className="space-y-2">
            <li>
              <button onClick={() => onNavigate('shop', 'Panjabi and Kurta')} className="hover:text-white transition-colors cursor-pointer">
                {t.navPanjabi}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('shop', 'Traditional Clothing')} className="hover:text-white transition-colors cursor-pointer">
                {t.navTraditional}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('shop', 'Three-Piece and Two-Piece')} className="hover:text-white transition-colors cursor-pointer">
                {t.navThreePiece}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('shop', 'Shirts and T-shirts')} className="hover:text-white transition-colors cursor-pointer">
                {t.navShirts}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('shop', 'Trousers and Jeans')} className="hover:text-white transition-colors cursor-pointer">
                {t.navTrousers}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('shop', "Kids' Fashion")} className="hover:text-white transition-colors cursor-pointer">
                {t.navKids}
              </button>
            </li>
          </ul>
        </div>

        {/* Customer Care & Policies */}
        <div className="space-y-3">
          <h4 className="text-white font-semibold text-xs tracking-wider uppercase font-mono">
            {language === 'bn' ? 'গ্রাহক সেবা' : 'Customer Care'}
          </h4>
          <ul className="space-y-2">
            <li>
              <button onClick={() => onNavigate('track-order')} className="hover:text-white transition-colors cursor-pointer text-[#c29b38] font-medium">
                {t.navTrackOrder}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('policy-shipping')} className="hover:text-white transition-colors cursor-pointer">
                {t.shippingPolicy}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('policy-return')} className="hover:text-white transition-colors cursor-pointer">
                {t.returnPolicy}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('policy-faq')} className="hover:text-white transition-colors cursor-pointer">
                {t.faq}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('policy-support')} className="hover:text-white transition-colors cursor-pointer">
                {t.customerSupport}
              </button>
            </li>
          </ul>
        </div>

        {/* Legal & Corporate */}
        <div className="space-y-3">
          <h4 className="text-white font-semibold text-xs tracking-wider uppercase font-mono">
            {language === 'bn' ? 'কোম্পানি' : 'Company'}
          </h4>
          <ul className="space-y-2">
            <li>
              <button onClick={() => onNavigate('policy-about')} className="hover:text-white transition-colors cursor-pointer">
                {t.aboutUs}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('policy-contact')} className="hover:text-white transition-colors cursor-pointer">
                {t.contactUs}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('policy-privacy')} className="hover:text-white transition-colors cursor-pointer">
                {t.privacyPolicy}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('policy-terms')} className="hover:text-white transition-colors cursor-pointer">
                {t.termsConditions}
              </button>
            </li>
            <li>
              <button onClick={onOpenAdmin} className="text-[#c29b38] hover:text-[#d8b14a] transition-colors cursor-pointer flex items-center gap-1 font-mono">
                <Shield className="w-3.5 h-3.5" />
                <span>{t.adminLogin}</span>
              </button>
            </li>
          </ul>
        </div>
      </div>

      {/* Payment & Logistics Badges Strip */}
      <div className="border-t border-slate-800/80 py-6 px-4 bg-slate-950/60">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-[11px] text-slate-500 font-mono">পেমেন্ট পার্টনার:</span>
            <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-mono font-bold">bKash</span>
            <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-mono font-bold">Nagad</span>
            <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-mono font-bold">Rocket</span>
            <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-mono font-bold">Cash on Delivery</span>
            <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-mono font-bold">SSLCommerz</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-500 font-mono">কুরিয়ার ডেলিভারি:</span>
            <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-mono">Steadfast Courier</span>
            <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-mono">Pathao Express</span>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-slate-900 py-4 px-4 text-center text-slate-500 text-[11px]">
        <p>&copy; {new Date().getFullYear()} {t.allRightsReserved}</p>
      </div>
    </footer>
  );
};
