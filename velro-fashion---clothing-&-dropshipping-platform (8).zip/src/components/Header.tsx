import React, { useState } from 'react';
import { ShoppingBag, Search, Menu, X, User } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useCart } from '../context/CartContext';

interface HeaderProps {
  currentView: string;
  onNavigate: (view: string, param?: string) => void;
  onOpenSearch: () => void;
  onOpenAdmin: () => void;
  storeSettings?: any;
}

export const Header: React.FC<HeaderProps> = ({
  onNavigate,
  onOpenSearch,
  onOpenAdmin,
  storeSettings
}) => {
  const { t } = useLanguage();
  const { totalItems, setIsCartOpen } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      {/* Top Header Navbar */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-100 shadow-xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5 flex items-center justify-between gap-2 sm:gap-4">
          
          {/* Left: Mobile Hamburger / Navigation Menu Toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 sm:p-2 text-slate-800 hover:text-slate-950 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6 stroke-[2.2]" />}
            </button>
          </div>

          {/* Center: VELRO FASHION Logo with Monogram & Tagline */}
          <div 
            onClick={() => onNavigate('home')}
            className="flex flex-col items-center justify-center cursor-pointer group select-none text-center"
          >
            <div className="flex items-center gap-1.5">
              <svg className="w-6 h-6 sm:w-7 sm:h-7 text-[#0284c7]" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4 6L14 23L24 6H19L14 16L9 6H4Z" fill="#0284c7" />
                <circle cx="10" cy="4" r="1.5" fill="#0284c7" />
                <circle cx="14" cy="3" r="1.5" fill="#0284c7" />
                <circle cx="18" cy="4" r="1.5" fill="#0284c7" />
              </svg>
              <span className="text-xl sm:text-2xl font-serif font-black tracking-tight text-[#0f172a] group-hover:text-[#0284c7] transition-colors leading-none">
                {storeSettings?.storeName || 'VELRO'}
                <span className="font-sans font-bold text-base sm:text-lg tracking-wider text-[#0284c7] ml-1.5">
                  FASHION
                </span>
              </span>
            </div>
            <span className="text-[8px] sm:text-[9px] font-mono tracking-[0.25em] text-slate-500 font-semibold uppercase mt-0.5">
              STYLE • COMFORT • YOU
            </span>
          </div>

          {/* Right: Cart with Counter Badge & Sign In / Account Button */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Bag with Count Badge */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 text-slate-800 hover:text-slate-950 transition-colors cursor-pointer"
              aria-label="Shopping Bag"
              title="Shopping Bag"
            >
              <ShoppingBag className="w-6 h-6 stroke-[1.8]" />
              <span className="absolute top-0.5 right-0.5 bg-[#0284c7] text-white font-bold text-[10px] sm:text-[11px] w-4.5 h-4.5 rounded-full flex items-center justify-center border-2 border-white">
                {totalItems}
              </span>
            </button>

            {/* User / Sign In Button */}
            <button
              onClick={onOpenAdmin}
              className="flex items-center gap-1.5 p-1.5 sm:px-2.5 sm:py-1.5 text-slate-700 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer text-left"
              title="Sign In / Admin Portal"
            >
              <User className="w-5 h-5 stroke-[1.8] text-slate-700" />
              <div className="hidden sm:flex flex-col text-[10px] leading-tight font-medium">
                <span className="font-bold text-slate-900">Sign In</span>
                <span className="text-slate-500">অ্যাডমিন</span>
              </div>
            </button>
          </div>
        </div>

        {/* Global Search Bar Under Header */}
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pb-3">
          <div 
            onClick={onOpenSearch}
            className="relative flex items-center w-full bg-slate-50 hover:bg-white border border-slate-200/90 hover:border-slate-400 rounded-full py-2 px-3.5 transition-all cursor-pointer shadow-2xs group"
          >
            <Search className="w-4 h-4 sm:w-5 sm:h-5 text-slate-400 group-hover:text-slate-600 mr-2.5 shrink-0" />
            <input
              type="text"
              readOnly
              placeholder="পোশাক খুঁজুন... (পাঞ্জাবি, শার্ট, থ্রি পিস, ডেনিম জিন্স)"
              className="w-full text-xs sm:text-sm text-slate-800 placeholder-slate-400 bg-transparent focus:outline-none cursor-pointer"
            />
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-2 animate-in fade-in slide-in-from-top-4 duration-150">
            <div className="flex flex-col space-y-1.5 text-xs sm:text-sm font-medium text-slate-800">
              <button
                onClick={() => { onNavigate('home'); setMobileMenuOpen(false); }}
                className="text-left py-2 px-3 rounded hover:bg-slate-50"
              >
                {t.navHome}
              </button>
              <button
                onClick={() => { onNavigate('shop', 'all'); setMobileMenuOpen(false); }}
                className="text-left py-2 px-3 rounded hover:bg-slate-50"
              >
                {t.navShopAll}
              </button>
              <button
                onClick={() => { onNavigate('shop', 'Shirts and T-shirts'); setMobileMenuOpen(false); }}
                className="text-left py-2 px-3 rounded hover:bg-slate-50"
              >
                শার্ট ও টি-শার্ট (Shirts)
              </button>
              <button
                onClick={() => { onNavigate('shop', 'Three-Piece and Two-Piece'); setMobileMenuOpen(false); }}
                className="text-left py-2 px-3 rounded hover:bg-slate-50"
              >
                থ্রি-পিস ও কুর্তি (Three Piece)
              </button>
              <button
                onClick={() => { onNavigate('shop', 'Panjabi and Kurta'); setMobileMenuOpen(false); }}
                className="text-left py-2 px-3 rounded hover:bg-slate-50"
              >
                পাঞ্জাবি ও কুর্তা (Panjabi)
              </button>
              <button
                onClick={() => { onNavigate('shop', 'Trousers and Jeans'); setMobileMenuOpen(false); }}
                className="text-left py-2 px-3 rounded hover:bg-slate-50"
              >
                ট্রাউজার ও জিন্স (Denim)
              </button>
              <button
                onClick={() => { onNavigate('shop', 'new-arrivals'); setMobileMenuOpen(false); }}
                className="text-left py-2 px-3 rounded hover:bg-slate-50 text-[#0284c7] font-bold"
              >
                নতুন কালেকশন (New Arrivals)
              </button>
              <button
                onClick={() => { onNavigate('track-order'); setMobileMenuOpen(false); }}
                className="text-left py-2 px-3 rounded hover:bg-slate-50 font-mono text-slate-600"
              >
                অর্ডার ট্র্যাক করুন (Track Order)
              </button>
              <button
                onClick={() => { onOpenAdmin(); setMobileMenuOpen(false); }}
                className="text-left py-2 px-3 rounded hover:bg-slate-50 text-[#c29b38] font-bold"
              >
                অ্যাডমিন পোর্টাল (Admin Portal)
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
