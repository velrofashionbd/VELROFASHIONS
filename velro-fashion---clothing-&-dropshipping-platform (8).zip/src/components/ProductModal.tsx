import React, { useState } from 'react';
import { X, ShoppingBag, ShieldCheck, Truck, RefreshCw, Check, ArrowRight } from 'lucide-react';
import { Product } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useCart } from '../context/CartContext';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onNavigateToCheckout: () => void;
  onQuickOrder?: (product: Product) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onNavigateToCheckout,
  onQuickOrder
}) => {
  const { language, t } = useLanguage();
  const { addToCart, setIsCartOpen } = useCart();

  if (!product) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'Standard');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0] || 'Standard');
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const title = language === 'bn' ? (product.titleBn || product.title) : product.title;
  const description = language === 'bn' ? (product.descriptionBn || product.description) : product.description;
  const shippingInfo = language === 'bn' ? (product.shippingInfoBn || product.shippingInfo) : product.shippingInfo;

  const currentPrice = product.salePrice || product.sellingPrice;
  const hasDiscount = product.salePrice && product.salePrice < product.sellingPrice;

  const currentVariant = product.variants?.find(
    v => v.size.toLowerCase() === selectedSize.toLowerCase() &&
         v.color.toLowerCase() === selectedColor.toLowerCase()
  ) || (product.variants && product.variants[0]);

  const stock = currentVariant ? currentVariant.stock : product.stockQuantity;

  const handleAddToCart = () => {
    addToCart(product, selectedSize, selectedColor, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const handleBuyNow = () => {
    addToCart(product, selectedSize, selectedColor, quantity);
    onClose();
    setIsCartOpen(false);
    onNavigateToCheckout();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        onClick={(e) => e.stopPropagation()}
        className="relative bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200 grid grid-cols-1 md:grid-cols-2 text-left"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-slate-500 hover:text-slate-900 bg-white/80 hover:bg-white rounded-full transition-colors cursor-pointer border border-slate-200"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Column: Image Gallery */}
        <div className="p-4 sm:p-6 flex flex-col gap-3 bg-slate-50/50">
          <div className="aspect-[3/4] w-full rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
            <img
              src={product.images[activeImageIndex] || product.images[0]}
              alt={title}
              className="w-full h-full object-cover object-top"
            />
          </div>
          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-16 h-20 shrink-0 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                    activeImageIndex === idx ? 'border-slate-900 shadow-sm' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Product Specs & Ordering */}
        <div className="p-4 sm:p-8 flex flex-col justify-between space-y-5 sm:space-y-6">
          <div>
            {/* Category and SKU metadata */}
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
              <span>{product.category}</span>
              <span aria-hidden="true">•</span>
              <span className="font-mono">{product.sku}</span>
              <span aria-hidden="true">•</span>
              <span className="text-emerald-700 font-medium">
                {stock > 0 ? `${t.inStock} (${stock})` : t.outOfStock}
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl font-serif font-bold text-slate-900 leading-tight">
              {title}
            </h1>

            {/* Price section */}
            <div className="mt-3 flex items-baseline gap-3">
              <span className="text-2xl font-bold font-mono text-slate-950 tabular-nums">
                ৳ {currentPrice.toLocaleString('en-BD')}
              </span>
              {hasDiscount && (
                <span className="text-sm text-slate-400 line-through font-mono tabular-nums">
                  ৳ {product.sellingPrice.toLocaleString('en-BD')}
                </span>
              )}
              {hasDiscount && (
                <span className="text-xs bg-emerald-50 text-emerald-800 font-mono px-2 py-0.5 rounded border border-emerald-200">
                  Save ৳ {(product.sellingPrice - currentPrice).toLocaleString('en-BD')}
                </span>
              )}
            </div>

            {/* Description */}
            <p className="mt-4 text-xs sm:text-sm text-slate-600 leading-relaxed">
              {description}
            </p>

            {/* Size Selector */}
            <div className="mt-5">
              <div className="flex justify-between items-center text-xs font-semibold text-slate-700 mb-2">
                <span>{t.size}:</span>
                <span className="text-slate-500 font-mono">
                  {selectedSize} {currentVariant ? `(মজুদ: ${stock})` : ''}
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => {
                  const variantForSize = product.variants?.find(
                    v => v.size.toLowerCase() === s.toLowerCase() && v.color.toLowerCase() === selectedColor.toLowerCase()
                  ) || product.variants?.find(v => v.size.toLowerCase() === s.toLowerCase());

                  const isAvailable = variantForSize ? variantForSize.stock > 0 : stock > 0;

                  return (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`px-3.5 py-1.5 text-xs font-mono font-medium rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 ${
                        selectedSize === s
                          ? 'border-slate-900 bg-slate-900 text-white shadow-sm font-bold'
                          : isAvailable
                          ? 'border-slate-200 text-slate-700 hover:border-slate-400 bg-white'
                          : 'border-slate-100 text-slate-300 bg-slate-50 line-through'
                      }`}
                    >
                      <span>{s}</span>
                      {!isAvailable && <span className="text-[10px] text-rose-400">(শেষ)</span>}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Color Selector */}
            {product.colors.length > 0 && (
              <div className="mt-4">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-700 mb-2">
                  <span>{t.color}:</span>
                  <span className="text-slate-700 font-medium">{selectedColor}</span>
                </div>
                <div className="flex flex-wrap gap-2.5">
                  {product.colors.map((c) => {
                    let dotColor = '#1e293b';
                    const lower = c.toLowerCase();
                    if (lower.includes('blue') || lower.includes('navy')) dotColor = '#1e3a8a';
                    else if (lower.includes('maroon') || lower.includes('red')) dotColor = '#881337';
                    else if (lower.includes('green') || lower.includes('emerald')) dotColor = '#065f46';
                    else if (lower.includes('white') || lower.includes('ivory')) dotColor = '#f8fafc';
                    else if (lower.includes('black') || lower.includes('charcoal')) dotColor = '#09090b';
                    else if (lower.includes('gold') || lower.includes('champagne')) dotColor = '#d97706';
                    else if (lower.includes('pink') || lower.includes('rose')) dotColor = '#e11d48';

                    return (
                      <button
                        key={c}
                        onClick={() => setSelectedColor(c)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all cursor-pointer flex items-center gap-2 ${
                          selectedColor === c
                            ? 'border-slate-900 bg-slate-100 text-slate-900 font-semibold ring-1 ring-slate-900'
                            : 'border-slate-200 text-slate-600 hover:border-slate-300 bg-white'
                        }`}
                      >
                        <span 
                          className="w-3.5 h-3.5 rounded-full border border-slate-300 shrink-0" 
                          style={{ backgroundColor: dotColor }} 
                        />
                        <span>{c}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="mt-4 flex items-center gap-4">
              <span className="text-xs font-semibold text-slate-700">{t.quantity}:</span>
              <div className="flex items-center border border-slate-200 rounded-lg bg-white overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-1 text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  -
                </button>
                <span className="px-4 py-1 text-xs font-mono font-bold text-slate-900">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(Math.min(stock, quantity + 1))}
                  className="px-3 py-1 text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-slate-100 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleAddToCart}
                disabled={stock <= 0}
                className={`py-3 px-4 rounded-xl font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer border border-slate-900 ${
                  added
                    ? 'bg-emerald-700 text-white border-emerald-700'
                    : 'bg-white text-slate-900 hover:bg-slate-50'
                }`}
              >
                {added ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
                <span>{added ? 'Added to Bag' : t.addToCart}</span>
              </button>
              <button
                onClick={handleBuyNow}
                disabled={stock <= 0}
                className="py-3 px-4 rounded-xl font-semibold text-xs text-white bg-[#0f172a] hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <span>{t.buyNow}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Direct 1-Click Order Button */}
            <button
              onClick={() => {
                onClose();
                if (onQuickOrder) onQuickOrder(product);
              }}
              className="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-colors"
            >
              <span>সহজে অর্ডার করুন (Cash on Delivery)</span>
            </button>

            {/* Delivery & Trust highlights */}
            <div className="bg-slate-50 rounded-xl p-3 text-[11px] text-slate-600 space-y-1.5 border border-slate-100">
              <div className="flex items-center gap-2">
                <Truck className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <span>{shippingInfo}</span>
              </div>
              <div className="flex items-center gap-2">
                <RefreshCw className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <span>{language === 'bn' ? '৭ দিনের সহজ সাইজ পরিবর্তন গ্যারান্টি।' : '7-Day Hassle-Free Size Exchange.'}</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <span>{language === 'bn' ? 'ক্যাশ অন ডেলিভারি ও পার্সেল চেক করে গ্রহণের সুযোগ।' : 'Cash on Delivery with parcel inspection upon delivery.'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
