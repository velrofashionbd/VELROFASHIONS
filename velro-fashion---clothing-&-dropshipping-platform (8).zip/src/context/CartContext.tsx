import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Product } from '../types';

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, size: string, color: string, quantity?: number) => void;
  removeFromCart: (variantId: string) => void;
  updateQuantity: (variantId: string, quantity: number) => void;
  clearCart: () => void;
  coupon: { code: string; discountAmount: number; discountType: string; value: number } | null;
  applyCouponCode: (code: string) => Promise<{ success: boolean; message: string }>;
  removeCoupon: () => void;
  subtotal: number;
  discount: number;
  total: number;
  totalItems: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('vf_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [coupon, setCoupon] = useState<{
    code: string;
    discountAmount: number;
    discountType: string;
    value: number;
  } | null>(() => {
    try {
      const saved = localStorage.getItem('vf_coupon');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('vf_cart', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    if (coupon) {
      localStorage.setItem('vf_coupon', JSON.stringify(coupon));
    } else {
      localStorage.removeItem('vf_coupon');
    }
  }, [coupon]);

  const addToCart = (product: Product, size: string, color: string, quantity = 1) => {
    const matchedVariant = product.variants?.find(
      v => v.size.toLowerCase() === size.toLowerCase() && v.color.toLowerCase() === color.toLowerCase()
    ) || (product.variants && product.variants[0]);

    const variantId = matchedVariant ? matchedVariant.id : `${product.id}-${size}-${color}`;
    const unitPrice = product.salePrice || product.sellingPrice;

    setItems(prev => {
      const existing = prev.find(item => item.variantId === variantId);
      if (existing) {
        return prev.map(item =>
          item.variantId === variantId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        const newItem: CartItem = {
          productId: product.id,
          variantId,
          sku: matchedVariant?.sku || product.sku,
          title: product.title,
          titleBn: product.titleBn,
          size,
          color,
          price: unitPrice,
          costPrice: product.costPrice,
          quantity,
          image: product.images[0] || '',
          supplierName: product.supplierName,
          supplierProductId: product.supplierProductId,
          supplierVariantId: matchedVariant?.supplierVariantId
        };
        return [...prev, newItem];
      }
    });

    setIsCartOpen(true);
  };

  const removeFromCart = (variantId: string) => {
    setItems(prev => prev.filter(item => item.variantId !== variantId));
  };

  const updateQuantity = (variantId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(variantId);
      return;
    }
    setItems(prev =>
      prev.map(item =>
        item.variantId === variantId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setItems([]);
    setCoupon(null);
  };

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const applyCouponCode = async (code: string) => {
    try {
      const res = await fetch('/api/cart/validate-coupon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, subtotal })
      });
      const data = await res.json();
      if (res.ok && data.valid) {
        setCoupon({
          code: data.code,
          discountAmount: data.discountAmount,
          discountType: data.discountType,
          value: data.value
        });
        return { success: true, message: data.message };
      } else {
        return { success: false, message: data.message || 'Invalid coupon code' };
      }
    } catch {
      return { success: false, message: 'Could not validate coupon code' };
    }
  };

  const removeCoupon = () => {
    setCoupon(null);
  };

  const discount = coupon ? coupon.discountAmount : 0;
  const total = Math.max(0, subtotal - discount);
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        coupon,
        applyCouponCode,
        removeCoupon,
        subtotal,
        discount,
        total,
        totalItems,
        isCartOpen,
        setIsCartOpen
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
