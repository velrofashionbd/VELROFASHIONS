import React, { createContext, useContext, useState, useEffect } from 'react';
import { StoreSettings } from '../types';

interface SettingsContextType {
  settings: StoreSettings;
  updateSettingsState: (newSettings: Partial<StoreSettings>) => void;
  refreshSettings: () => Promise<void>;
  loading: boolean;
}

export const DEFAULT_STORE_SETTINGS: StoreSettings = {
  storeName: 'VELRO FASHION',
  storeNameBn: 'ভেলরো ফ্যাশন',
  storeTagline: 'অভিজাত বাংলাদেশী ও সমকালীন ফ্যাশন',
  storeTaglineEn: 'Curated Bangladeshi & Contemporary Fashion',
  announcementBarText: 'সারা দেশে হোম ডেলিভারি | ক্যাশ অন ডেলিভারি ও বিকাশ ভেরিফাইড',
  announcementBarTextEn: 'Nationwide Fast Delivery & Cash on Delivery Available',
  showAnnouncementBar: true,
  currency: 'BDT',
  currencySymbol: '৳',
  defaultDeliveryFeeDhaka: 70,
  defaultDeliveryFeeOutside: 130,
  freeShippingThreshold: 5000,
  deliveryTimeDhaka: '২৪-৪৮ ঘণ্টা',
  deliveryTimeOutside: '৩-৫ কার্যদিবস',
  courierPreference: 'steadfast',
  supportPhone: '+880 1711-982341',
  whatsappNumber: '+8801711982341',
  supportEmail: 'support@velrofashion.com',
  showroomAddress: 'রোড ১১, ব্লক ডি, বনানী, ঢাকা-১২১৩, বাংলাদেশ',
  officeHours: '১০:০০ AM - ১০:০০ PM',
  enableCod: true,
  enableBkash: true,
  enableNagad: true,
  enableRocket: true,
  enableSslcommerz: true,
  bkashMerchantNumber: '01711-982341',
  nagadMerchantNumber: '01711-982341',
  rocketMerchantNumber: '01711-982341-8',
  autoFulfillPaidOrders: true,
  allowCodFulfillment: true,
  defaultMarkupPercentage: 90,
  minProfitMarginBdt: 400,
  enableSandboxPayments: true
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<StoreSettings>(DEFAULT_STORE_SETTINGS);
  const [loading, setLoading] = useState(true);

  const refreshSettings = async () => {
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const data = await res.json();
        if (data.settings) {
          setSettings(prev => ({ ...prev, ...data.settings }));
        }
      }
    } catch (err) {
      console.error('Failed to load settings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshSettings();
  }, []);

  const updateSettingsState = (newSettings: Partial<StoreSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  return (
    <SettingsContext.Provider value={{ settings, updateSettingsState, refreshSettings, loading }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
