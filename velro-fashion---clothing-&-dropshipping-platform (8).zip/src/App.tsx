import { useState, useEffect } from 'react';
import { LanguageProvider } from './context/LanguageContext';
import { CartProvider } from './context/CartContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { SearchModal } from './components/SearchModal';
import { ProductModal } from './components/ProductModal';
import { QuickOrderModal } from './components/QuickOrderModal';
import { LiveSupportWidget } from './components/LiveSupportWidget';
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { TrackOrderPage } from './pages/TrackOrderPage';
import { PolicyPages } from './pages/PolicyPages';
import { AdminLogin } from './admin/AdminLogin';
import { AdminDashboard } from './admin/AdminDashboard';
import { Product, Category, Order } from './types';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [quickOrderProduct, setQuickOrderProduct] = useState<Product | null>(null);
  const [quickOrderOpen, setQuickOrderOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  // Admin authentication state
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem('vf_admin_token') || (window as any).__vf_admin_token || null;
    } catch {
      return null;
    }
  });
  const [adminUser, setAdminUser] = useState<string>(() => {
    try {
      return localStorage.getItem('vf_admin_user') || (window as any).__vf_admin_user || 'RuhinurRahman';
    } catch {
      return 'RuhinurRahman';
    }
  });
  const [requiresPasswordChange, setRequiresPasswordChange] = useState(false);

  // Completed order for confirmation page
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  // Global store settings
  const [storeSettings, setStoreSettings] = useState<any>(null);

  // Preloaded track query
  const [trackParams, setTrackParams] = useState<{ orderNumber: string; phone: string }>({
    orderNumber: '',
    phone: ''
  });

  // Check URL path on mount
  useEffect(() => {
    const path = window.location.pathname;
    const hash = window.location.hash;
    if (path.includes('/admin') || hash.includes('admin')) {
      if (adminToken) {
        setCurrentView('admin-dashboard');
      } else {
        setCurrentView('admin-login');
      }
    }
  }, [adminToken]);

  // Fetch initial catalog and settings
  const loadCatalog = async () => {
    try {
      const [prodRes, catRes, setRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/categories'),
        fetch('/api/settings')
      ]);

      if (prodRes.ok) {
        const prodData = await prodRes.json();
        setProducts(prodData.products || []);
      }
      if (catRes.ok) {
        const catData = await catRes.json();
        setCategories(catData.categories || []);
      }
      if (setRes.ok) {
        const setData = await setRes.json();
        setStoreSettings(setData.settings || null);
      }
    } catch (err) {
      console.error('Failed to load initial catalog or settings:', err);
    }
  };

  useEffect(() => {
    loadCatalog();
  }, []);

  // Navigation router
  const handleNavigate = (view: string, param?: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (view === 'shop') {
      setSelectedCategory(param || 'all');
      setCurrentView('shop');
    } else {
      setCurrentView(view);
    }
  };

  // Admin auth handlers
  const handleAdminLoginSuccess = (token: string, username: string, reqPassChange: boolean) => {
    setAdminToken(token);
    setAdminUser(username);
    setRequiresPasswordChange(reqPassChange);
    try {
      localStorage.setItem('vf_admin_token', token);
      localStorage.setItem('vf_admin_user', username);
    } catch {
      (window as any).__vf_admin_token = token;
      (window as any).__vf_admin_user = username;
    }
    setCurrentView('admin-dashboard');
  };

  const handleAdminLogout = async () => {
    try {
      await fetch('/api/admin/logout', { method: 'POST', credentials: 'include' });
    } catch {}
    setAdminToken(null);
    try {
      localStorage.removeItem('vf_admin_token');
      localStorage.removeItem('vf_admin_user');
    } catch {}
    delete (window as any).__vf_admin_token;
    delete (window as any).__vf_admin_user;
    setCurrentView('admin-login');
  };

  return (
    <LanguageProvider>
      <CartProvider>
        <div className="min-h-screen flex flex-col bg-[#faf9f6] text-slate-900 selection:bg-[#c29b38]/30 selection:text-slate-900 font-sans overflow-x-hidden w-full">
          
          {/* Header & Nav if not in Admin Portal */}
          {currentView !== 'admin-login' && currentView !== 'admin-dashboard' && (
            <Header
              currentView={currentView}
              onNavigate={handleNavigate}
              onOpenSearch={() => setSearchOpen(true)}
              storeSettings={storeSettings}
              onOpenAdmin={() => {
                if (adminToken) {
                  setCurrentView('admin-dashboard');
                } else {
                  setCurrentView('admin-login');
                }
              }}
            />
          )}

          {/* Main Content Area */}
          <main className="flex-1 w-full overflow-x-hidden">
            {/* 1. Home Page */}
            {currentView === 'home' && (
              <HomePage
                categories={categories}
                products={products}
                onSelectProduct={(p) => setSelectedProduct(p)}
                onNavigateToCategory={(slug) => {
                  const matched = categories.find(c => c.slug === slug);
                  handleNavigate('shop', matched ? matched.nameEn : slug);
                }}
                onNavigateToShop={(filter) => handleNavigate('shop', filter)}
                onQuickOrder={(p) => {
                  setQuickOrderProduct(p);
                  setQuickOrderOpen(true);
                }}
              />
            )}

            {/* 2. Shop Page */}
            {currentView === 'shop' && (
              <ShopPage
                products={products}
                initialCategory={selectedCategory}
                onSelectProduct={(p) => setSelectedProduct(p)}
                onQuickOrder={(p) => {
                  setQuickOrderProduct(p);
                  setQuickOrderOpen(true);
                }}
              />
            )}

            {/* 3. Checkout Page */}
            {currentView === 'checkout' && (
              <CheckoutPage
                onOrderSuccess={(order) => {
                  setConfirmedOrder(order);
                  setCurrentView('order-confirmation');
                  loadCatalog();
                }}
                onBackToShop={() => handleNavigate('shop', 'all')}
              />
            )}

            {/* 4. Order Confirmation Page */}
            {currentView === 'order-confirmation' && confirmedOrder && (
              <OrderConfirmationPage
                order={confirmedOrder}
                onNavigateToTrack={(ordNum, phone) => {
                  setTrackParams({ orderNumber: ordNum, phone });
                  setCurrentView('track-order');
                }}
                onBackToShop={() => handleNavigate('shop', 'all')}
              />
            )}

            {/* 5. Track Order Page */}
            {currentView === 'track-order' && (
              <TrackOrderPage
                initialOrderNumber={trackParams.orderNumber}
                initialPhone={trackParams.phone}
              />
            )}

            {/* 6. Policy Pages */}
            {currentView.startsWith('policy-') && (
              <PolicyPages
                policyType={currentView.replace('policy-', '') as any}
              />
            )}

            {/* 7. Admin Login */}
            {currentView === 'admin-login' && (
              <AdminLogin
                onLoginSuccess={handleAdminLoginSuccess}
                onBackToStore={() => setCurrentView('home')}
              />
            )}

            {/* 8. Admin Dashboard */}
            {currentView === 'admin-dashboard' && (
              <AdminDashboard
                adminUsername={adminUser}
                initialRequiresPasswordChange={requiresPasswordChange}
                onLogout={handleAdminLogout}
                onReturnToStore={() => {
                  loadCatalog();
                  setCurrentView('home');
                }}
              />
            )}
          </main>

          {/* Footer (storefront only) */}
          {currentView !== 'admin-login' && currentView !== 'admin-dashboard' && (
            <Footer
              onNavigate={handleNavigate}
              storeSettings={storeSettings}
              onOpenAdmin={() => {
                if (adminToken) {
                  setCurrentView('admin-dashboard');
                } else {
                  setCurrentView('admin-login');
                }
              }}
            />
          )}

          {/* Slide-out Cart Drawer */}
          <CartDrawer
            onNavigateToCheckout={() => setCurrentView('checkout')}
            onNavigateToShop={() => handleNavigate('shop', 'all')}
          />

          {/* Live Search Modal */}
          <SearchModal
            isOpen={searchOpen}
            onClose={() => setSearchOpen(false)}
            products={products}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onNavigateToShop={(cat) => handleNavigate('shop', cat)}
          />

          {/* Product Quick View & Details Modal */}
          {selectedProduct && (
            <ProductModal
              product={selectedProduct}
              onClose={() => setSelectedProduct(null)}
              onNavigateToCheckout={() => setCurrentView('checkout')}
              onQuickOrder={(p) => {
                setQuickOrderProduct(p);
                setQuickOrderOpen(true);
              }}
            />
          )}

          {/* Direct 1-Click Easy Quick Order Modal */}
          <QuickOrderModal
            product={quickOrderProduct}
            isOpen={quickOrderOpen}
            onClose={() => {
              setQuickOrderOpen(false);
              setQuickOrderProduct(null);
            }}
            onOrderSuccess={(order) => {
              setConfirmedOrder(order);
              setCurrentView('order-confirmation');
              loadCatalog();
            }}
          />

          {/* Floating Customer Support Concierge */}
          {currentView !== 'admin-login' && currentView !== 'admin-dashboard' && (
            <LiveSupportWidget />
          )}
        </div>
      </CartProvider>
    </LanguageProvider>
  );
}
