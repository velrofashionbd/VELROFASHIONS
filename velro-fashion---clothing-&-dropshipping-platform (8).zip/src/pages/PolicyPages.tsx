import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  CheckCircle,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface PolicyPageProps {
  policyType: 'about' | 'contact' | 'faq' | 'shipping' | 'return' | 'privacy' | 'terms' | 'support';
}

export const PolicyPages: React.FC<PolicyPageProps> = ({ policyType }) => {
  const { language, t } = useLanguage();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [ticketSubmitted, setTicketSubmitted] = useState(false);

  const faqs = [
    {
      qEn: 'How long does delivery take inside Dhaka and nationwide?',
      qBn: 'ঢাকা ও সমগ্র বাংলাদেশে ডেলিভারি পেতে কতদিন সময় লাগে?',
      aEn: 'Orders in Dhaka City are delivered within 24 to 48 hours via Steadfast Express or Pathao. Nationwide deliveries across all 64 districts typically arrive within 3 to 5 business days.',
      aBn: 'ঢাকা সিটির ভেতরে Steadfast ও Pathao কুরিয়ারের মাধ্যমে ২৪ থেকে ৪৮ ঘণ্টার মধ্যে ডেলিভারি সম্পন্ন হয়। ঢাকার বাইরে সমগ্র বাংলাদেশের ৬৪ জেলায় ৩ থেকে ৫ কার্যদিবসের মধ্যে ডেলিভারি পৌঁছে যায়।'
    },
    {
      qEn: 'Do you offer Cash on Delivery (COD)?',
      qBn: 'ক্যাশ অন ডেলিভারি (COD) সুবিধা আছে কি?',
      aEn: 'Yes! We offer 100% Cash on Delivery across all districts of Bangladesh. You can inspect the package upon arrival and pay the delivery rider directly in cash.',
      aBn: 'হ্যাঁ! সমগ্র বাংলাদেশে শতভাগ ক্যাশ অন ডেলিভারি সুবিধা রয়েছে। ডেলিভারি রাইডারের নিকট থেকে পণ্য বুঝে পেয়ে মূল্য পরিশোধ করতে পারবেন।'
    },
    {
      qEn: 'What is your size exchange and return policy?',
      qBn: 'সাইজ না মিললে এক্সচেঞ্জ বা পরিবর্তনের নিয়ম কি?',
      aEn: 'We offer a 7-day hassle-free size replacement guarantee. If a Panjabi, shirt, or jeans does not fit perfectly, contact our helpline (+880 1711-982341) within 7 days with the original tags intact for an exchange.',
      aBn: 'ভেলরো ফ্যাশন দিচ্ছে ৭ দিনের সহজ সাইজ এক্সচেঞ্জ সুবিধা। পোশাকের সাইজ বা ফিটিং নিয়ে সমস্যা হলে অক্ষত ট্যাগসহ আমাদের হেল্পলাইনে (+৮৮০ ১৭১১-৯৮২৩৪১) যোগাযোগ করলে আমাদের রাইডার সাইজ এক্সচেঞ্জ সম্পন্ন করবে।'
    },
    {
      qEn: 'How does VELRO FASHION ensure clothing quality?',
      qBn: 'কাপড়ের কোয়ালিটি কীভাবে নিশ্চিত করা হয়?',
      aEn: 'Our catalog combines heritage Bangladeshi handloom artisans (Dhakai Jamdani from Narayanganj) with quality-vetted dropshipping suppliers (combed cotton, Egyptian cotton, and selvedge denim). Every piece is pre-checked before courier manifest creation.',
      aBn: 'আমাদের নিজস্ব কোয়ালিটি কন্ট্রোল টিম প্রতিটি পাঞ্জাবি, শাড়ি ও শার্টের ফেব্রিক কাউন্ট ও সেলাই যাচাই করে কুরিয়ারে হস্তান্তর করে।'
    },
    {
      qEn: 'Can I track my order in real-time?',
      qBn: 'অর্ডার ট্র্যাক করার উপায় কি?',
      aEn: 'Yes! Navigate to "Track Order" in the top bar, enter your Order Number (e.g. VF-2026-XXXX) and your 11-digit mobile number to view live consignment milestones and courier dispatch updates.',
      aBn: 'হ্যাঁ! ওয়েবসাইটের "Track Order" মেন্যুতে গিয়ে আপনার অর্ডার নম্বর (যেমন: VF-2026-XXXX) ও মোবাইল নম্বর দিলেই লাইভ স্ট্যাটাস দেখতে পাবেন।'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-left space-y-10">
      
      {/* 1. ABOUT US */}
      {policyType === 'about' && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h1 className="text-3xl font-serif font-bold text-slate-900">{t.aboutUs}</h1>
            <p className="text-xs text-slate-500 font-mono mt-1">VELRO FASHION BANGLADESH • EST. 2026</p>
          </div>
          
          <div className="prose prose-slate text-sm leading-relaxed space-y-4 text-slate-700">
            <p>
              Welcome to <strong>VELRO FASHION</strong>, Bangladesh’s forward-thinking clothing brand where timeless Bengali craftsmanship converges with modern dropshipping automation and contemporary styling.
            </p>
            <p>
              Born in Dhaka, VELRO was founded with a singular ambition: to provide discerning men, women, and children across Bangladesh with impeccably tailored garments that celebrate tradition without compromising on modern fit and convenience.
            </p>
            <h3 className="text-base font-bold text-slate-900 pt-2">Our Dual Supply Engine: Artisan Heritage &amp; Global Dropshipping</h3>
            <p>
              Unlike traditional retail boutiques with rigid inventory limits, VELRO combines local master weavers such as our Narayanganj pit-loom Jamdani artisans with a modern, automated dropshipping routing hub. We connect directly with certified manufacturing partners via CJdropshipping, DSers, and specialized apparel ateliers. This hybrid model allows us to offer vast curated wardrobes at transparent prices while ensuring rigorous quality control.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="font-bold text-slate-900 block text-sm">100% Quality Fabric</span>
                <span className="text-xs text-slate-500">Combed Egyptian cotton, pure silks, and heavy selvedge denim.</span>
              </div>
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="font-bold text-slate-900 block text-sm">64 Districts Delivery</span>
                <span className="text-xs text-slate-500">Fast home delivery via Steadfast and Pathao logistics networks.</span>
              </div>
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="font-bold text-slate-900 block text-sm">Customer First</span>
                <span className="text-xs text-slate-500">Hassle-free size exchanges and dedicated live concierge care.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. CONTACT US */}
      {policyType === 'contact' && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h1 className="text-3xl font-serif font-bold text-slate-900">{t.contactUs}</h1>
            <p className="text-xs text-slate-500 mt-1">Get in touch with our Dhaka headquarters and concierge desk</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6 text-sm text-slate-700">
              <div className="p-5 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#c29b38] shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900">Showroom &amp; Fulfillment Center:</strong>
                    <p className="text-xs text-slate-600">Road 11, Block D, Banani, Dhaka-1213, Bangladesh</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-[#c29b38] shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900">Customer Helpline &amp; WhatsApp:</strong>
                    <p className="text-xs text-slate-600">+880 1711-982341 (10 AM - 10 PM Everyday)</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-[#c29b38] shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900">Email Enquiries:</strong>
                    <p className="text-xs text-slate-600">support@velrofashion.com / orders@velrofashion.com</p>
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-500 leading-relaxed">
                For wholesale, corporate gifting, dropshipping supplier onboarding, or press inquiries, please mention your organization in the message subject.
              </p>
            </div>

            {/* Inquiry Form */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
              {contactSubmitted ? (
                <div className="text-center py-8 space-y-3">
                  <CheckCircle className="w-10 h-10 text-emerald-600 mx-auto" />
                  <h4 className="text-base font-semibold text-slate-900">Message Received!</h4>
                  <p className="text-xs text-slate-600">Our customer care representative will contact you within 2 hours.</p>
                </div>
              ) : (
                <form onSubmit={(e) => { e.preventDefault(); setContactSubmitted(true); }} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Your Name *</label>
                    <input required type="text" placeholder="e.g. Mahir Faysal" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900" />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Phone Number *</label>
                    <input required type="tel" placeholder="01XXXXXXXXX" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono" />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Subject</label>
                    <input type="text" placeholder="Size inquiry, Order follow-up, etc." className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900" />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Message *</label>
                    <textarea required rows={3} placeholder="How can we assist you today?" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900" />
                  </div>
                  <button type="submit" className="w-full py-2.5 bg-[#0f172a] hover:bg-slate-800 text-white rounded-lg font-semibold transition-colors cursor-pointer">
                    Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. FAQ */}
      {policyType === 'faq' && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h1 className="text-3xl font-serif font-bold text-slate-900">{t.faq}</h1>
            <p className="text-xs text-slate-500 mt-1">Answers to your frequently asked questions</p>
          </div>

          <div className="space-y-3">
            {faqs.map((f, idx) => (
              <div key={idx} className="border border-slate-200 rounded-xl overflow-hidden bg-white">
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full p-4 text-left flex items-center justify-between font-semibold text-xs sm:text-sm text-slate-900 hover:bg-slate-50 transition-colors"
                >
                  <span>{language === 'bn' ? f.qBn : f.qEn}</span>
                  {openFaq === idx ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
                </button>
                {openFaq === idx && (
                  <div className="p-4 pt-0 text-xs sm:text-sm text-slate-600 border-t border-slate-100 bg-slate-50/50 leading-relaxed">
                    <p>{language === 'bn' ? f.aBn : f.aEn}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. SHIPPING POLICY */}
      {policyType === 'shipping' && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h1 className="text-3xl font-serif font-bold text-slate-900">{t.shippingPolicy}</h1>
            <p className="text-xs text-slate-500 font-mono mt-1">REVISED FOR 2026 LOGISTICS</p>
          </div>

          <div className="prose prose-slate text-xs sm:text-sm leading-relaxed space-y-4 text-slate-700">
            <h3 className="text-base font-bold text-slate-900">1. Delivery Zones and Charges</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left border border-slate-200 rounded-lg text-xs">
                <thead className="bg-slate-100 font-mono">
                  <tr>
                    <th className="p-3 border-b">Destination</th>
                    <th className="p-3 border-b">Standard Timeline</th>
                    <th className="p-3 border-b">Delivery Fee</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  <tr>
                    <td className="p-3 font-sans">Dhaka Metropolitan Area</td>
                    <td className="p-3">24 to 48 Hours</td>
                    <td className="p-3">৳ 70</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-sans">Outside Dhaka (All 63 Districts)</td>
                    <td className="p-3">3 to 5 Business Days</td>
                    <td className="p-3">৳ 130</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-sans font-bold">Orders Above ৳ 5,000</td>
                    <td className="p-3">Standard</td>
                    <td className="p-3 font-bold text-emerald-700">FREE NATIONWIDE</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-base font-bold text-slate-900 pt-3">2. Official Courier Partners</h3>
            <p>
              Consignments are fulfilled and dispatched via Bangladesh’s trusted couriers: <strong>Steadfast Courier</strong> and <strong>Pathao Express</strong>. Customers receive real-time SMS alerts containing the tracking number once manifest barcodes are scanned.
            </p>

            <h3 className="text-base font-bold text-slate-900 pt-3">3. Multi-Supplier Shipments</h3>
            <p>
              If your order contains apparel from multiple specialized supplier ateliers (e.g. a bespoke handloom saree from Narayanganj and imported heavyweight denim from our dropshipping partner), your order may arrive in safely split packages. You will only be billed a single delivery fee.
            </p>
          </div>
        </div>
      )}

      {/* 5. RETURN & EXCHANGE POLICY */}
      {policyType === 'return' && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h1 className="text-3xl font-serif font-bold text-slate-900">{t.returnPolicy}</h1>
            <p className="text-xs text-slate-500 font-mono mt-1">7-DAY CONFIDENCE GUARANTEE</p>
          </div>

          <div className="prose prose-slate text-xs sm:text-sm leading-relaxed space-y-4 text-slate-700">
            <p>
              At VELRO FASHION, we want you to feel completely confident with your wardrobe choices. If an item does not fit or meets a manufacturing defect, our 7-day exchange protocol guarantees a prompt solution.
            </p>

            <h3 className="text-base font-bold text-slate-900">Exchange Conditions:</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Item must be unworn, unwashed, and in pristine original condition.</li>
              <li>Original brand tags, barcode labels, and packaging box must remain intact.</li>
              <li>Claim must be submitted within 7 calendar days of receipt.</li>
            </ul>

            <h3 className="text-base font-bold text-slate-900 pt-2">How to Request an Exchange:</h3>
            <ol className="list-decimal pl-5 space-y-1">
              <li>Call our hotline at +880 1711-982341 or message us on Live Concierge.</li>
              <li>Provide your Order Number (e.g. VF-2026-XXXX) and desired replacement size.</li>
              <li>Our courier rider will deliver the replacement and collect the returned garment directly at your doorstep.</li>
            </ol>
          </div>
        </div>
      )}

      {/* 6. PRIVACY POLICY */}
      {policyType === 'privacy' && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h1 className="text-3xl font-serif font-bold text-slate-900">{t.privacyPolicy}</h1>
            <p className="text-xs text-slate-500 font-mono mt-1">DATA PROTECTION &amp; GUEST SHOPPING SAFETY</p>
          </div>

          <div className="prose prose-slate text-xs sm:text-sm leading-relaxed space-y-4 text-slate-700">
            <p>
              VELRO FASHION is committed to safeguarding customer personal privacy. Because our storefront requires no customer registration, we collect only the essential details necessary for order dispatch: recipient name, mobile number, and delivery address.
            </p>

            <h3 className="text-base font-bold text-slate-900">Information Handling:</h3>
            <p>
              Customer addresses and contact numbers are encrypted and transmitted exclusively to authorized fulfillment suppliers and courier delivery riders for route completion. We never sell, lease, or monetize customer data.
            </p>
          </div>
        </div>
      )}

      {/* 7. TERMS AND CONDITIONS */}
      {policyType === 'terms' && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h1 className="text-3xl font-serif font-bold text-slate-900">{t.termsConditions}</h1>
            <p className="text-xs text-slate-500 font-mono mt-1">LEGAL &amp; COMMERCIAL TERMS</p>
          </div>

          <div className="prose prose-slate text-xs sm:text-sm leading-relaxed space-y-4 text-slate-700">
            <p>
              By accessing VELRO FASHION and placing orders, you agree to these terms and conditions. All prices listed are in Bangladeshi Taka (BDT ৳) and include applicable trade taxes.
            </p>

            <h3 className="text-base font-bold text-slate-900">Dropshipping &amp; Supply Terms:</h3>
            <p>
              VELRO FASHION operates an integrated supply network. While product specifications and imagery represent authentic articles, slight batch dye variations may naturally occur in artisanal handloom textiles.
            </p>
          </div>
        </div>
      )}

      {/* 8. CUSTOMER SUPPORT & TICKET */}
      {policyType === 'support' && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h1 className="text-3xl font-serif font-bold text-slate-900">{t.customerSupport}</h1>
            <p className="text-xs text-slate-500 mt-1">Direct Help Desk, Ticket Submission &amp; WhatsApp Concierge</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4 text-xs sm:text-sm text-slate-700">
              <div className="p-5 bg-[#0f172a] text-white rounded-xl space-y-2">
                <span className="text-[#c29b38] font-mono text-xs block">INSTANT WHATSAPP ASSISTANCE</span>
                <p className="text-sm font-semibold">Chat directly with a fashion specialist</p>
                <p className="text-xs text-slate-400">Available everyday: 10:00 AM – 10:00 PM</p>
                <a
                  href="https://wa.me/8801711982341"
                  target="_blank"
                  rel="noreferrer"
                  className="mt-3 inline-block px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-xs transition-colors"
                >
                  Open WhatsApp (+880 1711-982341)
                </a>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                <span className="font-bold text-slate-900 block">Frequently Handled Requests:</span>
                <p>• Size advice for Panjabi / Saree styling</p>
                <p>• Address correction before courier handoff</p>
                <p>• Steadfast / Pathao tracking status confirmation</p>
                <p>• Corporate and wedding bulk orders</p>
              </div>
            </div>

            {/* Ticket Submission */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-sm font-semibold text-slate-900 mb-3">Submit a Support Ticket</h3>
              {ticketSubmitted ? (
                <div className="text-center py-8 space-y-3">
                  <CheckCircle className="w-10 h-10 text-emerald-600 mx-auto" />
                  <h4 className="text-base font-semibold text-slate-900">Ticket #VF-TK-{Math.floor(1000 + Math.random() * 9000)} Created</h4>
                  <p className="text-xs text-slate-600">Our support supervisor will review your issue and reply via SMS/call.</p>
                </div>
              ) : (
                <form onSubmit={(e) => { e.preventDefault(); setTicketSubmitted(true); }} className="space-y-3 text-xs">
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Your Name *</label>
                    <input required type="text" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900" />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Mobile Number *</label>
                    <input required type="tel" placeholder="01XXXXXXXXX" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono" />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Order Number (if applicable)</label>
                    <input type="text" placeholder="VF-2026-XXXX" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono uppercase" />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Inquiry Details *</label>
                    <textarea required rows={3} placeholder="Please describe how we can assist..." className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900" />
                  </div>
                  <button type="submit" className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold transition-colors cursor-pointer">
                    Submit Ticket
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
