import React, { useState } from 'react';
import { 
  Truck, 
  CreditCard, 
  CheckCircle, 
  AlertCircle, 
  ArrowLeft, 
  Lock,
  ShieldCheck
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useLanguage } from '../context/LanguageContext';
import { BANGLADESH_DISTRICTS } from '../i18n';
import { Order } from '../types';

interface CheckoutPageProps {
  onOrderSuccess: (order: Order) => void;
  onBackToShop: () => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({
  onOrderSuccess,
  onBackToShop
}) => {
  const { items, subtotal, discount, coupon, clearCart } = useCart();
  const { language, t } = useLanguage();

  const [formData, setFormData] = useState({
    customerName: '',
    customerPhone: '',
    customerEmail: '',
    district: 'Dhaka',
    deliveryArea: '',
    address: '',
    notes: '',
    paymentMethod: 'cod' as 'cod' | 'bkash' | 'nagad' | 'rocket' | 'sslcommerz'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const isDhaka = formData.district.toLowerCase() === 'dhaka';
  const deliveryFee = subtotal >= 5000 ? 0 : (isDhaka ? 70 : 130);
  const grandTotal = Math.max(0, subtotal + deliveryFee - discount);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!formData.customerName.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    const cleanPhone = formData.customerPhone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 11) {
      setErrorMsg('Please enter a valid 11-digit Bangladesh mobile number (e.g., 01711XXXXXX).');
      return;
    }
    if (!formData.deliveryArea.trim()) {
      setErrorMsg('Please enter your delivery area/thana (e.g., Banani, Mirpur, Dhanmondi).');
      return;
    }
    if (!formData.address.trim()) {
      setErrorMsg('Please enter your complete address (House, Road, Flat number).');
      return;
    }
    if (items.length === 0) {
      setErrorMsg('Your cart is empty. Please add items to order.');
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          items,
          couponCode: coupon?.code
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to place order.');
      }

      if (formData.paymentMethod !== 'cod') {
        const payRes = await fetch('/api/payments/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            orderId: data.orderId,
            gateway: formData.paymentMethod,
            paymentId: `PAY-${Date.now()}`,
            trxId: `TRX-${Math.random().toString(36).substring(2, 8).toUpperCase()}`
          })
        });
        await payRes.json();
      }

      clearCart();
      onOrderSuccess(data.order);
    } catch (err: any) {
      setErrorMsg(err.message || 'An error occurred during order submission.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="max-w-xl mx-auto py-20 px-4 text-center space-y-4">
        <h2 className="text-xl font-semibold text-slate-800">{t.emptyCart}</h2>
        <p className="text-xs text-slate-500">Your bag has no items for checkout.</p>
        <button
          onClick={onBackToShop}
          className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-semibold cursor-pointer"
        >
          {t.startShopping}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 text-left">
      {/* Back button & Page Title */}
      <div className="mb-8 flex items-center justify-between">
        <div>
          <button
            onClick={onBackToShop}
            className="text-xs text-slate-500 hover:text-slate-900 flex items-center gap-1.5 mb-2 cursor-pointer transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'শপিংয়ে ফিরে যান' : 'Back to Shopping'}</span>
          </button>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900">
            {t.guestCheckout}
          </h1>
          <p className="text-xs text-slate-500 mt-1">{t.guestCheckoutDesc}</p>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 text-xs">
          <Lock className="w-3.5 h-3.5 text-emerald-600" />
          <span>256-Bit SSL Secured</span>
        </div>
      </div>

      {errorMsg && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-3 text-rose-800 text-xs">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Delivery & Payment Details (7 cols) */}
        <div className="lg:col-span-7 space-y-8">
          
          {/* Customer & Address Form */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-5">
            <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
              <Truck className="w-4 h-4 text-[#c29b38]" />
              <span>{t.customerInfo}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.fullName} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  placeholder="e.g. Tanvir Hossain"
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.phoneNumber} *
                </label>
                <input
                  type="tel"
                  required
                  value={formData.customerPhone}
                  onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                  placeholder="01XXXXXXXXX"
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {t.emailAddress}
              </label>
              <input
                type="email"
                value={formData.customerEmail}
                onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })}
                placeholder="name@example.com (for order receipt & tracking)"
                className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.deliveryDistrict} *
                </label>
                <select
                  value={formData.district}
                  onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-medium"
                >
                  {BANGLADESH_DISTRICTS.map((dist) => (
                    <option key={dist} value={dist}>{dist}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {t.deliveryArea} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.deliveryArea}
                  onChange={(e) => setFormData({ ...formData, deliveryArea: e.target.value })}
                  placeholder="e.g. Banani 11 / Dhanmondi 27 / Agrabad"
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {t.fullAddress} *
              </label>
              <textarea
                required
                rows={2}
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="House No, Road No, Flat / Apartment, Landmark"
                className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {t.deliveryNotes}
              </label>
              <input
                type="text"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Optional: Call before arrival, leave with security, etc."
                className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
              <CreditCard className="w-4 h-4 text-[#c29b38]" />
              <span>{t.selectPaymentMethod}</span>
            </h3>

            <div className="space-y-3">
              {/* Cash on Delivery */}
              <label className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-colors ${
                formData.paymentMethod === 'cod' ? 'border-slate-900 bg-slate-50' : 'border-slate-200 hover:bg-slate-50/50'
              }`}>
                <input
                  type="radio"
                  name="paymentMethod"
                  value="cod"
                  checked={formData.paymentMethod === 'cod'}
                  onChange={() => setFormData({ ...formData, paymentMethod: 'cod' })}
                  className="mt-0.5"
                />
                <div className="text-xs">
                  <span className="font-semibold text-slate-900 block">{t.cod}</span>
                  <span className="text-slate-500 text-[11px]">
                    {language === 'bn' ? 'ডেলিভারি রাইডারের নিকট পণ্য বুঝে পেয়ে মূল্য পরিশোধ করুন।' : 'Pay in cash directly to delivery rider upon receipt.'}
                  </span>
                </div>
              </label>

              {/* bKash Payment */}
              <label className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-colors ${
                formData.paymentMethod === 'bkash' ? 'border-[#e2136e] bg-[#fdf0f5]' : 'border-slate-200 hover:bg-slate-50/50'
              }`}>
                <input
                  type="radio"
                  name="paymentMethod"
                  value="bkash"
                  checked={formData.paymentMethod === 'bkash'}
                  onChange={() => setFormData({ ...formData, paymentMethod: 'bkash' })}
                  className="mt-0.5"
                />
                <div className="text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900">bKash Merchant Payment</span>
                    <span className="bg-[#e2136e] text-white text-[10px] px-1.5 py-0.2 rounded font-bold">bKash</span>
                  </div>
                  <span className="text-slate-500 text-[11px] block mt-0.5">
                    Tokenized Merchant Checkout • Instant automated verification.
                  </span>
                </div>
              </label>

              {/* Nagad Direct Payment */}
              <label className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-colors ${
                formData.paymentMethod === 'nagad' ? 'border-[#f7941d] bg-[#fef7ee]' : 'border-slate-200 hover:bg-slate-50/50'
              }`}>
                <input
                  type="radio"
                  name="paymentMethod"
                  value="nagad"
                  checked={formData.paymentMethod === 'nagad'}
                  onChange={() => setFormData({ ...formData, paymentMethod: 'nagad' })}
                  className="mt-0.5"
                />
                <div className="text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900">Nagad Payment Gateway</span>
                    <span className="bg-[#f7941d] text-white text-[10px] px-1.5 py-0.2 rounded font-bold">Nagad</span>
                  </div>
                  <span className="text-slate-500 text-[11px] block mt-0.5">
                    Direct merchant digital payment with instant transaction confirmation.
                  </span>
                </div>
              </label>

              {/* SSLCommerz Cards */}
              <label className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-colors ${
                formData.paymentMethod === 'sslcommerz' ? 'border-slate-900 bg-slate-50' : 'border-slate-200 hover:bg-slate-50/50'
              }`}>
                <input
                  type="radio"
                  name="paymentMethod"
                  value="sslcommerz"
                  checked={formData.paymentMethod === 'sslcommerz'}
                  onChange={() => setFormData({ ...formData, paymentMethod: 'sslcommerz' })}
                  className="mt-0.5"
                />
                <div className="text-xs">
                  <span className="font-semibold text-slate-900 block">{t.sslcommerz}</span>
                  <span className="text-slate-500 text-[11px]">
                    Visa, Mastercard, City Bank AMEX, DBBL Nexus, and Internet Banking.
                  </span>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Right Column: Order Summary & Placement (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5 sticky top-24">
            <h3 className="text-base font-semibold text-slate-900 border-b border-slate-100 pb-3">
              {language === 'bn' ? 'অর্ডার সারাংশ' : 'Order Summary'}
            </h3>

            {/* Line items list */}
            <div className="max-h-60 overflow-y-auto space-y-3 pr-1">
              {items.map((item) => (
                <div key={item.variantId} className="flex items-center gap-3">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-12 h-14 object-cover rounded-lg bg-slate-100 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-slate-900 truncate">
                      {language === 'bn' ? (item.titleBn || item.title) : item.title}
                    </p>
                    <p className="text-[11px] text-slate-500 font-mono">
                      {item.size} • {item.color} • Qty: {item.quantity}
                    </p>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-900 tabular-nums">
                    ৳ {(item.price * item.quantity).toLocaleString('en-BD')}
                  </span>
                </div>
              ))}
            </div>

            {/* Price Calculations */}
            <div className="space-y-2 pt-3 border-t border-slate-100 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>{t.subtotal}</span>
                <span className="font-mono tabular-nums font-semibold text-slate-900">৳ {subtotal.toLocaleString('en-BD')}</span>
              </div>
              <div className="flex justify-between">
                <span>{t.deliveryCharge} ({isDhaka ? 'Dhaka City' : 'Outside Dhaka'})</span>
                <span className="font-mono tabular-nums">
                  {deliveryFee === 0 ? <strong className="text-emerald-700">FREE</strong> : `৳ ${deliveryFee}`}
                </span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>{t.discount} ({coupon?.code})</span>
                  <span className="font-mono tabular-nums font-semibold">-৳ {discount.toLocaleString('en-BD')}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-bold text-slate-950 pt-3 border-t border-slate-200">
                <span>{t.total}</span>
                <span className="font-mono tabular-nums text-lg">৳ {grandTotal.toLocaleString('en-BD')}</span>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 px-4 bg-[#0f172a] hover:bg-slate-800 text-white rounded-xl text-xs font-semibold tracking-wide uppercase transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <span>{language === 'bn' ? 'অর্ডার প্রক্রিয়াধীন...' : 'Processing Order...'}</span>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 text-[#c29b38]" />
                  <span>{t.placeOrder} (৳ {grandTotal.toLocaleString('en-BD')})</span>
                </>
              )}
            </button>

            <div className="p-3 bg-slate-50 rounded-xl text-[11px] text-slate-500 space-y-1">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-slate-700 shrink-0" />
                <span>7-Day size replacement assistance</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-slate-700 shrink-0" />
                <span>Steadfast &amp; Pathao official courier transit</span>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
