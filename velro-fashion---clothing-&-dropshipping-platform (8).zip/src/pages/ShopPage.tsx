import React, { useState, useMemo } from 'react';
import { RefreshCw } from 'lucide-react';
import { Product } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { ProductCard } from '../components/ProductCard';

interface ShopPageProps {
  products: Product[];
  initialCategory?: string;
  onSelectProduct: (product: Product) => void;
  onQuickOrder?: (product: Product) => void;
}

export const ShopPage: React.FC<ShopPageProps> = ({
  products,
  initialCategory = 'all',
  onSelectProduct,
  onQuickOrder
}) => {
  const { language } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<string>(initialCategory);
  const [selectedSort, setSelectedSort] = useState<string>('recommended');
  const [selectedSize, setSelectedSize] = useState<string>('all');
  const [maxPrice, setMaxPrice] = useState<number>(6000);
  const [inStockOnly] = useState<boolean>(false);

  React.useEffect(() => {
    if (initialCategory) {
      setActiveCategory(initialCategory);
    }
  }, [initialCategory]);

  const categories = [
    { id: 'all', nameEn: 'Shop All', nameBn: 'সব পোশাক' },
    { id: 'Panjabi and Kurta', nameEn: 'Panjabi & Kurta', nameBn: 'পাঞ্জাবি ও কুর্তা' },
    { id: 'Three-Piece and Two-Piece', nameEn: 'Three-Piece & Two-Piece', nameBn: 'থ্রি-পিস ও টু-পিস' },
    { id: 'Traditional Clothing', nameEn: 'Traditional Sarees', nameBn: 'ঐতিহ্যবাহী জামদানি' },
    { id: 'Shirts and T-shirts', nameEn: 'Shirts & T-shirts', nameBn: 'শার্ট ও টি-শার্ট' },
    { id: 'Trousers and Jeans', nameEn: 'Trousers & Jeans', nameBn: 'ডেনিম ও জিন্স' },
    { id: "Kids' Fashion", nameEn: "Kids' Fashion", nameBn: 'বাচ্চাদের পোশাক' },
    { id: 'new-arrivals', nameEn: 'New Arrivals', nameBn: 'নতুন আগমন' },
    { id: 'bestsellers', nameEn: 'Best Sellers', nameBn: 'সেরা বিক্রিত' }
  ];

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (activeCategory === 'new-arrivals' && !p.isNewArrival) return false;
      if (activeCategory === 'bestsellers' && !p.isBestseller) return false;
      if (activeCategory === "Men's Fashion" && !['Panjabi and Kurta', 'Shirts and T-shirts', 'Trousers and Jeans'].includes(p.category)) return false;
      if (activeCategory === "Women's Fashion" && !['Traditional Clothing', 'Three-Piece and Two-Piece'].includes(p.category)) return false;
      if (
        activeCategory !== 'all' &&
        activeCategory !== 'new-arrivals' &&
        activeCategory !== 'bestsellers' &&
        activeCategory !== "Men's Fashion" &&
        activeCategory !== "Women's Fashion" &&
        p.category.toLowerCase() !== activeCategory.toLowerCase()
      ) {
        return false;
      }

      const price = p.salePrice || p.sellingPrice;
      if (price > maxPrice) return false;
      if (selectedSize !== 'all' && !p.sizes?.some(s => s.toLowerCase().includes(selectedSize.toLowerCase()))) {
        return false;
      }
      if (inStockOnly && p.stockQuantity <= 0) return false;

      return true;
    }).sort((a, b) => {
      const priceA = a.salePrice || a.sellingPrice;
      const priceB = b.salePrice || b.sellingPrice;
      if (selectedSort === 'price_asc') return priceA - priceB;
      if (selectedSort === 'price_desc') return priceB - priceA;
      if (selectedSort === 'newest') return (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0);
      if (selectedSort === 'bestselling') return (b.isBestseller ? 1 : 0) - (a.isBestseller ? 1 : 0);
      return 0;
    });
  }, [products, activeCategory, maxPrice, selectedSize, inStockOnly, selectedSort]);

  const allAvailableSizes = ['30', '32', '34', '36', '38', '40', '42', '44', 'S', 'M', 'L', 'XL', 'XXL'];

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-5 sm:py-8 text-left space-y-6 sm:space-y-8 overflow-x-hidden">
      {/* Category Pills Header */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveCategory(c.id)}
            className={`px-4 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
              activeCategory === c.id
                ? 'bg-slate-900 text-white font-semibold shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            {language === 'bn' ? c.nameBn : c.nameEn}
          </button>
        ))}
      </div>

      {/* Filter and Sorting Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white rounded-xl border border-slate-200">
        <div className="flex items-center gap-4 text-xs text-slate-600">
          <span className="font-semibold text-slate-900 font-mono">
            {filteredProducts.length} {language === 'bn' ? 'টি পোশাক প্রদর্শিত' : 'Apparel Items'}
          </span>
          <span aria-hidden="true" className="text-slate-300">•</span>
          <span>COD Available</span>
          <span aria-hidden="true" className="text-slate-300">•</span>
          <span>Dhaka 24-48h Delivery</span>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Quick Size Filter */}
          <select
            value={selectedSize}
            onChange={(e) => setSelectedSize(e.target.value)}
            className="text-xs px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-none"
          >
            <option value="all">All Sizes</option>
            {allAvailableSizes.map((s) => (
              <option key={s} value={s}>Size {s}</option>
            ))}
          </select>

          {/* Sort By */}
          <select
            value={selectedSort}
            onChange={(e) => setSelectedSort(e.target.value)}
            className="text-xs px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-none font-medium"
          >
            <option value="recommended">Featured / Recommended</option>
            <option value="bestselling">Best Sellers First</option>
            <option value="newest">New Arrivals First</option>
            <option value="price_asc">Price: Low to High (কম থেকে বেশি)</option>
            <option value="price_desc">Price: High to Low (বেশি থেকে কম)</option>
          </select>

          {/* Reset Filters */}
          {(selectedSize !== 'all' || activeCategory !== 'all' || maxPrice < 6000) && (
            <button
              onClick={() => {
                setActiveCategory('all');
                setSelectedSize('all');
                setMaxPrice(6000);
                setSelectedSort('recommended');
              }}
              className="text-xs text-rose-600 hover:text-rose-700 font-medium flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Product Grid */}
      {filteredProducts.length === 0 ? (
        <div className="py-20 text-center bg-white rounded-2xl border border-slate-200 p-8 space-y-4">
          <p className="text-base font-semibold text-slate-800">
            {language === 'bn' ? 'কোন পোশাক পাওয়া যায়নি' : 'No clothing items match your filter selection'}
          </p>
          <p className="text-xs text-slate-500">Try adjusting your price range or size selection.</p>
          <button
            onClick={() => {
              setActiveCategory('all');
              setSelectedSize('all');
              setMaxPrice(6000);
            }}
            className="px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Clear All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-6">
          {filteredProducts.map((product) => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onSelect={onSelectProduct}
              onQuickOrder={onQuickOrder}
            />
          ))}
        </div>
      )}
    </div>
  );
};
