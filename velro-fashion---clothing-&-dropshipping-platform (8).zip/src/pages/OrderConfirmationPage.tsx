import React from 'react';
import { CheckCircle2, Printer, Truck } from 'lucide-react';
import { Order } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface OrderConfirmationPageProps {
  order: Order;
  onNavigateToTrack: (orderNumber: string, phone: string) => void;
  onBackToShop: () => void;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({
  order,
  onNavigateToTrack,
  onBackToShop
}) => {
  const { language, t } = useLanguage();

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 text-left space-y-8">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm text-center space-y-3">
        <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-serif font-bold text-slate-900">
          {t.orderSuccess}
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
          {t.orderConfirmationNote}
        </p>
        <div className="pt-2 inline-flex items-center gap-2 bg-slate-100 px-4 py-2 rounded-xl text-xs font-mono font-bold text-slate-900 border border-slate-200">
          <span>{t.orderNumber}:</span>
          <span className="text-[#b3821a] tracking-wider text-sm">{order.orderNumber}</span>
        </div>
      </div>

      {/* Invoice Details Card */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-900">VELRO FASHION INVOICE</h2>
            <p className="text-xs text-slate-500 font-mono">Date: {new Date(order.createdAt).toLocaleDateString('en-GB')}</p>
          </div>
          <button
            onClick={handlePrint}
            className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors self-start cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Invoice</span>
          </button>
        </div>

        {/* Customer & Shipping Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-600 bg-slate-50 p-4 rounded-xl">
          <div>
            <span className="font-semibold text-slate-900 block mb-1">Delivery Recipient:</span>
            <p className="font-medium text-slate-800">{order.customerName}</p>
            <p className="font-mono text-slate-700">{order.customerPhone}</p>
            {order.customerEmail && <p>{order.customerEmail}</p>}
          </div>
          <div>
            <span className="font-semibold text-slate-900 block mb-1">Destination:</span>
            <p>{order.deliveryArea}, {order.district}</p>
            <p className="text-slate-500">{order.address}</p>
          </div>
        </div>

        {/* Ordered Line Items */}
        <div className="divide-y divide-slate-100 text-xs">
          <div className="py-2 flex justify-between font-semibold text-slate-500 uppercase tracking-wider text-[11px]">
            <span>Item</span>
            <span>Total</span>
          </div>
          {order.items.map((item, idx) => (
            <div key={idx} className="py-3 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-12 h-14 object-cover rounded-md bg-slate-100 shrink-0"
                />
                <div>
                  <p className="font-semibold text-slate-900">{item.title}</p>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Size: {item.size} • Color: {item.color} • Qty: {item.quantity}
                  </p>
                </div>
              </div>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                ৳ {(item.price * item.quantity).toLocaleString('en-BD')}
              </span>
            </div>
          ))}
        </div>

        {/* Totals */}
        <div className="pt-4 border-t border-slate-200 space-y-2 text-xs text-slate-600">
          <div className="flex justify-between">
            <span>{t.subtotal}</span>
            <span className="font-mono tabular-nums text-slate-900 font-medium">৳ {order.subtotal.toLocaleString('en-BD')}</span>
          </div>
          <div className="flex justify-between">
            <span>{t.deliveryCharge}</span>
            <span className="font-mono tabular-nums">৳ {order.deliveryFee}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between text-emerald-700">
              <span>{t.discount}</span>
              <span className="font-mono tabular-nums font-semibold">-৳ {order.discount}</span>
            </div>
          )}
          <div className="flex justify-between text-base font-bold text-slate-950 pt-2 border-t border-slate-200">
            <span>{t.total}</span>
            <span className="font-mono tabular-nums">৳ {order.total.toLocaleString('en-BD')}</span>
          </div>
          <div className="flex justify-between text-xs pt-1 text-slate-500">
            <span>Payment Method:</span>
            <span className="font-mono uppercase font-bold text-slate-800">{order.paymentMethod} ({order.paymentStatus})</span>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => onNavigateToTrack(order.orderNumber, order.customerPhone)}
            className="flex-1 py-3 px-4 bg-[#0f172a] hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-sm"
          >
            <Truck className="w-4 h-4 text-[#c29b38]" />
            <span>{t.navTrackOrder}</span>
          </button>
          <button
            onClick={onBackToShop}
            className="py-3 px-6 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            <span>{language === 'bn' ? 'আরও কেনাকাটা করুন' : 'Continue Shopping'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
