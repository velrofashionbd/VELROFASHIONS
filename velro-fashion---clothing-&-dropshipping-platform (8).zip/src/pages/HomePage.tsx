import React, { useState } from 'react';
import { 
  ArrowRight, 
  Truck, 
  ShieldCheck, 
  RefreshCw, 
  Headphones, 
  CreditCard, 
  Banknote,
  Flame,
  Shirt
} from 'lucide-react';
import { Product } from '../types';
import { ProductCard } from '../components/ProductCard';

interface HomePageProps {
  categories?: any[];
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onNavigateToCategory?: (categorySlug: string) => void;
  onNavigateToShop: (filter?: string) => void;
  onQuickOrder?: (product: Product) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  products,
  onSelectProduct,
  onNavigateToShop,
  onQuickOrder
}) => {
  const [activeSlide, setActiveSlide] = useState(0);

  // New arrivals products for the main section
  const newArrivals = products.slice(0, 8);

  // 5 Top Circular Categories
  const topCircularCategories = [
    {
      titleEn: 'MEN',
      titleBn: 'পুরুষ',
      image: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=400&auto=format&fit=crop&q=80',
      isIcon: false,
      filter: "Men's Fashion"
    },
    {
      titleEn: 'WOMEN',
      titleBn: 'নারী',
      image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=400&auto=format&fit=crop&q=80',
      isIcon: false,
      filter: "Women's Fashion"
    },
    {
      titleEn: 'SHIRTS',
      titleBn: 'শার্ট',
      image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400&auto=format&fit=crop&q=80',
      isIcon: false,
      filter: 'Shirts and T-shirts'
    },
    {
      titleEn: 'THREE PIECE',
      titleBn: 'থ্রি পিস',
      image: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=400&auto=format&fit=crop&q=80',
      isIcon: false,
      filter: 'Three-Piece and Two-Piece'
    },
    {
      titleEn: 'NEW ARRIVALS',
      titleBn: 'নতুন',
      isIcon: true,
      filter: 'new-arrivals'
    }
  ];

  return (
    <div className="space-y-6 sm:space-y-8 pb-16 text-left overflow-x-hidden bg-[#fafafa]">
      
      {/* 1. TOP CIRCULAR CATEGORIES ROW */}
      <section className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-3 sm:pt-4">
        <div className="flex items-center justify-between sm:justify-center gap-2 sm:gap-8 overflow-x-auto pb-1 scrollbar-none">
          {topCircularCategories.map((cat, idx) => (
            <button
              key={idx}
              onClick={() => onNavigateToShop(cat.filter)}
              className="flex flex-col items-center group cursor-pointer shrink-0 transition-transform hover:scale-105"
            >
              {/* Circular Avatar Container */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full p-1 bg-gradient-to-tr from-[#0284c7]/40 to-blue-200 shadow-xs mb-1.5 flex items-center justify-center">
                <div className="w-full h-full rounded-full overflow-hidden bg-sky-50 flex items-center justify-center border-2 border-white">
                  {cat.isIcon ? (
                    <div className="flex flex-col items-center justify-center text-[#0284c7]">
                      <Shirt className="w-6 h-6 sm:w-8 sm:h-8 stroke-[1.8]" />
                      <span className="text-[8px] font-bold font-mono uppercase bg-[#0284c7] text-white px-1 rounded-sm mt-0.5">
                        NEW
                      </span>
                    </div>
                  ) : (
                    <img
                      src={cat.image}
                      alt={cat.titleEn}
                      className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-300"
                    />
                  )}
                </div>
              </div>
              <span className="text-[11px] sm:text-xs font-bold text-slate-800 tracking-tight block">
                {cat.titleEn}
              </span>
              <span className="text-[10px] text-slate-500 font-medium">
                ({cat.titleBn})
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* 2. HERO BANNER CAROUSEL */}
      <section className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden bg-gradient-to-r from-[#e0f2fe]/90 via-[#f0f9ff] to-[#ecfeff] border border-sky-100 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-12 items-center min-h-[220px] sm:min-h-[340px]">
            
            {/* Left Content Column */}
            <div className="p-5 sm:p-10 md:col-span-7 space-y-2 sm:space-y-3 z-10">
              <span className="text-[10px] sm:text-xs font-mono font-bold tracking-widest text-[#0f172a] uppercase block">
                PREMIUM CLOTHING BRAND
              </span>
              
              <h1 className="text-2xl sm:text-4xl lg:text-5xl font-serif font-black tracking-tight text-[#0f172a] leading-tight">
                VELRO FASHION
              </h1>
              
              <h2 className="text-lg sm:text-2xl lg:text-3xl font-bold text-[#0284c7] leading-snug">
                নতুন ট্রেন্ডের প্রিমিয়াম পোশাক
              </h2>

              <p className="text-xs sm:text-sm text-slate-600 font-medium pb-1">
                পাঞ্জাবি, ফরমাল শার্ট, এক্সক্লুসিভ থ্রি-পিস ও ড্রপশোল্ডার টি-শার্ট।
              </p>

              <div>
                <button
                  onClick={() => onNavigateToShop('all')}
                  className="px-5 py-2.5 sm:px-6 sm:py-3 bg-[#0f172a] hover:bg-slate-800 text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-md inline-flex items-center gap-2 cursor-pointer group"
                >
                  <span>Shop Now</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>

            {/* Right Photo Column */}
            <div className="relative md:col-span-5 h-48 sm:h-full min-h-[200px] sm:min-h-[340px] flex items-end justify-center overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=800&auto=format&fit=crop&q=80"
                alt="Velro Fashion Banner"
                className="absolute inset-0 w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a]/30 via-transparent to-transparent"></div>
              
              <div className="absolute top-4 right-4 sm:top-6 sm:right-6 text-right z-10 pointer-events-none drop-shadow-md">
                <p className="font-serif italic text-lg sm:text-2xl font-bold text-slate-900 leading-tight">
                  Fashion
                </p>
                <p className="font-serif italic text-xs sm:text-sm text-slate-800">
                  For a Better You
                </p>
              </div>
            </div>
          </div>

          {/* Carousel Indicator Dots */}
          <div className="absolute bottom-2.5 inset-x-0 flex items-center justify-center gap-1.5 z-20">
            {[0, 1, 2, 3, 4].map((dot) => (
              <button
                key={dot}
                onClick={() => setActiveSlide(dot)}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  activeSlide === dot ? 'w-5 bg-[#0284c7]' : 'w-2 bg-slate-300'
                }`}
                aria-label={`Slide ${dot + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 3. TRUST & SERVICE HIGHLIGHTS (6 CARDS GRID) */}
      <section className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 sm:gap-3">
          
          {/* 1 */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-3 sm:p-3.5 shadow-2xs flex flex-col items-center text-center space-y-1">
            <div className="w-8 h-8 rounded-lg bg-sky-50 text-[#0284c7] flex items-center justify-center mb-0.5">
              <Banknote className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-900">সেরা মূল্য</h4>
            <p className="text-[10px] text-slate-500">BDT-তে সাশ্রয়ী রেট</p>
          </div>

          {/* 2 */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-3 sm:p-3.5 shadow-2xs flex flex-col items-center text-center space-y-1">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center mb-0.5">
              <CreditCard className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-900">ক্যাশ অন ডেলিভারি</h4>
            <p className="text-[10px] text-slate-500">পণ্য দেখে মূল্য দিন</p>
          </div>

          {/* 3 */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-3 sm:p-3.5 shadow-2xs flex flex-col items-center text-center space-y-1">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-0.5">
              <Truck className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-900">দ্রুত ডেলিভারি</h4>
            <p className="text-[10px] text-slate-500">৬৪ জেলায় হোম সার্ভিস</p>
          </div>

          {/* 4 */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-3 sm:p-3.5 shadow-2xs flex flex-col items-center text-center space-y-1">
            <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-600 flex items-center justify-center mb-0.5">
              <ShieldCheck className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-900">নিরাপদ পেমেন্ট</h4>
            <p className="text-[10px] text-slate-500">SSL ও বিকাশ সিকিউরড</p>
          </div>

          {/* 5 */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-3 sm:p-3.5 shadow-2xs flex flex-col items-center text-center space-y-1">
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center mb-0.5">
              <Headphones className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-900">২৪/৭ সাপোর্ট</h4>
            <p className="text-[10px] text-slate-500">কল ও হোয়াটসঅ্যাপ</p>
          </div>

          {/* 6 */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-3 sm:p-3.5 shadow-2xs flex flex-col items-center text-center space-y-1">
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-[#b45309] flex items-center justify-center mb-0.5">
              <RefreshCw className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-900">সহজ এক্সচেঞ্জ</h4>
            <p className="text-[10px] text-slate-500">৭ দিনের মধ্যে পরিবর্তন</p>
          </div>
        </div>
      </section>

      {/* 4. FOUR PROMOTIONAL CARDS */}
      <section className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          
          {/* Card 1: MEN'S COLLECTION */}
          <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-blue-50 to-sky-100 border border-sky-200 p-4 sm:p-5 flex flex-col justify-between min-h-[170px] shadow-2xs">
            <div className="max-w-[65%] space-y-1 z-10">
              <h3 className="font-black text-sm sm:text-base text-slate-900 leading-tight">
                MEN'S<br />COLLECTION
              </h3>
              <p className="text-[11px] text-slate-600 line-clamp-2">
                পাঞ্জাবি, ফরমাল ও ক্যাজুয়াল শার্ট
              </p>
            </div>
            <div className="pt-3 z-10">
              <button
                onClick={() => onNavigateToShop("Men's Fashion")}
                className="px-3.5 py-1.5 bg-[#0f172a] hover:bg-slate-800 text-white rounded-lg text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
              >
                <span>দেখুন</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <img
              src="https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=400&auto=format&fit=crop&q=80"
              alt="Men Collection"
              className="absolute right-0 bottom-0 w-28 h-36 object-cover object-top opacity-90"
            />
          </div>

          {/* Card 2: WOMEN'S COLLECTION */}
          <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-pink-50 to-rose-100 border border-pink-200 p-4 sm:p-5 flex flex-col justify-between min-h-[170px] shadow-2xs">
            <div className="max-w-[65%] space-y-1 z-10">
              <h3 className="font-black text-sm sm:text-base text-slate-900 leading-tight">
                WOMEN'S<br />COLLECTION
              </h3>
              <p className="text-[11px] text-slate-600 line-clamp-2">
                এক্সক্লুসিভ থ্রি-পিস ও জামদানি শাড়ি
              </p>
            </div>
            <div className="pt-3 z-10">
              <button
                onClick={() => onNavigateToShop("Women's Fashion")}
                className="px-3.5 py-1.5 bg-[#0f172a] hover:bg-slate-800 text-white rounded-lg text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
              >
                <span>দেখুন</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <img
              src="https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=400&auto=format&fit=crop&q=80"
              alt="Women Collection"
              className="absolute right-0 bottom-0 w-28 h-36 object-cover object-top opacity-90"
            />
          </div>

          {/* Card 3: স্পেশাল অফার */}
          <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#0284c7] to-blue-700 text-white p-4 sm:p-5 flex flex-col justify-between min-h-[170px] shadow-2xs">
            <div className="space-y-1 z-10">
              <span className="text-[10px] font-mono font-bold tracking-wider uppercase bg-white/20 px-2 py-0.5 rounded inline-block">
                SPECIAL OFFER
              </span>
              <p className="text-xs text-sky-100">সিজনাল ডিসকাউন্ট</p>
              <h4 className="text-2xl sm:text-3xl font-black font-mono leading-none">
                FLAT 20% OFF
              </h4>
              <p className="text-[11px] text-sky-100 font-medium">কুপন: VELRO10</p>
            </div>
            <div className="pt-3 z-10">
              <button
                onClick={() => onNavigateToShop('bestsellers')}
                className="px-3.5 py-1.5 bg-white hover:bg-slate-100 text-[#0f172a] rounded-lg text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer shadow-xs"
              >
                <span>অফার নিন</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none"></div>
          </div>

          {/* Card 4: ডেলিভারি ও পেমেন্ট */}
          <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-slate-50 to-sky-50 border border-slate-200 p-4 sm:p-5 flex flex-col justify-between min-h-[170px] shadow-2xs">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-[#0284c7]" />
                <h3 className="font-bold text-xs sm:text-sm text-slate-900 leading-tight">
                  সারা দেশে ক্যাশ অন ডেলিভারি
                </h3>
              </div>
              <p className="text-[11px] text-slate-500">
                পণ্য হাতে পেয়ে মূল্য পরিশোধের সুবিধা
              </p>
              {/* bKash & Nagad Badges */}
              <div className="flex items-center gap-2 pt-1">
                <span className="bg-[#e2136e] text-white text-[10px] px-2 py-0.5 rounded font-bold font-mono">
                  bKash
                </span>
                <span className="bg-[#f7941d] text-white text-[10px] px-2 py-0.5 rounded font-bold font-mono">
                  Nagad
                </span>
              </div>
            </div>
            <div className="pt-3">
              <button
                onClick={() => onNavigateToShop('all')}
                className="w-full py-1.5 bg-[#0f172a] hover:bg-slate-800 text-white rounded-lg text-[11px] font-bold text-center cursor-pointer"
              >
                অর্ডার করুন
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 5. NEW ARRIVALS PRODUCTS SECTION WITH DIRECT EASY ORDER */}
      <section className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-2">
        {/* Section Header */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-rose-600 fill-rose-600" />
            <h2 className="text-base sm:text-xl font-bold text-slate-900">
              নতুন কালেকশন (New Arrivals)
            </h2>
          </div>
          <button
            onClick={() => onNavigateToShop('new-arrivals')}
            className="text-xs sm:text-sm font-semibold text-[#0284c7] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>সব দেখুন</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-5">
          {newArrivals.map((product) => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onSelect={onSelectProduct}
              onQuickOrder={onQuickOrder}
            />
          ))}
        </div>
      </section>
    </div>
  );
};
