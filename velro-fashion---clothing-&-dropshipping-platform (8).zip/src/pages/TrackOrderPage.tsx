import React, { useState, useEffect } from 'react';
import { Search, MapPin, AlertCircle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface TrackOrderPageProps {
  initialOrderNumber?: string;
  initialPhone?: string;
}

export const TrackOrderPage: React.FC<TrackOrderPageProps> = ({
  initialOrderNumber = '',
  initialPhone = ''
}) => {
  const { t } = useLanguage();
  const [orderNumber, setOrderNumber] = useState(initialOrderNumber);
  const [phone, setPhone] = useState(initialPhone);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [orderData, setOrderData] = useState<any | null>(null);

  const fetchTracking = async (ordNum: string, ph: string) => {
    if (!ordNum.trim() || !ph.trim()) {
      setError('Please provide both Order Number and Phone Number.');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/orders/track?orderNumber=${encodeURIComponent(ordNum.trim())}&phone=${encodeURIComponent(ph.trim())}`);
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Order not found.');
      }
      setOrderData(data);
    } catch (err: any) {
      setError(err.message || 'Unable to track consignment.');
      setOrderData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialOrderNumber && initialPhone) {
      fetchTracking(initialOrderNumber, initialPhone);
    }
  }, [initialOrderNumber, initialPhone]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchTracking(orderNumber, phone);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-left space-y-8">
      {/* Title */}
      <div className="text-center max-w-xl mx-auto space-y-2">
        <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900">
          {t.trackYourOrder}
        </h1>
        <p className="text-xs sm:text-sm text-slate-600">
          {t.trackDesc}
        </p>
      </div>

      {/* Lookup Form */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm max-w-2xl mx-auto">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.orderNumber} *
              </label>
              <input
                type="text"
                required
                value={orderNumber}
                onChange={(e) => setOrderNumber(e.target.value)}
                placeholder="e.g. VF-2026-9812"
                className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono uppercase"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.phoneNumber} *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="e.g. 01711982341"
                className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-[#0f172a] hover:bg-slate-800 text-white rounded-xl text-xs font-semibold tracking-wide uppercase transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Search className="w-4 h-4 text-[#c29b38]" />
            <span>{loading ? 'Searching Consignment...' : t.trackOrderBtn}</span>
          </button>
        </form>

        {error && (
          <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Tracking Results Card */}
      {orderData && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-8 animate-in fade-in duration-200">
          
          {/* Header Status */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-100 gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-slate-500">CONSIGNMENT</span>
                <span className="text-base font-bold font-mono text-slate-900">{orderData.orderNumber}</span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Recipient: <strong>{orderData.customerName}</strong> • {orderData.deliveryArea}, {orderData.district}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-[11px] font-mono text-slate-400 uppercase block">{t.orderStatus}</span>
                <span className="text-xs font-bold uppercase text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200 inline-block font-mono">
                  {orderData.orderStatus}
                </span>
              </div>
            </div>
          </div>

          {/* Multi-Supplier Shipments Status if applicable */}
          {orderData.supplierFulfillments && orderData.supplierFulfillments.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-500 font-semibold">
                Fulfillment Routing &amp; Carrier Status
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {orderData.supplierFulfillments.map((ful: any, idx: number) => (
                  <div key={idx} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-slate-900">{ful.supplierName}</span>
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-white border border-slate-200 font-bold">
                        {ful.status}
                      </span>
                    </div>
                    {ful.trackingNumber && (
                      <p className="text-[11px] font-mono text-slate-600">
                        Carrier: {ful.courierName} • Tracking: <strong className="text-slate-900">{ful.trackingNumber}</strong>
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Timeline of Shipment Milestones */}
          <div className="space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-500 font-semibold">
              {t.timeline}
            </h3>
            <div className="relative border-l-2 border-slate-200 ml-4 space-y-6 py-2">
              {orderData.events && orderData.events.length > 0 ? (
                orderData.events.map((evt: any, idx: number) => (
                  <div key={idx} className="relative pl-6">
                    <div className="absolute -left-2 top-1 w-3.5 h-3.5 rounded-full bg-[#0f172a] border-2 border-white shadow-xs"></div>
                    <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                      <h4 className="text-xs font-bold text-slate-900">{evt.status}</h4>
                      <span className="text-[11px] font-mono text-slate-500">
                        {new Date(evt.timestamp).toLocaleString('en-GB')}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>{evt.location}</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      {evt.description}
                    </p>
                  </div>
                ))
              ) : (
                <div className="pl-6 text-xs text-slate-500">
                  Order registered. Consignment manifest being prepared by delivery partner.
                </div>
              )}
            </div>
          </div>

          {/* Consignment Items */}
          <div className="pt-4 border-t border-slate-100 space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-500 font-semibold">
              Package Contents
            </h3>
            <div className="divide-y divide-slate-100">
              {orderData.items.map((item: any, idx: number) => (
                <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <img src={item.image} alt="" className="w-10 h-12 object-cover rounded bg-slate-100" />
                    <div>
                      <p className="font-semibold text-slate-900">{item.title}</p>
                      <p className="text-[11px] text-slate-500 font-mono">
                        {item.size} • {item.color} • Qty: {item.quantity}
                      </p>
                    </div>
                  </div>
                  <span className="font-mono font-bold text-slate-900">৳ {(item.price * item.quantity).toLocaleString('en-BD')}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
