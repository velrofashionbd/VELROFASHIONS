import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';
import fs from 'node:fs';
import path from 'path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const SQLITE_FILE = path.join(DATA_DIR, 'velro_database.sqlite');

export class VelroSqlDatabase {
  private db: Database | null = null;
  private isInitialized = false;

  async init(): Promise<Database> {
    if (this.db && this.isInitialized) return this.db;

    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    const SQL = await initSqlJs();
    if (fs.existsSync(SQLITE_FILE)) {
      try {
        const fileBuffer = fs.readFileSync(SQLITE_FILE);
        this.db = new SQL.Database(fileBuffer);
      } catch (err) {
        console.error('Failed to load existing SQLite file, creating new database:', err);
        this.db = new SQL.Database();
      }
    } else {
      this.db = new SQL.Database();
    }

    this.createTables();
    this.saveToDisk();
    this.isInitialized = true;
    return this.db;
  }

  private createTables() {
    if (!this.db) return;

    this.db.run(`
      -- Categories Table
      CREATE TABLE IF NOT EXISTS categories (
        slug TEXT PRIMARY KEY,
        name_en TEXT NOT NULL,
        name_bn TEXT NOT NULL,
        description_en TEXT,
        description_bn TEXT,
        image_url TEXT,
        parent_group TEXT
      );

      -- Products Table
      CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        sku TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        title_bn TEXT,
        description TEXT,
        description_bn TEXT,
        category TEXT NOT NULL,
        subcategory TEXT,
        cost_price REAL NOT NULL,
        selling_price REAL NOT NULL,
        sale_price REAL,
        discount_percent REAL,
        stock_quantity INTEGER NOT NULL DEFAULT 0,
        weight_kg REAL DEFAULT 0.5,
        status TEXT NOT NULL DEFAULT 'published',
        supplier_name TEXT DEFAULT 'In-House Studio',
        supplier_product_id TEXT,
        supplier_product_url TEXT,
        images TEXT, -- JSON Array of URLs
        colors TEXT, -- JSON Array of Color strings
        sizes TEXT,  -- JSON Array of Size strings
        shipping_info TEXT,
        shipping_info_bn TEXT,
        is_featured INTEGER DEFAULT 0,
        is_bestseller INTEGER DEFAULT 0,
        is_new_arrival INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      );

      -- Product Variants Table (Size + Color + SKU matrix)
      CREATE TABLE IF NOT EXISTS product_variants (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        sku TEXT NOT NULL,
        size TEXT NOT NULL,
        color TEXT NOT NULL,
        stock INTEGER NOT NULL DEFAULT 0,
        cost_price REAL NOT NULL,
        price REAL NOT NULL,
        supplier_variant_id TEXT,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
      );

      -- Orders Table
      CREATE TABLE IF NOT EXISTS orders (
        id TEXT PRIMARY KEY,
        order_number TEXT UNIQUE NOT NULL,
        customer_name TEXT NOT NULL,
        customer_phone TEXT NOT NULL,
        customer_email TEXT,
        district TEXT NOT NULL,
        delivery_area TEXT NOT NULL,
        address TEXT NOT NULL,
        notes TEXT,
        subtotal REAL NOT NULL,
        delivery_fee REAL NOT NULL,
        discount REAL DEFAULT 0,
        coupon_code TEXT,
        total REAL NOT NULL,
        payment_method TEXT NOT NULL,
        payment_status TEXT NOT NULL,
        payment_reference TEXT,
        order_status TEXT NOT NULL,
        fulfillment_status TEXT NOT NULL,
        tracking_number TEXT,
        courier_name TEXT,
        supplier_order_ids TEXT, -- JSON Array
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      );

      -- Order Items Table
      CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        variant_id TEXT,
        sku TEXT,
        title TEXT NOT NULL,
        size TEXT,
        color TEXT,
        quantity INTEGER NOT NULL,
        price REAL NOT NULL,
        cost_price REAL NOT NULL,
        image TEXT,
        supplier_name TEXT,
        supplier_product_id TEXT,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
      );

      -- Shipment Events Table
      CREATE TABLE IF NOT EXISTS shipment_events (
        id TEXT PRIMARY KEY,
        order_id TEXT NOT NULL,
        order_number TEXT NOT NULL,
        status TEXT NOT NULL,
        location TEXT NOT NULL,
        description TEXT,
        source TEXT NOT NULL,
        timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
      );

      -- Integrations Table
      CREATE TABLE IF NOT EXISTS integrations (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        status TEXT NOT NULL,
        status_message TEXT,
        api_url TEXT,
        api_key TEXT,
        api_secret TEXT,
        access_token TEXT,
        store_domain TEXT,
        sandbox_mode INTEGER DEFAULT 1,
        fulfillment_priority INTEGER DEFAULT 1,
        products_count INTEGER DEFAULT 0,
        active_orders_count INTEGER DEFAULT 0,
        last_sync_timestamp TEXT,
        settings_json TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      );

      -- Facebook Page & Meta Commerce Settings Table
      CREATE TABLE IF NOT EXISTS facebook_settings (
        id TEXT PRIMARY KEY DEFAULT 'fb_main',
        page_name TEXT DEFAULT 'VELRO FASHION',
        page_id TEXT DEFAULT 'velrofashion.bd',
        page_url TEXT DEFAULT 'https://facebook.com/velrofashion.bd',
        messenger_url TEXT DEFAULT 'https://m.me/velrofashion.bd',
        access_token TEXT,
        pixel_id TEXT DEFAULT '129481928419284',
        catalog_sync_enabled INTEGER DEFAULT 1,
        messenger_chat_enabled INTEGER DEFAULT 1,
        last_catalog_sync TEXT,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      );

      -- Audit Logs Table
      CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
        admin_username TEXT NOT NULL,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        ip_address TEXT,
        details TEXT -- JSON
      );
    `);
  }

  saveToDisk() {
    if (!this.db) return;
    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(SQLITE_FILE, buffer);
    } catch (err) {
      console.error('Error saving SQLite database to disk:', err);
    }
  }

  runQuery(sql: string, params: any[] = []): { success: boolean; data?: any; error?: string } {
    if (!this.db) return { success: false, error: 'Database not initialized' };
    try {
      const stmt = this.db.prepare(sql);
      stmt.bind(params);
      const results: any[] = [];
      while (stmt.step()) {
        results.push(stmt.getAsObject());
      }
      stmt.free();
      return { success: true, data: results };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  execute(sql: string, params: any[] = []): { success: boolean; error?: string } {
    if (!this.db) return { success: false, error: 'Database not initialized' };
    try {
      this.db.run(sql, params);
      this.saveToDisk();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  getTables(): Array<{ name: string; rowCount: number }> {
    if (!this.db) return [];
    try {
      const res = this.runQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';");
      if (!res.success || !res.data) return [];
      
      return res.data.map((row: any) => {
        const countRes = this.runQuery(`SELECT COUNT(*) as count FROM ${row.name}`);
        const count = countRes.data?.[0]?.count || 0;
        return { name: row.name, rowCount: count };
      });
    } catch {
      return [];
    }
  }

  getTableSchema(tableName: string): any[] {
    if (!this.db) return [];
    try {
      const res = this.runQuery(`PRAGMA table_info(${tableName});`);
      return res.data || [];
    } catch {
      return [];
    }
  }
}

export const sqlDb = new VelroSqlDatabase();
