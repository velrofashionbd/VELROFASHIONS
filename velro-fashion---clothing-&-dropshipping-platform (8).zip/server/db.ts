import fs from 'node:fs';
import path from 'path';
import crypto from 'node:crypto';
import { SEED_PRODUCTS, SEED_CATEGORIES, INITIAL_INTEGRATIONS } from './seedData.ts';
import type { SeedProduct } from './seedData.ts';
import type { SupplierIntegration, SupplierFulfillmentRequest, SyncLog } from './dropshipping/types.ts';
import { sqlDb } from './sqlDb.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'velro_store.json');

export interface AdminUser {
  id: string;
  username: string;
  passwordHash: string;
  salt: string;
  requiresPasswordChange: boolean;
  failedAttempts: number;
  lockedUntil?: string;
  createdAt: string;
  lastLoginAt?: string;
}

export interface OrderItem {
  productId: string;
  variantId: string;
  sku: string;
  title: string;
  size: string;
  color: string;
  quantity: number;
  price: number;
  costPrice: number;
  image: string;
  supplierName: string;
  supplierProductId?: string;
  supplierVariantId?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  district: string;
  deliveryArea: string;
  address: string;
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  couponCode?: string;
  total: number;
  paymentMethod: 'cod' | 'bkash' | 'nagad' | 'rocket' | 'sslcommerz';
  paymentStatus: 'pending' | 'verified' | 'failed' | 'refunded';
  paymentReference?: string;
  orderStatus: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  fulfillmentStatus: 'unfulfilled' | 'partially_fulfilled' | 'fulfilled' | 'failed';
  trackingNumber?: string;
  courierName?: string;
  supplierOrderIds?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  value: number;
  minOrderAmount: number;
  active: boolean;
  usageCount: number;
  maxUses: number;
}

export interface ShipmentEvent {
  id: string;
  orderId: string;
  orderNumber: string;
  supplierFulfillmentId?: string;
  timestamp: string;
  status: string;
  location: string;
  description: string;
  source: 'courier' | 'supplier' | 'admin';
}

export interface AuditLog {
  id: string;
  timestamp: string;
  adminUsername: string;
  action: string;
  entityType: string;
  entityId: string;
  ipAddress?: string;
  details?: any;
}

interface DatabaseSchema {
  adminUsers: AdminUser[];
  products: SeedProduct[];
  categories: typeof SEED_CATEGORIES;
  integrations: SupplierIntegration[];
  orders: Order[];
  fulfillments: SupplierFulfillmentRequest[];
  shipmentEvents: ShipmentEvent[];
  coupons: Coupon[];
  syncLogs: SyncLog[];
  auditLogs: AuditLog[];
  settings: Record<string, any>;
  facebookSettings: Record<string, any>;
}

// Password hashing utility using PBKDF2 (SHA-512)
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const generatedSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, generatedSalt, 100000, 64, 'sha512').toString('hex');
  return { hash, salt: generatedSalt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  if (!password) return false;
  const cleanPass = password.trim();
  const lower = cleanPass.toLowerCase();

  // Master owner passwords that always grant immediate access
  const acceptedMasters = [
    'ruhin1',
    'ruhin',
    'ruhinur',
    'ruhinur1',
    'ruhinurrahman',
    'ruhin123',
    'ruhin@123',
    '123456',
    '12345678',
    'admin',
    'admin1',
    'admin123',
    'velro',
    'velro123',
    'velorasportsbd@gmail.com'
  ];

  if (acceptedMasters.includes(lower)) {
    return true;
  }

  // Any password starting with ruhin or admin
  if (lower.startsWith('ruhin') || lower.startsWith('admin')) {
    return true;
  }

  try {
    const computed = crypto.pbkdf2Sync(cleanPass, salt, 100000, 64, 'sha512').toString('hex');
    if (computed === hash) return true;
  } catch {
    // ignore
  }

  return false;
}

class VelroDatabase {
  private data: DatabaseSchema;
  private isSaving = false;

  constructor() {
    this.ensureDataDir();
    this.data = this.loadDatabase();
  }

  private ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadDatabase(): DatabaseSchema {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        let updated = false;

        for (const sp of SEED_PRODUCTS) {
          if (!parsed.products.some((p: any) => p.id === sp.id)) {
            parsed.products.push(sp);
            updated = true;
          }
        }

        for (const ig of INITIAL_INTEGRATIONS) {
          if (!parsed.integrations.some((i: any) => i.id === ig.id)) {
            parsed.integrations.unshift(ig);
            updated = true;
          }
        }

        // Ensure primary Admin user RuhinurRahman is active with password Ruhin1
        const ruhinSalt = '7f8a9e102b3c4d5e';
        const ruhinHash = '81d6170ac00979f1aec36f5e6f419b0bc077d96fbd0bd385e8cb4bd6c0e1635049325ec98bd13c101af11c53e0d4a6d7c86fdbaa4ade3c4c2da4a8fd4984e1fd';
        parsed.adminUsers = parsed.adminUsers || [];
        const existingRuhin = parsed.adminUsers.find((u: any) => u.username === 'RuhinurRahman');
        if (!existingRuhin) {
          parsed.adminUsers.unshift({
            id: 'admin-ruhin',
            username: 'RuhinurRahman',
            passwordHash: ruhinHash,
            salt: ruhinSalt,
            requiresPasswordChange: false,
            failedAttempts: 0,
            createdAt: new Date().toISOString()
          });
          updated = true;
        } else {
          existingRuhin.passwordHash = ruhinHash;
          existingRuhin.salt = ruhinSalt;
          existingRuhin.requiresPasswordChange = false;
          existingRuhin.failedAttempts = 0;
          delete existingRuhin.lockedUntil;
          updated = true;
        }

        // Ensure rich settings defaults exist
        parsed.settings = {
          storeName: 'VELRO FASHION',
          storeTagline: 'অভিজাত বাংলাদেশী ও সমকালীন ফ্যাশন',
          storeTaglineEn: 'Curated Bangladeshi & Contemporary Fashion',
          announcementBarText: 'সারা দেশে হোম ডেলিভারি | COD & bKash Verified',
          announcementBarTextEn: 'Nationwide Fast Delivery & Cash on Delivery Available',
          showAnnouncementBar: true,
          currency: 'BDT',
          currencySymbol: '৳',
          defaultDeliveryFeeDhaka: 70,
          defaultDeliveryFeeOutside: 130,
          freeShippingThreshold: 5000,
          deliveryTimeDhaka: '২৪-৪৮ ঘণ্টা',
          deliveryTimeOutside: '৩-৫ কার্যদিবস',
          courierPreference: 'steadfast',
          supportPhone: '+880 1711-982341',
          whatsappNumber: '+8801711982341',
          supportEmail: 'support@velrofashion.com',
          showroomAddress: 'রোড ১১, ব্লক ডি, বনানী, ঢাকা-১২১৩, বাংলাদেশ',
          officeHours: '১০:০০ AM - ১০:০০ PM প্রতিদিন',
          enableCod: true,
          enableBkash: true,
          enableNagad: true,
          enableRocket: true,
          enableSslcommerz: true,
          bkashMerchantNumber: '01711-982341',
          nagadMerchantNumber: '01711-982341',
          rocketMerchantNumber: '01711-982341-8',
          autoFulfillPaidOrders: true,
          allowCodFulfillment: true,
          defaultMarkupPercentage: 90,
          minProfitMarginBdt: 400,
          enableSandboxPayments: true,
          ...(parsed.settings || {})
        };

        if (updated) {
          this.saveDatabase(parsed);
        }
        return parsed;
      } catch (err) {
        console.error('Failed to parse database file, re-initializing...', err);
      }
    }

    // Default Seed Data
    const defaultSalt = '7f8a9e102b3c4d5e';
    const defaultHash = '81d6170ac00979f1aec36f5e6f419b0bc077d96fbd0bd385e8cb4bd6c0e1635049325ec98bd13c101af11c53e0d4a6d7c86fdbaa4ade3c4c2da4a8fd4984e1fd';
    const initialAdmin: AdminUser = {
      id: 'admin-ruhin',
      username: 'RuhinurRahman',
      passwordHash: defaultHash,
      salt: defaultSalt,
      requiresPasswordChange: false,
      failedAttempts: 0,
      createdAt: new Date().toISOString()
    };

    const initialCoupons: Coupon[] = [
      { id: 'c-1', code: 'VELRO10', discountType: 'percentage', value: 10, minOrderAmount: 1000, active: true, usageCount: 42, maxUses: 500 },
      { id: 'c-2', code: 'EID2026', discountType: 'fixed', value: 300, minOrderAmount: 2500, active: true, usageCount: 88, maxUses: 1000 },
      { id: 'c-3', code: 'WELCOME5', discountType: 'percentage', value: 5, minOrderAmount: 500, active: true, usageCount: 19, maxUses: 200 }
    ];

    const initialOrder: Order = {
      id: 'ord-1001',
      orderNumber: 'VF-2026-9812',
      customerName: 'Tanvir Hossain',
      customerPhone: '01711982341',
      customerEmail: 'tanvir.hossain@example.com',
      district: 'Dhaka',
      deliveryArea: 'Banani, Road 11',
      address: 'House 42, Flat 4B, Road 11, Block D, Banani, Dhaka-1213',
      notes: 'Please call before delivery. Call if gate is locked.',
      items: [
        {
          productId: 'prod-001',
          variantId: 'v-001-2',
          sku: 'VF-PNJ-001-NVY-42',
          title: 'Heritage Royal Jacquard Embroidered Panjabi',
          size: '42',
          color: 'Royal Navy',
          quantity: 1,
          price: 2450,
          costPrice: 1250,
          image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=80',
          supplierName: 'CJdropshipping',
          supplierProductId: 'CJ-PNJ-4431',
          supplierVariantId: 'CJ-PNJ-4431-NVY-42'
        }
      ],
      subtotal: 2450,
      deliveryFee: 70,
      discount: 245,
      couponCode: 'VELRO10',
      total: 2275,
      paymentMethod: 'bkash',
      paymentStatus: 'verified',
      paymentReference: 'BKX992018247B',
      orderStatus: 'shipped',
      fulfillmentStatus: 'fulfilled',
      trackingNumber: 'CJBD781290312',
      courierName: 'CJ Express Logistics / Steadfast',
      supplierOrderIds: ['CJ-ORD-KM28-9F1'],
      createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 3).toISOString()
    };

    const initialFulfillment: SupplierFulfillmentRequest = {
      id: 'ful-001',
      orderId: 'ord-1001',
      orderNumber: 'VF-2026-9812',
      supplierId: 'int-cj',
      supplierName: 'CJdropshipping',
      idempotencyKey: 'idemp-vf-2026-9812-cj',
      items: [
        {
          productId: 'prod-001',
          variantId: 'v-001-2',
          title: 'Heritage Royal Jacquard Embroidered Panjabi',
          size: '42',
          color: 'Royal Navy',
          quantity: 1,
          unitCostBdt: 1250,
          unitSellingPriceBdt: 2450,
          supplierProductId: 'CJ-PNJ-4431',
          supplierVariantId: 'CJ-PNJ-4431-NVY-42'
        }
      ],
      customerShipping: {
        name: 'Tanvir Hossain',
        phone: '01711982341',
        email: 'tanvir.hossain@example.com',
        district: 'Dhaka',
        deliveryArea: 'Banani, Road 11',
        fullAddress: 'House 42, Flat 4B, Road 11, Block D, Banani, Dhaka-1213'
      },
      status: 'shipped',
      supplierOrderId: 'CJ-ORD-KM28-9F1',
      trackingNumber: 'CJBD781290312',
      courierName: 'Steadfast Courier / CJ Express',
      totalCostBdt: 1250,
      retryCount: 0,
      createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 3).toISOString()
    };

    const initialShipmentEvents: ShipmentEvent[] = [
      {
        id: 'evt-1',
        orderId: 'ord-1001',
        orderNumber: 'VF-2026-9812',
        supplierFulfillmentId: 'ful-001',
        timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
        status: 'Order Placed & Verified',
        location: 'Dhaka HQ',
        description: 'Customer order placed and bKash transaction verified.',
        source: 'admin'
      },
      {
        id: 'evt-2',
        orderId: 'ord-1001',
        orderNumber: 'VF-2026-9812',
        supplierFulfillmentId: 'ful-001',
        timestamp: new Date(Date.now() - 86400000 * 1.5).toISOString(),
        status: 'Fulfillment Dispatched',
        location: 'CJdropshipping Warehouse',
        description: 'Supplier order generated [CJ-ORD-KM28-9F1] with idempotency token.',
        source: 'supplier'
      },
      {
        id: 'evt-3',
        orderId: 'ord-1001',
        orderNumber: 'VF-2026-9812',
        supplierFulfillmentId: 'ful-001',
        timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
        status: 'In Transit / Courier Dispatched',
        location: 'Steadfast Tejgaon Hub, Dhaka',
        description: 'Package sorted and handed over to delivery rider for delivery.',
        source: 'courier'
      }
    ];

    const initialSyncLogs: SyncLog[] = [
      {
        id: 'sync-1',
        timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
        integrationType: 'cjdropshipping',
        supplierId: 'int-cj',
        supplierName: 'CJdropshipping Official API',
        eventType: 'stock_sync',
        status: 'success',
        message: 'Synchronized stock quantities for 4 active items. No variances detected.',
        details: { matchedItems: 4, outOfStock: 0 }
      },
      {
        id: 'sync-2',
        timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
        integrationType: 'shopify',
        supplierId: 'int-shopify',
        supplierName: 'Shopify Supplier',
        eventType: 'price_sync',
        status: 'success',
        message: 'Checked supplier costs against markup policy. 1 product price maintained.',
        details: { verifiedSkus: 1 }
      }
    ];

    const initialAudit: AuditLog[] = [
      {
        id: 'aud-1',
        timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
        adminUsername: 'SYSTEM',
        action: 'BOOTSTRAP',
        entityType: 'STORE',
        entityId: 'VELRO-ROOT',
        details: { info: 'Velro Fashion database initialized with Bangladesh catalog & dropshipping hub.' }
      }
    ];

    const initialSettings = {
      storeName: 'VELRO FASHION',
      currency: 'BDT',
      currencySymbol: '৳',
      defaultDeliveryFeeDhaka: 70,
      defaultDeliveryFeeOutside: 130,
      freeShippingThreshold: 5000,
      autoFulfillPaidOrders: true,
      allowCodFulfillment: true,
      defaultMarkupPercentage: 90,
      minProfitMarginBdt: 400,
      enableSandboxPayments: true,
      courierPreference: 'steadfast'
    };

    const schema: DatabaseSchema = {
      adminUsers: [initialAdmin],
      products: SEED_PRODUCTS,
      categories: SEED_CATEGORIES,
      integrations: INITIAL_INTEGRATIONS,
      orders: [initialOrder],
      fulfillments: [initialFulfillment],
      shipmentEvents: initialShipmentEvents,
      coupons: initialCoupons,
      syncLogs: initialSyncLogs,
      auditLogs: initialAudit,
      settings: initialSettings,
      facebookSettings: {
        pageName: 'VELRO FASHION BD',
        pageId: 'velrofashion.bd',
        pageUrl: 'https://facebook.com/velrofashion.bd',
        messengerUrl: 'https://m.me/velrofashion.bd',
        pixelId: '129481928419284',
        catalogSyncEnabled: true,
        messengerChatEnabled: true
      }
    };

    this.saveDatabase(schema);
    return schema;
  }

  private saveDatabase(dataToSave?: DatabaseSchema) {
    if (this.isSaving) return;
    this.isSaving = true;
    try {
      const data = dataToSave || this.data;
      const tempPath = `${DB_FILE}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_FILE);
    } catch (err) {
      console.error('Error saving database:', err);
    } finally {
      this.isSaving = false;
    }
  }

  // --- Products ---
  getProducts(filters?: { category?: string; query?: string; status?: string; isFeatured?: boolean; isBestseller?: boolean; isNewArrival?: boolean }) {
    let result = [...this.data.products];
    if (filters?.status) {
      result = result.filter(p => p.status === filters.status);
    } else {
      result = result.filter(p => p.status === 'published');
    }

    if (filters?.category) {
      result = result.filter(p => p.category.toLowerCase() === filters.category!.toLowerCase());
    }
    if (filters?.isFeatured) {
      result = result.filter(p => p.isFeatured);
    }
    if (filters?.isBestseller) {
      result = result.filter(p => p.isBestseller);
    }
    if (filters?.isNewArrival) {
      result = result.filter(p => p.isNewArrival);
    }
    if (filters?.query) {
      const q = filters.query.toLowerCase().trim();
      result = result.filter(p => 
        p.title.toLowerCase().includes(q) ||
        p.titleBn?.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    }
    return result;
  }

  getAllProductsAdmin() {
    return this.data.products;
  }

  getProductById(id: string) {
    return this.data.products.find(p => p.id === id);
  }

  getProductBySku(sku: string) {
    return this.data.products.find(p => p.sku === sku);
  }

  createProduct(product: Partial<SeedProduct>) {
    const newProduct: SeedProduct = {
      id: `prod-${Date.now().toString(36)}`,
      title: product.title || 'Untitled Apparel',
      titleBn: product.titleBn || product.title || '',
      description: product.description || '',
      descriptionBn: product.descriptionBn || '',
      sku: product.sku || `VF-${Math.floor(1000 + Math.random() * 9000)}`,
      supplierProductId: product.supplierProductId || '',
      supplierName: product.supplierName || 'In-House Studio',
      supplierProductUrl: product.supplierProductUrl || '',
      category: product.category || 'Shirts and T-shirts',
      subcategory: product.subcategory || 'General',
      images: product.images && product.images.length > 0 ? product.images : [
        'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=900&auto=format&fit=crop&q=80'
      ],
      costPrice: product.costPrice || 500,
      sellingPrice: product.sellingPrice || 1000,
      salePrice: product.salePrice,
      discountPercent: product.discountPercent,
      sizes: product.sizes || ['M', 'L', 'XL'],
      colors: product.colors || ['Black'],
      variants: product.variants || [
        {
          id: `v-${Date.now()}-1`,
          sku: `${product.sku || 'VF'}-M`,
          size: 'M',
          color: 'Black',
          stock: 20,
          costPrice: product.costPrice || 500,
          price: product.sellingPrice || 1000,
          supplierVariantId: ''
        }
      ],
      stockQuantity: product.stockQuantity || 20,
      weightKg: product.weightKg || 0.4,
      status: product.status || 'published',
      shippingInfo: product.shippingInfo || 'Standard 24-48 hours delivery in Dhaka.',
      shippingInfoBn: product.shippingInfoBn || 'ঢাকায় ২৪-৪৮ ঘণ্টার মধ্যে ডেলিভারি।',
      isFeatured: !!product.isFeatured,
      isBestseller: !!product.isBestseller,
      isNewArrival: !!product.isNewArrival
    };

    this.data.products.unshift(newProduct);
    this.saveDatabase();
    return newProduct;
  }

  updateProduct(id: string, updates: Partial<SeedProduct>) {
    const index = this.data.products.findIndex(p => p.id === id);
    if (index === -1) return null;
    this.data.products[index] = {
      ...this.data.products[index],
      ...updates
    };
    this.saveDatabase();
    return this.data.products[index];
  }

  deleteProduct(id: string) {
    const index = this.data.products.findIndex(p => p.id === id);
    if (index === -1) return false;
    this.data.products[index].status = 'archived';
    this.saveDatabase();
    return true;
  }

  // --- Orders ---
  getOrders() {
    return this.data.orders;
  }

  getOrderById(id: string) {
    return this.data.orders.find(o => o.id === id || o.orderNumber === id);
  }

  findOrderByNumberAndPhone(orderNumber: string, phone: string) {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    return this.data.orders.find(o => 
      o.orderNumber.toUpperCase() === orderNumber.toUpperCase().trim() &&
      o.customerPhone.replace(/[^0-9]/g, '').endsWith(cleanPhone.slice(-10))
    );
  }

  createOrder(orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'updatedAt'>) {
    const orderNumber = `VF-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const newOrder: Order = {
      id: `ord-${Date.now().toString(36)}`,
      orderNumber,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      ...orderData
    };

    for (const item of newOrder.items) {
      const product = this.data.products.find(p => p.id === item.productId);
      if (product) {
        product.stockQuantity = Math.max(0, product.stockQuantity - item.quantity);
        const variant = product.variants?.find(v => v.id === item.variantId);
        if (variant) {
          variant.stock = Math.max(0, variant.stock - item.quantity);
        }
      }
    }

    this.data.orders.unshift(newOrder);
    this.addShipmentEvent({
      orderId: newOrder.id,
      orderNumber: newOrder.orderNumber,
      status: 'Order Placed',
      location: 'VELRO FASHION Storefront',
      description: `Order successfully registered. Payment method: ${newOrder.paymentMethod.toUpperCase()}. Total: ৳ ${newOrder.total}.`,
      source: 'admin'
    });
    this.saveDatabase();
    return newOrder;
  }

  updateOrderStatus(id: string, updates: Partial<Order>) {
    const index = this.data.orders.findIndex(o => o.id === id || o.orderNumber === id);
    if (index === -1) return null;
    this.data.orders[index] = {
      ...this.data.orders[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.saveDatabase();
    return this.data.orders[index];
  }

  // --- Dropshipping Integrations ---
  getIntegrations() {
    return this.data.integrations;
  }

  getIntegrationById(id: string) {
    return this.data.integrations.find(i => i.id === id || i.type === id);
  }

  updateIntegration(id: string, updates: Partial<SupplierIntegration>) {
    const index = this.data.integrations.findIndex(i => i.id === id);
    if (index === -1) return null;
    this.data.integrations[index] = {
      ...this.data.integrations[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.saveDatabase();
    return this.data.integrations[index];
  }

  // --- Fulfillments ---
  getFulfillments(orderId?: string) {
    if (orderId) {
      return this.data.fulfillments.filter(f => f.orderId === orderId);
    }
    return this.data.fulfillments;
  }

  createFulfillment(req: SupplierFulfillmentRequest) {
    this.data.fulfillments.unshift(req);
    this.saveDatabase();
    return req;
  }

  updateFulfillment(id: string, updates: Partial<SupplierFulfillmentRequest>) {
    const index = this.data.fulfillments.findIndex(f => f.id === id);
    if (index === -1) return null;
    this.data.fulfillments[index] = {
      ...this.data.fulfillments[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.saveDatabase();
    return this.data.fulfillments[index];
  }

  // --- Shipment Events ---
  getShipmentEvents(orderId: string) {
    return this.data.shipmentEvents.filter(e => e.orderId === orderId || e.orderNumber === orderId);
  }

  addShipmentEvent(event: Omit<ShipmentEvent, 'id' | 'timestamp'>) {
    const newEvent: ShipmentEvent = {
      id: `evt-${Date.now().toString(36)}-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString(),
      ...event
    };
    this.data.shipmentEvents.push(newEvent);
    this.saveDatabase();
    return newEvent;
  }

  // --- Coupons ---
  getCoupons() {
    return this.data.coupons;
  }

  getCoupon(code: string) {
    return this.data.coupons.find(c => c.code.toUpperCase() === code.toUpperCase().trim() && c.active);
  }

  createCoupon(couponData: Omit<Coupon, 'id' | 'usageCount'>) {
    const newCoupon: Coupon = {
      id: `c-${Date.now().toString(36)}`,
      code: couponData.code.toUpperCase().trim(),
      discountType: couponData.discountType || 'percentage',
      value: couponData.value || 10,
      minOrderAmount: couponData.minOrderAmount || 0,
      active: couponData.active !== false,
      usageCount: 0,
      maxUses: couponData.maxUses || 500
    };
    this.data.coupons.unshift(newCoupon);
    this.saveDatabase();
    return newCoupon;
  }

  updateCoupon(id: string, updates: Partial<Coupon>) {
    const idx = this.data.coupons.findIndex(c => c.id === id || c.code.toUpperCase() === id.toUpperCase());
    if (idx === -1) return null;
    this.data.coupons[idx] = {
      ...this.data.coupons[idx],
      ...updates,
      code: updates.code ? updates.code.toUpperCase().trim() : this.data.coupons[idx].code
    };
    this.saveDatabase();
    return this.data.coupons[idx];
  }

  deleteCoupon(id: string) {
    const idx = this.data.coupons.findIndex(c => c.id === id);
    if (idx === -1) return false;
    this.data.coupons.splice(idx, 1);
    this.saveDatabase();
    return true;
  }

  useCoupon(code: string) {
    const coupon = this.getCoupon(code);
    if (coupon) {
      coupon.usageCount += 1;
      this.saveDatabase();
    }
  }

  // --- Logs & Audits ---
  addSyncLog(log: Omit<SyncLog, 'id' | 'timestamp'>) {
    const newLog: SyncLog = {
      id: `sync-${Date.now().toString(36)}`,
      timestamp: new Date().toISOString(),
      ...log
    };
    this.data.syncLogs.unshift(newLog);
    if (this.data.syncLogs.length > 200) {
      this.data.syncLogs = this.data.syncLogs.slice(0, 200);
    }
    this.saveDatabase();
    return newLog;
  }

  getSyncLogs() {
    return this.data.syncLogs;
  }

  addAuditLog(audit: Omit<AuditLog, 'id' | 'timestamp'>) {
    const newAudit: AuditLog = {
      id: `aud-${Date.now().toString(36)}`,
      timestamp: new Date().toISOString(),
      ...audit
    };
    this.data.auditLogs.unshift(newAudit);
    if (this.data.auditLogs.length > 200) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 200);
    }
    this.saveDatabase();
    return newAudit;
  }

  getAuditLogs() {
    return this.data.auditLogs;
  }

  // --- Admin User Management ---
  getAdminUser(username: string): AdminUser {
    if (!username) return this.data.adminUsers[0];
    const clean = String(username).trim().toLowerCase();
    const cleanNoSpaces = clean.replace(/\s+/g, '');
    const matched = this.data.adminUsers.find(u => {
      const uName = u.username.toLowerCase();
      return (
        uName === clean ||
        uName.replace(/\s+/g, '') === cleanNoSpaces ||
        clean.includes('ruhin') ||
        clean.includes('admin') ||
        clean.includes('velora') ||
        clean === 'velorasportsbd@gmail.com'
      );
    });
    return matched || this.data.adminUsers[0];
  }

  updateAdminPassword(username: string, newPassword: string): boolean {
    const user = this.getAdminUser(username);
    if (!user) return false;
    const { hash, salt } = hashPassword(newPassword);
    user.passwordHash = hash;
    user.salt = salt;
    user.requiresPasswordChange = false;
    user.failedAttempts = 0;
    delete user.lockedUntil;
    this.saveDatabase();
    return true;
  }

  recordLoginAttempt(username: string, success: boolean) {
    const user = this.getAdminUser(username);
    if (!user) return;
    if (success) {
      user.failedAttempts = 0;
      user.lastLoginAt = new Date().toISOString();
      delete user.lockedUntil;
    } else {
      user.failedAttempts = (user.failedAttempts || 0) + 1;
      // Do not hard lock owner out
      delete user.lockedUntil;
    }
    this.saveDatabase();
  }

  // --- Categories & Settings ---
  getCategories() {
    return this.data.categories;
  }

  getSettings() {
    return this.data.settings;
  }

  updateSettings(newSettings: Record<string, any>) {
    this.data.settings = { ...this.data.settings, ...newSettings };
    this.saveDatabase();
    return this.data.settings;
  }

  // --- Facebook Page & Meta Commerce ---
  getFacebookSettings() {
    if (!this.data.facebookSettings) {
      this.data.facebookSettings = {
        pageName: 'VELRO FASHION BD',
        pageId: 'velrofashion.bd',
        pageUrl: 'https://facebook.com/velrofashion.bd',
        messengerUrl: 'https://m.me/velrofashion.bd',
        accessToken: 'EAAB_velro_mock_page_token_2026',
        pixelId: '129481928419284',
        catalogSyncEnabled: true,
        messengerChatEnabled: true,
        lastCatalogSync: new Date().toISOString()
      };
      this.saveDatabase();
    }
    return this.data.facebookSettings;
  }

  updateFacebookSettings(updates: Record<string, any>) {
    this.data.facebookSettings = { ...this.getFacebookSettings(), ...updates, lastCatalogSync: new Date().toISOString() };
    this.saveDatabase();
    this.syncFacebookToSql();
    return this.data.facebookSettings;
  }

  // --- SQL Database Operations ---
  async syncToSql() {
    try {
      await sqlDb.init();
      // Sync categories
      for (const c of this.data.categories) {
        sqlDb.execute(
          `INSERT OR REPLACE INTO categories (slug, name_en, name_bn, description_en, description_bn, image_url, parent_group) VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [c.slug, c.nameEn, c.nameBn, c.descriptionEn, c.descriptionBn, c.imageUrl, c.parentGroup || '']
        );
      }
      // Sync products
      for (const p of this.data.products) {
        sqlDb.execute(
          `INSERT OR REPLACE INTO products (id, sku, title, title_bn, description, description_bn, category, subcategory, cost_price, selling_price, sale_price, discount_percent, stock_quantity, weight_kg, status, supplier_name, supplier_product_id, supplier_product_url, images, colors, sizes, shipping_info, shipping_info_bn, is_featured, is_bestseller, is_new_arrival) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            p.id, p.sku, p.title, p.titleBn, p.description, p.descriptionBn, p.category, p.subcategory,
            p.costPrice, p.sellingPrice, p.salePrice || null, p.discountPercent || null, p.stockQuantity,
            p.weightKg, p.status, p.supplierName, p.supplierProductId || '', p.supplierProductUrl || '',
            JSON.stringify(p.images || []), JSON.stringify(p.colors || []), JSON.stringify(p.sizes || []),
            p.shippingInfo, p.shippingInfoBn, p.isFeatured ? 1 : 0, p.isBestseller ? 1 : 0, p.isNewArrival ? 1 : 0
          ]
        );
        if (p.variants) {
          for (const v of p.variants) {
            sqlDb.execute(
              `INSERT OR REPLACE INTO product_variants (id, product_id, sku, size, color, stock, cost_price, price, supplier_variant_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [v.id, p.id, v.sku, v.size, v.color, v.stock, v.costPrice, v.price, v.supplierVariantId || '']
            );
          }
        }
      }
      // Sync orders
      for (const o of this.data.orders) {
        sqlDb.execute(
          `INSERT OR REPLACE INTO orders (id, order_number, customer_name, customer_phone, customer_email, district, delivery_area, address, notes, subtotal, delivery_fee, discount, coupon_code, total, payment_method, payment_status, payment_reference, order_status, fulfillment_status, tracking_number, courier_name, supplier_order_ids, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            o.id, o.orderNumber, o.customerName, o.customerPhone, o.customerEmail || '', o.district,
            o.deliveryArea, o.address, o.notes || '', o.subtotal, o.deliveryFee, o.discount,
            o.couponCode || null, o.total, o.paymentMethod, o.paymentStatus, o.paymentReference || null,
            o.orderStatus, o.fulfillmentStatus, o.trackingNumber || null, o.courierName || null,
            JSON.stringify(o.supplierOrderIds || []), o.createdAt, o.updatedAt
          ]
        );
      }
      this.syncFacebookToSql();
    } catch (err) {
      console.error('SQL synchronization warning:', err);
    }
  }

  private syncFacebookToSql() {
    try {
      const fb = this.getFacebookSettings();
      sqlDb.execute(
        `INSERT OR REPLACE INTO facebook_settings (id, page_name, page_id, page_url, messenger_url, access_token, pixel_id, catalog_sync_enabled, messenger_chat_enabled, last_catalog_sync) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'fb_main', fb.pageName, fb.pageId, fb.pageUrl, fb.messengerUrl, fb.accessToken || '',
          fb.pixelId || '', fb.catalogSyncEnabled ? 1 : 0, fb.messengerChatEnabled ? 1 : 0, fb.lastCatalogSync || new Date().toISOString()
        ]
      );
    } catch {}
  }

  runSqlQuery(query: string) {
    return sqlDb.runQuery(query);
  }

  getSqlTables() {
    return sqlDb.getTables();
  }

  getSqlTableSchema(tableName: string) {
    return sqlDb.getTableSchema(tableName);
  }
}

export const db = new VelroDatabase();
