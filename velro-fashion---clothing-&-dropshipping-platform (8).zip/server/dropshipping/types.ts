export type IntegrationType = 
  | 'shopbase_reseller'
  | 'shopify' 
  | 'woocommerce' 
  | 'dsers' 
  | 'cjdropshipping' 
  | 'aliexpress' 
  | 'facebook_shop'
  | 'custom_webhook';

export type IntegrationStatus = 
  | 'not_connected' 
  | 'connecting' 
  | 'connected' 
  | 'syncing' 
  | 'action_required' 
  | 'connection_error';

export interface SupplierIntegration {
  id: string;
  name: string;
  type: IntegrationType;
  status: IntegrationStatus;
  statusMessage?: string;
  config: {
    apiUrl?: string;
    apiKey?: string;
    apiSecret?: string;
    accessToken?: string;
    storeDomain?: string;
    webhookSecret?: string;
    sandboxMode?: boolean;
    fulfillmentPriority?: number;
    resellerPhone?: string;
    storeName?: string;
    pageId?: string;
    pageName?: string;
  };
  stats: {
    productsCount: number;
    activeOrdersCount: number;
    lastSyncTimestamp?: string;
    lastSuccessfulFulfillment?: string;
    syncErrorsCount: number;
  };
  settings: {
    autoImport: boolean;
    autoPublish: boolean;
    autoPriceSync: boolean;
    autoStockSync: boolean;
    autoFulfillPaidOrders: boolean;
    allowCodFulfillment: boolean;
    defaultMarkupPercentage: number;
    minimumProfitMarginBdt: number;
    maxShippingDays: number;
  };
  createdAt: string;
  updatedAt: string;
}

export interface SupplierProductDraft {
  supplierId: string;
  supplierProductId: string;
  supplierProductUrl?: string;
  supplierName?: string;
  title: string;
  description: string;
  images: string[];
  category: string;
  supplierCostBdt: number;
  suggestedSellingPriceBdt: number;
  stockQuantity: number;
  variants: {
    supplierVariantId: string;
    size: string;
    color: string;
    supplierCostBdt: number;
    stock: number;
    suggestedPriceBdt: number;
  }[];
}

export interface FulfillmentItem {
  productId: string;
  variantId: string;
  title: string;
  size: string;
  color: string;
  quantity: number;
  unitCostBdt: number;
  unitSellingPriceBdt: number;
  supplierProductId?: string;
  supplierVariantId?: string;
}

export interface SupplierFulfillmentRequest {
  id: string;
  orderId: string;
  orderNumber: string;
  supplierId: string;
  supplierName: string;
  idempotencyKey: string;
  items: FulfillmentItem[];
  customerShipping: {
    name: string;
    phone: string;
    email?: string;
    district: string;
    deliveryArea: string;
    fullAddress: string;
  };
  status: 'pending_approval' | 'processing' | 'submitted' | 'shipped' | 'delivered' | 'failed' | 'cancelled';
  supplierOrderId?: string;
  trackingNumber?: string;
  courierName?: string;
  totalCostBdt: number;
  failureReason?: string;
  retryCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface SyncLog {
  id: string;
  timestamp: string;
  integrationType: IntegrationType;
  supplierId: string;
  supplierName: string;
  eventType: 'product_import' | 'price_sync' | 'stock_sync' | 'order_fulfillment' | 'tracking_sync' | 'webhook';
  status: 'success' | 'warning' | 'error';
  message: string;
  details?: Record<string, any>;
}
