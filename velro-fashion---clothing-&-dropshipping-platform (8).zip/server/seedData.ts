export interface SeedProduct {
  id: string;
  title: string;
  titleBn: string;
  description: string;
  descriptionBn: string;
  sku: string;
  supplierProductId: string;
  supplierName: string;
  supplierProductUrl: string;
  category: string;
  subcategory: string;
  images: string[];
  costPrice: number;
  sellingPrice: number;
  salePrice?: number;
  discountPercent?: number;
  sizes: string[];
  colors: string[];
  colorItems?: { name: string; hex: string; inStock?: boolean }[];
  sizeItems?: { size: string; chest?: string; length?: string; inStock?: boolean }[];
  variants: {
    id: string;
    sku: string;
    size: string;
    color: string;
    stock: number;
    costPrice: number;
    price: number;
    supplierVariantId: string;
  }[];
  stockQuantity: number;
  weightKg: number;
  status: 'published' | 'draft' | 'archived';
  shippingInfo: string;
  shippingInfoBn: string;
  isFeatured: boolean;
  isBestseller: boolean;
  isNewArrival: boolean;
}

export const SEED_CATEGORIES = [
  {
    slug: 'panjabi-and-kurta',
    nameEn: 'Panjabi and Kurta',
    nameBn: 'পাঞ্জাবি ও কুর্তা',
    descriptionEn: 'Handcrafted luxury panjabis for Eid, festivities, and weddings.',
    descriptionBn: 'ঈদ ও উৎসবের জন্য প্রিমিয়াম ডিজাইনার পাঞ্জাবি ও কুর্তা কালেকশন।',
    imageUrl: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=80',
    parentGroup: "Men's Fashion"
  },
  {
    slug: 'three-piece-and-two-piece',
    nameEn: 'Three-Piece and Two-Piece',
    nameBn: 'থ্রি-পিস ও টু-পিস',
    descriptionEn: 'Designer lawn, georgette, and organza luxury salwar suits.',
    descriptionBn: 'এক্সক্লুসিভ লন, জর্জেট ও অরগাঞ্জা থ্রি-পিস ও টু-পিস ড্রেস।',
    imageUrl: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=900&auto=format&fit=crop&q=80',
    parentGroup: "Women's Fashion"
  },
  {
    slug: 'shirts-and-tshirts',
    nameEn: 'Shirts and T-shirts',
    nameBn: 'শার্ট ও টি-শার্ট',
    descriptionEn: 'Breathable Supima cotton casual & formal shirts and oversized tees.',
    descriptionBn: 'অফিস ও ক্যাজুয়াল ব্যবহারের জন্য প্রিমিয়াম কটন শার্ট ও টি-শার্ট।',
    imageUrl: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=900&auto=format&fit=crop&q=80',
    parentGroup: "Men's Fashion"
  },
  {
    slug: 'trousers-and-jeans',
    nameEn: 'Trousers and Jeans',
    nameBn: 'ট্রাউজার ও ডেনিম জিন্স',
    descriptionEn: 'Tailored chinos, stretch formal pants, and raw selvedge denim.',
    descriptionBn: 'সেলভেজ ডেনিম জিন্স, টুইল চিনো ও ফরমাল ট্রাউজার।',
    imageUrl: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=900&auto=format&fit=crop&q=80',
    parentGroup: "Men's Fashion"
  },
  {
    slug: 'traditional-clothing',
    nameEn: 'Traditional Clothing',
    nameBn: 'ঐতিহ্যবাহী জামদানি ও শাড়ি',
    descriptionEn: 'Heritage Dhakai Jamdani, Katan, and Handloom silk sarees.',
    descriptionBn: 'নারায়ণগঞ্জের তাঁতের ঢাকাই জামদানি ও কাতান শাড়ির সংগ্রহ।',
    imageUrl: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=900&auto=format&fit=crop&q=80',
    parentGroup: "Women's Fashion"
  },
  {
    slug: 'kids-fashion',
    nameEn: "Kids' Fashion",
    nameBn: 'বাচ্চাদের ফ্যাশন',
    descriptionEn: 'Festive panjabi sets, princess gowns, and comfortable everyday wear.',
    descriptionBn: 'শিশুদের আরামদায়ক উৎসবের পাঞ্জাবি ও ফ্রক সেট।',
    imageUrl: 'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?w=900&auto=format&fit=crop&q=80',
    parentGroup: "Kids' Fashion"
  }
];

export const SEED_PRODUCTS: SeedProduct[] = [
  {
    id: 'prod-denim-01',
    title: 'Premium Denim Shirt',
    titleBn: 'প্রিমিয়াম ডেনিম শার্ট',
    description: '100% fine cotton washed denim shirt with western dual chest pockets, durable snap buttons, and comfortable tailored fit.',
    descriptionBn: '১০০% ফাইন ওয়াশড কটন ডেনিম শার্ট। ওয়েস্টার্ন পকেট ডিজাইন এবং আরামদায়ক রেগুলার ফিট।',
    sku: 'VF-DNM-001',
    supplierProductId: 'SB-DNM-201',
    supplierName: 'ShopBase BD (https://shopbasebd.com/)',
    supplierProductUrl: 'https://shopbasebd.com/products/premium-denim-shirt',
    category: 'Shirts and T-shirts',
    subcategory: 'Denim Shirts',
    images: [
      'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 750,
    sellingPrice: 1750,
    salePrice: 1350,
    discountPercent: 23,
    sizes: ['M', 'L', 'XL'],
    colors: ['Denim Blue', 'Dark Indigo', 'Charcoal'],
    variants: [
      { id: 'v-dnm-1', sku: 'VF-DNM-001-BLU-M', size: 'M', color: 'Denim Blue', stock: 45, costPrice: 750, price: 1350, supplierVariantId: 'SB-DNM-BLU-M' },
      { id: 'v-dnm-2', sku: 'VF-DNM-001-BLU-L', size: 'L', color: 'Denim Blue', stock: 55, costPrice: 750, price: 1350, supplierVariantId: 'SB-DNM-BLU-L' },
      { id: 'v-dnm-3', sku: 'VF-DNM-001-BLU-XL', size: 'XL', color: 'Denim Blue', stock: 35, costPrice: 750, price: 1350, supplierVariantId: 'SB-DNM-BLU-XL' },
    ],
    stockQuantity: 135,
    weightKg: 0.45,
    status: 'published',
    shippingInfo: 'Standard 24-48 hours in Dhaka. 3-5 days across all Bangladesh districts via Steadfast / Pathao.',
    shippingInfoBn: 'ঢাকায় ২৪-৪৮ ঘণ্টা, সারা দেশে ৩-৫ দিন।',
    isFeatured: true,
    isBestseller: false,
    isNewArrival: true
  },
  {
    id: 'prod-three-piece-01',
    title: 'Embroidered Three Piece',
    titleBn: 'এমব্রয়ডারি থ্রি পিস',
    description: 'Designer lawn cotton suit adorned with intricate resham embroidery on neckline and daman, paired with cotton trouser and chiffon printed dupatta.',
    descriptionBn: 'অভিজাত লন কটন থ্রি-পিস। নেকলাইন ও প্যানেলে আকর্ষণীয় এমব্রয়ডারি এবং শিফন ওড়না।',
    sku: 'VF-3PC-001',
    supplierProductId: 'SB-3PC-881',
    supplierName: 'ShopBase BD (https://shopbasebd.com/)',
    supplierProductUrl: 'https://shopbasebd.com/products/embroidered-three-piece-881',
    category: 'Three-Piece and Two-Piece',
    subcategory: 'Three-Piece',
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 1100,
    sellingPrice: 2450,
    salePrice: 1950,
    discountPercent: 20,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Dusty Rose', 'Peach Pink', 'Maroon'],
    variants: [
      { id: 'v-3pc-1', sku: 'VF-3PC-001-RSE-M', size: 'M', color: 'Dusty Rose', stock: 35, costPrice: 1100, price: 1950, supplierVariantId: 'SB-3PC-RSE-M' },
      { id: 'v-3pc-2', sku: 'VF-3PC-001-RSE-L', size: 'L', color: 'Dusty Rose', stock: 40, costPrice: 1100, price: 1950, supplierVariantId: 'SB-3PC-RSE-L' },
      { id: 'v-3pc-3', sku: 'VF-3PC-001-RSE-XL', size: 'XL', color: 'Dusty Rose', stock: 25, costPrice: 1100, price: 1950, supplierVariantId: 'SB-3PC-RSE-XL' },
    ],
    stockQuantity: 100,
    weightKg: 0.65,
    status: 'published',
    shippingInfo: 'Includes signature gift packaging. Ships in 24 hours.',
    shippingInfoBn: 'প্রিমিয়াম গিফট প্যাকেজিংসহ ২৪ ঘণ্টার মধ্যে পাঠানো হয়।',
    isFeatured: true,
    isBestseller: true,
    isNewArrival: false
  },
  {
    id: 'prod-casual-shirt-01',
    title: 'Casual Shirt',
    titleBn: 'ক্যাজুয়াল শার্ট',
    description: 'Garment-dyed 100% breathable organic cotton casual shirt with chest patch pocket, soft relaxed collar, and curved hem.',
    descriptionBn: 'গার্মেন্ট-ডায়েড পিওর অর্গানিক কটন শার্ট। সফট কলার ও আরামদায়ক ক্যাজুয়াল ফিট।',
    sku: 'VF-CSH-002',
    supplierProductId: 'SB-CSH-402',
    supplierName: 'ShopBase BD (https://shopbasebd.com/)',
    supplierProductUrl: 'https://shopbasebd.com/products/casual-olive-shirt',
    category: 'Shirts and T-shirts',
    subcategory: 'Casual Shirts',
    images: [
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 580,
    sellingPrice: 1450,
    salePrice: 1100,
    discountPercent: 24,
    sizes: ['M', 'L', 'XL'],
    colors: ['Olive Green', 'Deep Navy', 'Charcoal'],
    variants: [
      { id: 'v-csh-1', sku: 'VF-CSH-002-OLV-M', size: 'M', color: 'Olive Green', stock: 50, costPrice: 580, price: 1100, supplierVariantId: 'SB-CSH-OLV-M' },
      { id: 'v-csh-2', sku: 'VF-CSH-002-OLV-L', size: 'L', color: 'Olive Green', stock: 60, costPrice: 580, price: 1100, supplierVariantId: 'SB-CSH-OLV-L' },
      { id: 'v-csh-3', sku: 'VF-CSH-002-OLV-XL', size: 'XL', color: 'Olive Green', stock: 40, costPrice: 580, price: 1100, supplierVariantId: 'SB-CSH-OLV-XL' },
    ],
    stockQuantity: 150,
    weightKg: 0.35,
    status: 'published',
    shippingInfo: 'Fast dispatch within 24 hours.',
    shippingInfoBn: '২৪ ঘণ্টার মধ্যে দ্রুত ডেলিভারি প্রস্তুত।',
    isFeatured: true,
    isBestseller: false,
    isNewArrival: true
  },
  {
    id: 'prod-cotton-three-piece-01',
    title: 'Three Piece (Cotton)',
    titleBn: 'থ্রি পিস (কটন)',
    description: 'All-season pure combed cotton printed suit with metallic thread detailing, matching trousers, and lightweight printed malmal dupatta.',
    descriptionBn: 'অল-সিজন প্রিমিয়াম কম্বড কটন প্রিন্টেড থ্রি-পিস ও নরম সুতি মালমাল ওড়না।',
    sku: 'VF-3PC-COT-03',
    supplierProductId: 'SB-3PC-719',
    supplierName: 'ShopBase BD (https://shopbasebd.com/)',
    supplierProductUrl: 'https://shopbasebd.com/products/cotton-three-piece',
    category: 'Three-Piece and Two-Piece',
    subcategory: 'Three-Piece',
    images: [
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 950,
    sellingPrice: 2200,
    salePrice: 1750,
    discountPercent: 20,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Royal Navy', 'Teal Green', 'Black'],
    variants: [
      { id: 'v-3pc-cot-1', sku: 'VF-3PC-COT-NVY-S', size: 'S', color: 'Royal Navy', stock: 20, costPrice: 950, price: 1750, supplierVariantId: 'SB-3PC-NVY-S' },
      { id: 'v-3pc-cot-2', sku: 'VF-3PC-COT-NVY-M', size: 'M', color: 'Royal Navy', stock: 30, costPrice: 950, price: 1750, supplierVariantId: 'SB-3PC-NVY-M' },
      { id: 'v-3pc-cot-3', sku: 'VF-3PC-COT-NVY-L', size: 'L', color: 'Royal Navy', stock: 25, costPrice: 950, price: 1750, supplierVariantId: 'SB-3PC-NVY-L' },
    ],
    stockQuantity: 75,
    weightKg: 0.6,
    status: 'published',
    shippingInfo: 'Fast dispatch within 24 hours.',
    shippingInfoBn: '২৪ ঘণ্টার মধ্যে দ্রুত ডেলিভারি প্রস্তুত।',
    isFeatured: true,
    isBestseller: true,
    isNewArrival: false
  },
  {
    id: 'prod-001',
    title: 'Heritage Royal Jacquard Embroidered Panjabi',
    titleBn: 'হেরিটেজ রয়্যাল জ্যাকর্ড এমব্রয়ডারি পাঞ্জাবি',
    description: 'Masterfully crafted with regal golden thread embroidery across the mandarin band collar and placket. Spun from breathable linen-cotton jacquard for unmatched sophistication during Eid and family gala celebrations.',
    descriptionBn: 'ব্যান্ড কলার ও বুকজুড়ে সূক্ষ্ম গোল্ডেন এমব্রয়ডারি। প্রিমিয়াম লিনেন-কটন জ্যাকর্ড কাপড়ে তৈরি। ঈদ ও যেকোনো উৎসবের জন্য সেরা পছন্দ।',
    sku: 'VF-PNJ-001',
    supplierProductId: 'CJ-PNJ-4431',
    supplierName: 'CJdropshipping',
    supplierProductUrl: 'https://cjdropshipping.com/product/luxury-jacquard-embroidered-panjabi-4431',
    category: 'Panjabi and Kurta',
    subcategory: 'Festive Panjabi',
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 1250,
    sellingPrice: 2850,
    salePrice: 2450,
    discountPercent: 14,
    sizes: ['40', '42', '44'],
    colors: ['Royal Navy', 'Deep Maroon', 'Ivory Cream'],
    variants: [
      { id: 'v-001-1', sku: 'VF-PNJ-001-NVY-40', size: '40', color: 'Royal Navy', stock: 18, costPrice: 1250, price: 2450, supplierVariantId: 'CJ-PNJ-4431-NVY-40' },
      { id: 'v-001-2', sku: 'VF-PNJ-001-NVY-42', size: '42', color: 'Royal Navy', stock: 24, costPrice: 1250, price: 2450, supplierVariantId: 'CJ-PNJ-4431-NVY-42' },
      { id: 'v-001-3', sku: 'VF-PNJ-001-NVY-44', size: '44', color: 'Royal Navy', stock: 12, costPrice: 1250, price: 2450, supplierVariantId: 'CJ-PNJ-4431-NVY-44' },
      { id: 'v-001-4', sku: 'VF-PNJ-001-MAR-40', size: '40', color: 'Deep Maroon', stock: 15, costPrice: 1250, price: 2450, supplierVariantId: 'CJ-PNJ-4431-MAR-40' },
      { id: 'v-001-5', sku: 'VF-PNJ-001-MAR-42', size: '42', color: 'Deep Maroon', stock: 20, costPrice: 1250, price: 2450, supplierVariantId: 'CJ-PNJ-4431-MAR-42' },
      { id: 'v-001-6', sku: 'VF-PNJ-001-IVO-42', size: '42', color: 'Ivory Cream', stock: 14, costPrice: 1250, price: 2450, supplierVariantId: 'CJ-PNJ-4431-IVO-42' }
    ],
    stockQuantity: 103,
    weightKg: 0.45,
    status: 'published',
    shippingInfo: 'Standard 24-48 hours in Dhaka. 3-5 days across all Bangladesh districts via Steadfast / Pathao.',
    shippingInfoBn: 'ঢাকায় ২৪-৪৮ ঘণ্টা, সারা দেশে ৩-৫ দিন।',
    isFeatured: true,
    isBestseller: true,
    isNewArrival: false
  },
  {
    id: 'prod-002',
    title: 'Dhakai Jamdani Pure Handloom Heritage Saree',
    titleBn: 'ঢাকাই জামদানি পিওর হ্যান্ডলুম ঐতিহ্যবাহী শাড়ি',
    description: 'Woven by master weavers of Narayanganj on traditional wooden pit looms. Features traditional floral Jaal motifs in gold and silver zari on eighty-count fine cotton.',
    descriptionBn: 'নারায়ণগঞ্জের ঐতিহ্যবাহী পিট-লুমে বোনা আশি কাউন্ট সুতির ঢাকাই জামদানি। চোখজুড়ানো সোনালী ও রূপালী জরি সুতার নকশা।',
    sku: 'VF-SRI-002',
    supplierProductId: 'DHAKA-JAM-701',
    supplierName: 'Dhaka Handloom Guild',
    supplierProductUrl: 'https://supplier.example.com/crafts/dhakai-jamdani-701',
    category: 'Traditional Clothing',
    subcategory: 'Saree',
    images: [
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 3200,
    sellingPrice: 5950,
    salePrice: 5200,
    discountPercent: 12,
    sizes: ['Free Size (12 Haat)'],
    colors: ['Ruby Red', 'Emerald Green', 'Royal Gold'],
    variants: [
      { id: 'v-002-1', sku: 'VF-SRI-002-RED', size: 'Free Size', color: 'Ruby Red', stock: 8, costPrice: 3200, price: 5200, supplierVariantId: 'DHAKA-JAM-701-RED' },
      { id: 'v-002-2', sku: 'VF-SRI-002-GRN', size: 'Free Size', color: 'Emerald Green', stock: 6, costPrice: 3200, price: 5200, supplierVariantId: 'DHAKA-JAM-701-GRN' },
      { id: 'v-002-3', sku: 'VF-SRI-002-GLD', size: 'Free Size', color: 'Royal Gold', stock: 5, costPrice: 3200, price: 5200, supplierVariantId: 'DHAKA-JAM-701-GLD' }
    ],
    stockQuantity: 19,
    weightKg: 0.65,
    status: 'published',
    shippingInfo: 'Includes signature gift box & authentic loom seal certificate. Ships in 24 hours.',
    shippingInfoBn: 'প্রিমিয়াম বক্স ও সত্যতার সার্টিফিকেটসহ সরবরাহ করা হয়।',
    isFeatured: true,
    isBestseller: true,
    isNewArrival: false
  },
  {
    id: 'prod-003',
    title: 'Executive Cut Premium Oxford Cotton Shirt',
    titleBn: 'এক্সিকিউটিভ কাট প্রিমিয়াম অক্সফোর্ড কটন শার্ট',
    description: 'Tailored for executive presence. Features 100% combed long-staple pinpoint oxford fabric, reinforced button placket, button-down collar, and breathable weave.',
    descriptionBn: '১০০% কম্বড লং-স্ট্যাপল অক্সফোর্ড কটন। নিখুঁত বাটন-ডাউন কলার ও সেলাই। করপোরেট ও ক্যাজুয়াল ব্যবহারের জন্য আদর্শ।',
    sku: 'VF-SHT-003',
    supplierProductId: 'SHOP-OXF-8812',
    supplierName: 'Shopify Supplier',
    supplierProductUrl: 'https://velro-supplier.myshopify.com/products/oxford-shirt',
    category: 'Shirts and T-shirts',
    subcategory: 'Formal Shirts',
    images: [
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 750,
    sellingPrice: 1750,
    salePrice: 1450,
    discountPercent: 17,
    sizes: ['M (15)', 'L (16)', 'XL (16.5)', 'XXL (17)'],
    colors: ['Sky Blue', 'Crisp White', 'Soft Pink'],
    variants: [
      { id: 'v-003-1', sku: 'VF-SHT-003-BLU-M', size: 'M (15)', color: 'Sky Blue', stock: 25, costPrice: 750, price: 1450, supplierVariantId: 'SHOP-8812-BLU-15' },
      { id: 'v-003-2', sku: 'VF-SHT-003-BLU-L', size: 'L (16)', color: 'Sky Blue', stock: 35, costPrice: 750, price: 1450, supplierVariantId: 'SHOP-8812-BLU-16' },
      { id: 'v-003-3', sku: 'VF-SHT-003-BLU-XL', size: 'XL (16.5)', color: 'Sky Blue', stock: 20, costPrice: 750, price: 1450, supplierVariantId: 'SHOP-8812-BLU-17' },
      { id: 'v-003-4', sku: 'VF-SHT-003-WHT-M', size: 'M (15)', color: 'Crisp White', stock: 30, costPrice: 750, price: 1450, supplierVariantId: 'SHOP-8812-WHT-15' },
      { id: 'v-003-5', sku: 'VF-SHT-003-WHT-L', size: 'L (16)', color: 'Crisp White', stock: 40, costPrice: 750, price: 1450, supplierVariantId: 'SHOP-8812-WHT-16' },
    ],
    stockQuantity: 150,
    weightKg: 0.35,
    status: 'published',
    shippingInfo: 'Express delivery ready across Dhaka, Chattogram, Sylhet, and Khulna.',
    shippingInfoBn: 'ঢাকা, চট্টগ্রাম, সিলেটসহ সারা দেশে এক্সপ্রেস ডেলিভারি।',
    isFeatured: false,
    isBestseller: true,
    isNewArrival: false
  },
  {
    id: 'prod-004',
    title: 'Festive Embroidered Chiffon 2-Piece Kurti Set',
    titleBn: 'উৎসবে পরিধানযোগ্য এমব্রয়ডারি শিফন ২-পিস কুর্তি সেট',
    description: 'Chic Pakistani cut two-piece ensemble. Features delicate floral organza neckline appliqués, matching straight palazzo pants, and breathable inner slip lining.',
    descriptionBn: 'প্রিমিয়াম জর্জেট শিফন কুর্তি ও ম্যাচিং পালাজো। গলায় নিখুঁত অরগাঞ্জা ফুলেল কারুকাজ ও সফট ইনার লাইনিং।',
    sku: 'VF-2PC-004',
    supplierProductId: 'DSER-DRS-5502',
    supplierName: 'DSers',
    supplierProductUrl: 'https://dsers.com/product/embroidered-chiffon-two-piece-5502',
    category: 'Three-Piece and Two-Piece',
    subcategory: 'Two-Piece',
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 1450,
    sellingPrice: 3200,
    salePrice: 2850,
    discountPercent: 11,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Emerald Green', 'Dusty Rose', 'Midnight Lavender'],
    variants: [
      { id: 'v-004-1', sku: 'VF-2PC-004-GRN-S', size: 'S', color: 'Emerald Green', stock: 12, costPrice: 1450, price: 2850, supplierVariantId: 'DSER-5502-GRN-S' },
      { id: 'v-004-2', sku: 'VF-2PC-004-GRN-M', size: 'M', color: 'Emerald Green', stock: 25, costPrice: 1450, price: 2850, supplierVariantId: 'DSER-5502-GRN-M' },
      { id: 'v-004-3', sku: 'VF-2PC-004-GRN-L', size: 'L', color: 'Emerald Green', stock: 20, costPrice: 1450, price: 2850, supplierVariantId: 'DSER-5502-GRN-L' },
      { id: 'v-004-4', sku: 'VF-2PC-004-RSE-M', size: 'M', color: 'Dusty Rose', stock: 18, costPrice: 1450, price: 2850, supplierVariantId: 'DSER-5502-RSE-M' },
    ],
    stockQuantity: 75,
    weightKg: 0.5,
    status: 'published',
    shippingInfo: 'Carefully packaged with hanger and protective garment bag.',
    shippingInfoBn: 'প্রটেক্টিভ হ্যাঙ্গার প্যাকেজ সহ পাঠানো হয়।',
    isFeatured: true,
    isBestseller: false,
    isNewArrival: true
  },
  {
    id: 'prod-005',
    title: 'Raw Indigo Selvedge Denim Slim Straight Jeans',
    titleBn: 'র ইনডিগো সেলভেজ ডেনিম স্লিম স্ট্রেইট জিন্স',
    description: 'Constructed from premium 13.5 oz heavy stretch cotton denim. Authentically dyed with deep indigo, featuring contrast selvedge stitch and durable copper hardware.',
    descriptionBn: '১৩.৫ আউন্স ভারী স্ট্রেচ ডেনিম কটন। নিখুঁত লাল সেলভেজ বর্ডার, কপার রিভেটস এবং প্রিমিয়াম টেকসই ফিনিশ।',
    sku: 'VF-JNS-005',
    supplierProductId: 'CJ-JNS-1029',
    supplierName: 'CJdropshipping',
    supplierProductUrl: 'https://cjdropshipping.com/product/raw-selvedge-denim-jeans-1029',
    category: 'Trousers and Jeans',
    subcategory: 'Jeans',
    images: [
      'https://images.unsplash.com/photo-1542272604-787c3835535d?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 850,
    sellingPrice: 1950,
    salePrice: 1750,
    discountPercent: 10,
    sizes: ['30', '32', '34', '36'],
    colors: ['Raw Indigo Blue', 'Washed Charcoal Black'],
    variants: [
      { id: 'v-005-1', sku: 'VF-JNS-005-IND-30', size: '30', color: 'Raw Indigo Blue', stock: 22, costPrice: 850, price: 1750, supplierVariantId: 'CJ-JNS-1029-IND-30' },
      { id: 'v-005-2', sku: 'VF-JNS-005-IND-32', size: '32', color: 'Raw Indigo Blue', stock: 30, costPrice: 850, price: 1750, supplierVariantId: 'CJ-JNS-1029-IND-32' },
      { id: 'v-005-3', sku: 'VF-JNS-005-IND-34', size: '34', color: 'Raw Indigo Blue', stock: 28, costPrice: 850, price: 1750, supplierVariantId: 'CJ-JNS-1029-IND-34' },
      { id: 'v-005-4', sku: 'VF-JNS-005-IND-36', size: '36', color: 'Raw Indigo Blue', stock: 15, costPrice: 850, price: 1750, supplierVariantId: 'CJ-JNS-1029-IND-36' },
      { id: 'v-005-5', sku: 'VF-JNS-005-BLK-32', size: '32', color: 'Washed Charcoal Black', stock: 20, costPrice: 850, price: 1750, supplierVariantId: 'CJ-JNS-1029-BLK-32' }
    ],
    stockQuantity: 115,
    weightKg: 0.7,
    status: 'published',
    shippingInfo: '7-day hassle-free size exchange guarantee.',
    shippingInfoBn: '৭ দিনের সহজ সাইজ এক্সচেঞ্জ সুবিধা।',
    isFeatured: false,
    isBestseller: true,
    isNewArrival: false
  },
  {
    id: 'prod-006',
    title: 'Boys Festive Jacquard Kurta & Pajama Set',
    titleBn: 'বাচ্চাদের উৎসবের জাকর্ড কুর্তা ও পায়জামা সেট',
    description: 'Adorably designed boys ethnic wear set. Soft cotton lining inside to prevent irritation on young skin. Complete with elasticated comfortable churidar pajama.',
    descriptionBn: 'শিশুদের কোমল ত্বকের জন্য সম্পূর্ণ আরামদায়ক সুতি ইনার লাইনিং যুক্ত উৎসবের কুর্তা-পায়জামা সেট।',
    sku: 'VF-KID-006',
    supplierProductId: 'KID-EXP-301',
    supplierName: 'CJdropshipping',
    supplierProductUrl: 'https://cjdropshipping.com/product/boys-kurta-set-301',
    category: "Kids' Fashion",
    subcategory: 'Boys Ethnic',
    images: [
      'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 550,
    sellingPrice: 1250,
    salePrice: 1050,
    discountPercent: 16,
    sizes: ['2-3 Yrs', '4-5 Yrs', '6-7 Yrs', '8-9 Yrs'],
    colors: ['Maroon & Gold', 'Teal Blue & Silver'],
    variants: [
      { id: 'v-006-1', sku: 'VF-KID-006-MAR-2', size: '2-3 Yrs', color: 'Maroon & Gold', stock: 15, costPrice: 550, price: 1050, supplierVariantId: 'KID-EXP-301-MAR-2' },
      { id: 'v-006-2', sku: 'VF-KID-006-MAR-4', size: '4-5 Yrs', color: 'Maroon & Gold', stock: 20, costPrice: 550, price: 1050, supplierVariantId: 'KID-EXP-301-MAR-4' },
      { id: 'v-006-3', sku: 'VF-KID-006-MAR-6', size: '6-7 Yrs', color: 'Maroon & Gold', stock: 18, costPrice: 550, price: 1050, supplierVariantId: 'KID-EXP-301-MAR-6' },
      { id: 'v-006-4', sku: 'VF-KID-006-TEA-4', size: '4-5 Yrs', color: 'Teal Blue & Silver', stock: 15, costPrice: 550, price: 1050, supplierVariantId: 'KID-EXP-301-TEA-4' }
    ],
    stockQuantity: 68,
    weightKg: 0.3,
    status: 'published',
    shippingInfo: 'Fast dispatch within 24 hours.',
    shippingInfoBn: '২৪ ঘণ্টার মধ্যে দ্রুত ডেলিভারি প্রস্তুত।',
    isFeatured: true,
    isBestseller: false,
    isNewArrival: true
  },
  {
    id: 'prod-007',
    title: 'Luxury Organza Embroidered 3-Piece Suite',
    titleBn: 'লাক্সারি অরগাঞ্জা এমব্রয়ডারি থ্রি-পিস স্যুট',
    description: 'Floor-length flared designer kameez with heavy threadwork, paired with a digital floral organza dupatta and tonal silk trousers. High-end festive masterpiece.',
    descriptionBn: 'অভিজাত ফ্লোর-লেন্থ ডিজাইনার কামিজ, ডিজিটাল ফ্লোরাল অরগাঞ্জা ওড়না এবং সিল্ক ট্রাউজার। বিয়ে ও উৎসবের আভিজাত্য।',
    sku: 'VF-3PC-007',
    supplierProductId: 'DSER-3PC-991',
    supplierName: 'DSers',
    supplierProductUrl: 'https://dsers.com/product/luxury-organza-3piece-991',
    category: 'Three-Piece and Two-Piece',
    subcategory: 'Three-Piece',
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 2200,
    sellingPrice: 4850,
    salePrice: 4200,
    discountPercent: 13,
    sizes: ['M', 'L', 'XL'],
    colors: ['Champagne Gold', 'Powder Blue', 'Lavender Mist'],
    variants: [
      { id: 'v-007-1', sku: 'VF-3PC-007-GLD-M', size: 'M', color: 'Champagne Gold', stock: 14, costPrice: 2200, price: 4200, supplierVariantId: 'DSER-3PC-991-GLD-M' },
      { id: 'v-007-2', sku: 'VF-3PC-007-GLD-L', size: 'L', color: 'Champagne Gold', stock: 16, costPrice: 2200, price: 4200, supplierVariantId: 'DSER-3PC-991-GLD-L' },
      { id: 'v-007-3', sku: 'VF-3PC-007-BLU-M', size: 'M', color: 'Powder Blue', stock: 12, costPrice: 2200, price: 4200, supplierVariantId: 'DSER-3PC-991-BLU-M' },
    ],
    stockQuantity: 42,
    weightKg: 0.8,
    status: 'published',
    shippingInfo: 'Double packed in waterproof bubble wrap.',
    shippingInfoBn: 'ওয়াটারপ্রুফ ডাবল প্যাকেজিংয়ে প্রেরিত।',
    isFeatured: true,
    isBestseller: true,
    isNewArrival: true
  },
  {
    id: 'prod-008',
    title: 'Premium Combed Cotton Heavyweight Oversized Tee',
    titleBn: 'প্রিমিয়াম কম্বড কটন হেভিওয়েট ওভারসাইজড টি-শার্ট',
    description: '240 GSM dense knit heavyweight fabric with drop-shoulder silhouette, non-sagging ribbed collar, and reactive dye color retention.',
    descriptionBn: '২৪০ জিএসএম ডেনসিটি হেভিওয়েট কটন। ড্রপ-শোল্ডার ওভারসাইজড লুক ও প্রিমিয়াম সফট ফিনিশিং।',
    sku: 'VF-TSH-008',
    supplierProductId: 'CJ-TSH-9821',
    supplierName: 'CJdropshipping',
    supplierProductUrl: 'https://cjdropshipping.com/product/cotton-heavyweight-tshirt-9821',
    category: 'Shirts and T-shirts',
    subcategory: 'T-shirts',
    images: [
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 450,
    sellingPrice: 950,
    salePrice: 850,
    discountPercent: 11,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Midnight Black', 'Ivory White', 'Sage Green', 'Warm Mocha'],
    variants: [
      { id: 'v-008-1', sku: 'VF-TSH-008-BLK-M', size: 'M', color: 'Midnight Black', stock: 45, costPrice: 450, price: 850, supplierVariantId: 'CJ-TSH-9821-BLK-M' },
      { id: 'v-008-2', sku: 'VF-TSH-008-BLK-L', size: 'L', color: 'Midnight Black', stock: 55, costPrice: 450, price: 850, supplierVariantId: 'CJ-TSH-9821-BLK-L' },
      { id: 'v-008-3', sku: 'VF-TSH-008-WHT-M', size: 'M', color: 'Ivory White', stock: 30, costPrice: 450, price: 850, supplierVariantId: 'CJ-TSH-9821-WHT-M' },
      { id: 'v-008-4', sku: 'VF-TSH-008-WHT-L', size: 'L', color: 'Ivory White', stock: 35, costPrice: 450, price: 850, supplierVariantId: 'CJ-TSH-9821-WHT-L' },
    ],
    stockQuantity: 165,
    weightKg: 0.28,
    status: 'published',
    shippingInfo: 'Same-day dispatch for orders placed before 2 PM in Dhaka.',
    shippingInfoBn: 'দুপুর ২টার আগে অর্ডারে ঢাকায় সেম-ডে ডিসপ্যাচ।',
    isFeatured: false,
    isBestseller: true,
    isNewArrival: false
  },
  {
    id: 'prod-009',
    title: 'ShopBase Exclusive Semi-Long Embroidered Panjabi',
    titleBn: 'শপবেজ এক্সক্লুসিভ সেমি-লং এমব্রয়ডারি পাঞ্জাবি',
    description: 'Sourced via ShopBase Reseller Place (https://shopbasebd.com/). Pure blended linen with micro-thread motif on Mandarin collar and cuffs. Tailored fit for Bengali festive wear.',
    descriptionBn: 'শপবেজ বিডি রিসেলার হাব (shopbasebd.com) থেকে সংগৃহীত। পিওর ব্লেন্ডেড লিনেন এবং ব্যান্ড কলারে নিখুঁত সুতার কাজ।',
    sku: 'VF-SB-009',
    supplierProductId: 'SB-PNJ-7712',
    supplierName: 'ShopBase BD (https://shopbasebd.com/)',
    supplierProductUrl: 'https://shopbasebd.com/products/semi-long-jacquard-panjabi-7712',
    category: 'Panjabi and Kurta',
    subcategory: 'Festive Panjabi',
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 850,
    sellingPrice: 1950,
    salePrice: 1750,
    discountPercent: 10,
    sizes: ['40', '42', '44'],
    colors: ['Royal Navy', 'Off White'],
    variants: [
      { id: 'v-009-1', sku: 'VF-SB-009-NVY-40', size: '40', color: 'Royal Navy', stock: 35, costPrice: 850, price: 1750, supplierVariantId: 'SB-PNJ-7712-NVY-40' },
      { id: 'v-009-2', sku: 'VF-SB-009-NVY-42', size: '42', color: 'Royal Navy', stock: 45, costPrice: 850, price: 1750, supplierVariantId: 'SB-PNJ-7712-NVY-42' },
      { id: 'v-009-3', sku: 'VF-SB-009-WHT-40', size: '40', color: 'Off White', stock: 30, costPrice: 850, price: 1750, supplierVariantId: 'SB-PNJ-7712-WHT-40' }
    ],
    stockQuantity: 110,
    weightKg: 0.42,
    status: 'published',
    shippingInfo: 'Direct dispatch from ShopBase Reseller Tejgaon Hub via Steadfast.',
    shippingInfoBn: 'শপবেজ ঢাকা হাব থেকে সরাসরি কুরিয়ার ডিসপ্যাচ।',
    isFeatured: true,
    isBestseller: true,
    isNewArrival: true
  },
  {
    id: 'prod-010',
    title: 'Heritage Katan Silk Party Saree (ShopBase BD)',
    titleBn: 'কাতান সিল্ক পার্টি শাড়ি (শপবেজ বিডি)',
    description: 'Brought to you by ShopBase BD (https://shopbasebd.com/). Luxurious gold thread jacquard weaving on soft lightweight katan silk with matching blouse piece.',
    descriptionBn: 'শপবেজ বাংলাদেশ কালেকশন। নরম কাতান সিল্কের ওপর জমকালো সোনালী জরির অল-ওভার কাজের পার্টি শাড়ি।',
    sku: 'VF-SB-010',
    supplierProductId: 'SB-SRI-3301',
    supplierName: 'ShopBase BD (https://shopbasebd.com/)',
    supplierProductUrl: 'https://shopbasebd.com/products/katan-silk-heritage-saree-3301',
    category: 'Traditional Clothing',
    subcategory: 'Saree',
    images: [
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=900&auto=format&fit=crop&q=80'
    ],
    costPrice: 1850,
    sellingPrice: 3950,
    salePrice: 3650,
    discountPercent: 8,
    sizes: ['Free Size (12 Haat)'],
    colors: ['Crimson Red', 'Midnight Navy'],
    variants: [
      { id: 'v-010-1', sku: 'VF-SB-010-RED', size: 'Free Size (12 Haat)', color: 'Crimson Red', stock: 20, costPrice: 1850, price: 3650, supplierVariantId: 'SB-SRI-3301-RED' },
      { id: 'v-010-2', sku: 'VF-SB-010-NVY', size: 'Free Size (12 Haat)', color: 'Midnight Navy', stock: 25, costPrice: 1850, price: 3650, supplierVariantId: 'SB-SRI-3301-NVY' }
    ],
    stockQuantity: 45,
    weightKg: 0.68,
    status: 'published',
    shippingInfo: 'Delivered in signature protective gift pack nationwide.',
    shippingInfoBn: 'প্রটেক্টিভ গিফট বক্সে সারা দেশে হোম ডেলিভারি।',
    isFeatured: true,
    isBestseller: true,
    isNewArrival: true
  }
];

export const INITIAL_INTEGRATIONS = [
  {
    id: 'int-shopbase',
    name: 'ShopBase BD (https://shopbasebd.com/)',
    type: 'shopbase_reseller' as const,
    status: 'connected' as const,
    statusMessage: 'Connected to ShopBase Bangladesh (https://shopbasebd.com/). Dhaka central warehouse 24h stock sync and Steadfast courier auto-booking active.',
    config: {
      storeDomain: 'https://shopbasebd.com/',
      apiKey: 'sb_bd_live_reseller_token_2026',
      accessToken: 'sb_tok_shopbasebd_verified',
      apiUrl: 'https://shopbasebd.com/api/v1',
      sandboxMode: false,
      fulfillmentPriority: 1
    },
    stats: {
      productsCount: 4,
      activeOrdersCount: 2,
      lastSyncTimestamp: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
      lastSuccessfulFulfillment: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      syncErrorsCount: 0
    },
    settings: {
      autoImport: true,
      autoPublish: true,
      autoPriceSync: true,
      autoStockSync: true,
      autoFulfillPaidOrders: true,
      allowCodFulfillment: true,
      defaultMarkupPercentage: 90,
      minimumProfitMarginBdt: 450,
      maxShippingDays: 3
    },
    createdAt: new Date(Date.now() - 86400000 * 20).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'int-facebook',
    name: 'Facebook Page & Meta Shop (Facebook Commerce)',
    type: 'facebook_shop' as const,
    status: 'connected' as const,
    statusMessage: 'Connected to Facebook Page: VELRO FASHION BD. Live Messenger chat & automatic Catalog XML/JSON feed sync active.',
    config: {
      pageName: 'VELRO FASHION BD',
      pageId: 'velrofashion.bd',
      pageUrl: 'https://facebook.com/velrofashion.bd',
      messengerUrl: 'https://m.me/velrofashion.bd',
      pixelId: '129481928419284',
      accessToken: 'EAAB...facebook_page_token_verified',
      catalogSyncEnabled: true,
      messengerChatEnabled: true,
      sandboxMode: false,
      fulfillmentPriority: 1
    },
    stats: {
      productsCount: 10,
      activeOrdersCount: 0,
      lastSyncTimestamp: new Date().toISOString(),
      syncErrorsCount: 0
    },
    settings: {
      autoImport: false,
      autoPublish: true,
      autoPriceSync: true,
      autoStockSync: true,
      autoFulfillPaidOrders: false,
      allowCodFulfillment: false,
      defaultMarkupPercentage: 0,
      minimumProfitMarginBdt: 0,
      maxShippingDays: 0
    },
    createdAt: new Date(Date.now() - 86400000 * 15).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'int-cj',
    name: 'CJdropshipping Official API',
    type: 'cjdropshipping' as const,
    status: 'connected' as const,
    statusMessage: 'Connected & sync worker active. Real-time stock & fulfillment ready.',
    config: {
      apiKey: 'demo_cjdropshipping_api_key_bd',
      accessToken: 'cj_token_8829103982',
      apiUrl: 'https://developers.cjdropshipping.com/api2.0/v1',
      sandboxMode: true,
      fulfillmentPriority: 1
    },
    stats: {
      productsCount: 4,
      activeOrdersCount: 2,
      lastSyncTimestamp: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
      lastSuccessfulFulfillment: new Date(Date.now() - 1000 * 60 * 95).toISOString(),
      syncErrorsCount: 0
    },
    settings: {
      autoImport: true,
      autoPublish: true,
      autoPriceSync: true,
      autoStockSync: true,
      autoFulfillPaidOrders: true,
      allowCodFulfillment: true,
      defaultMarkupPercentage: 90,
      minimumProfitMarginBdt: 400,
      maxShippingDays: 5
    },
    createdAt: new Date(Date.now() - 86400000 * 14).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'int-dsers',
    name: 'DSers AliExpress Fulfillment',
    type: 'dsers' as const,
    status: 'connected' as const,
    statusMessage: 'DSers Open Platform token verified. Multi-item supplier routing enabled.',
    config: {
      apiKey: 'demo_dsers_app_key_bd',
      apiSecret: 'demo_dsers_app_secret_bd',
      apiUrl: 'https://openapi.dsers.com/api/v1',
      sandboxMode: true,
      fulfillmentPriority: 2
    },
    stats: {
      productsCount: 2,
      activeOrdersCount: 1,
      lastSyncTimestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
      lastSuccessfulFulfillment: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
      syncErrorsCount: 0
    },
    settings: {
      autoImport: false,
      autoPublish: false,
      autoPriceSync: true,
      autoStockSync: true,
      autoFulfillPaidOrders: true,
      allowCodFulfillment: false,
      defaultMarkupPercentage: 95,
      minimumProfitMarginBdt: 500,
      maxShippingDays: 7
    },
    createdAt: new Date(Date.now() - 86400000 * 10).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'int-shopify',
    name: 'Shopify Supplier Multi-Store Connect',
    type: 'shopify' as const,
    status: 'connected' as const,
    statusMessage: 'Private app token connected. Bi-directional order webhooks installed.',
    config: {
      storeDomain: 'velro-supplier.myshopify.com',
      accessToken: 'shpat_demo_secret_access_token_8819',
      apiUrl: 'https://velro-supplier.myshopify.com/admin/api/2026-01',
      sandboxMode: true,
      fulfillmentPriority: 3
    },
    stats: {
      productsCount: 1,
      activeOrdersCount: 1,
      lastSyncTimestamp: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
      lastSuccessfulFulfillment: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
      syncErrorsCount: 0
    },
    settings: {
      autoImport: true,
      autoPublish: true,
      autoPriceSync: true,
      autoStockSync: true,
      autoFulfillPaidOrders: true,
      allowCodFulfillment: true,
      defaultMarkupPercentage: 95,
      minimumProfitMarginBdt: 450,
      maxShippingDays: 3
    },
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'int-woocommerce',
    name: 'WooCommerce Artisan Drop',
    type: 'woocommerce' as const,
    status: 'action_required' as const,
    statusMessage: 'Consumer Key needs renewal or SSL certificate check.',
    config: {
      apiUrl: 'https://artisan-textiles.com.bd/wp-json/wc/v3',
      apiKey: '',
      apiSecret: '',
      sandboxMode: true,
      fulfillmentPriority: 4
    },
    stats: {
      productsCount: 0,
      activeOrdersCount: 0,
      syncErrorsCount: 2
    },
    settings: {
      autoImport: false,
      autoPublish: false,
      autoPriceSync: false,
      autoStockSync: false,
      autoFulfillPaidOrders: false,
      allowCodFulfillment: false,
      defaultMarkupPercentage: 80,
      minimumProfitMarginBdt: 300,
      maxShippingDays: 4
    },
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date().toISOString()
  }
];
